/* اختبارات الوحدات — تشغيل: node tests/run.js  (يكتب tests/test-results.json) */
'use strict';
const path = require('path'), fs = require('fs'), nc = require('node:crypto');
['util', 'crypto', 'kb', 'device', 'security', 'ai', 'twin', 'kitchen', 'body', 'fertility', 'chat', 'engine'].forEach(m => require(path.join('..', 'js', m + '.js')));
const KT = OvaKitchen, BD = OvaBody, F = OvaFertility, U = OvaUtil, C = OvaCrypto, AI = OvaAI, TW = OvaTwin, CH = OvaChat, E = OvaEngine, SEC = OvaSecurity, D = OvaDevice;
const results = [];
let failed = 0;
async function t(group, name, fn) {
  try { await fn(); results.push({ group, name, pass: true }); }
  catch (e) { failed++; results.push({ group, name, pass: false, error: String(e.message) }); console.error('FAIL', group, name, e.message); }
}
const eq = (a, b, m) => { if (a !== b) throw new Error((m || '') + ' expected ' + b + ' got ' + a); };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const near = (a, b, tol, m) => { if (Math.abs(a - b) > tol) throw new Error((m || '') + ' expected ≈' + b + ' got ' + a); };
const NOW = Date.UTC(2026, 10, 4, 14, 0);

(async () => {
  // ---- التشفير ----
  await t('crypto', 'SHA-256 يطابق Node على أطوال متعددة', () => {
    for (const s of ['', 'abc', 'x'.repeat(55), 'x'.repeat(56), 'x'.repeat(64), 'x'.repeat(1000), 'مرحبا بالعالم'.repeat(30)])
      eq(C.sha256Hex(s), nc.createHash('sha256').update(s).digest('hex'), 'len ' + s.length);
  });
  await t('crypto', 'JSON القياسي ثابت الترتيب', () => eq(C.canonical({ b: 1, a: [2, { d: 1, c: 2 }] }), C.canonical({ a: [2, { c: 2, d: 1 }], b: 1 })));
  await t('crypto', 'توقيع ECDSA يصح ويفشل عند أي تعديل', async () => {
    const k = await C.generateKeyPair(); const o = { a: 1, d: 5 }; const s = await C.sign(k.privateJwk, o);
    ok(await C.verify(k.publicJwk, { d: 5, a: 1 }, s)); ok(!(await C.verify(k.publicJwk, { a: 1, d: 6 }, s)));
    const k2 = await C.generateKeyPair(); ok(!(await C.verify(k2.publicJwk, o, s)));
  });
  // ---- إحصاء ----
  await t('util', 'سبيرمان: طردي/عكسي/روابط', () => {
    near(U.spearman([1, 2, 3, 4, 5], [10, 20, 30, 40, 50]), 1, 1e-9); near(U.spearman([1, 2, 3, 4, 5], [5, 4, 3, 2, 1]), -1, 1e-9);
    const r = U.spearman([1, 2, 2, 3], [1, 2, 3, 4]); ok(r > 0.9 && r < 1, 'ties ' + r);
    ok(isNaN(U.spearman([1, 1, 1], [1, 2, 3])));
  });
  await t('util', 'توحيد النص العربي', () => eq(U.normAr('أَدْوِيَتِي؟ ١٢'), 'ادويتي 12'));
  await t('util', 'مفاتيح الأيام بتوقيت السعودية', () => { eq(U.dayKey(Date.UTC(2026, 10, 4, 21, 30)), '2026-11-05'); eq(U.hhmm(Date.UTC(2026, 10, 4, 9, 5)), '12:05'); });
  // ---- الذكاء ----
  await t('ai', 'إحصاءات الجلوكوز و TIR', () => {
    const rs = [60, 80, 100, 150, 120].map((v, i) => ({ t: i * 1000, type: 'glucose', value: v }));
    const s = AI.glucoseStats(rs, 0, 1e6, { low: 70, high: 140 }); eq(s.n, 5); eq(s.tirPct, 60); eq(s.belowPct, 20); eq(s.abovePct, 20);
  });
  await t('ai', 'PBAC حسب Higham', () => {
    eq(AI.pbacDay({ pads: { m: 3 } }), 15); eq(AI.pbacDay({ pads: { s: 1 }, clotsL: 1 }), 25); eq(AI.pbacDay({ tampons: { s: 1 }, flooding: true, clotsS: 2 }), 17);
  });
  await t('ai', 'تحليل النزيف: غزير، متباعد، خطر', () => {
    const day = (k, o) => Object.assign({ date: k }, o);
    const heavy = []; for (let i = 0; i < 5; i++) heavy.push(day('2026-10-0' + (i + 1), { pads: { s: 2, m: 1 } }));
    const a = AI.bleedingAnalysis(heavy, Date.UTC(2026, 9, 20)); ok(a.patterns.some(p => p.code === 'HEAVY'), 'heavy'); ok(!a.urgent);
    const dz = AI.bleedingAnalysis([day('2026-10-01', { pads: { m: 2 }, dizzy: true })], Date.UTC(2026, 9, 5)); ok(dz.urgent, 'dizzy urgent');
    const sk = AI.bleedingAnalysis([day('2026-10-01', { pads: { s: 8 }, clotsL: 1 })], Date.UTC(2026, 9, 5)); ok(sk.urgent, 'soaking+clots urgent');
    const long = [day('2026-07-01', { pads: { m: 2 } }), day('2026-08-10', { pads: { m: 2 } })]; const l = AI.bleedingAnalysis(long, Date.UTC(2026, 7, 20));
    eq(l.cycleLens[0], 40); ok(l.patterns.some(p => p.code === 'LONG_CYCLES'));
    const none = AI.bleedingAnalysis([day('2026-01-01', { pads: { m: 2 } })], Date.UTC(2026, 6, 1)); ok(none.patterns.some(p => p.code === 'NO_PERIOD_90'));
    const sp = AI.bleedingAnalysis([day('2026-10-01', { spotting: true, pads: { l: 1 } })], Date.UTC(2026, 9, 2)); ok(sp.patterns.some(p => p.code === 'SPOTTING'));
  });
  await t('ai', 'حاجة التحليل: مستويات وأسباب', () => {
    const lo = AI.bloodTestNeed({ now: NOW, lastLabT: NOW - 10 * U.DAY, labIntervalDays: 90, patchAgeDays: 1, quality: 0.95, stats: { n: 10, belowPct: 0, cv: 15 }, fastingHighDays: 0 }); eq(lo.level, 'low'); eq(lo.reasons.length, 0);
    const hi = AI.bloodTestNeed({ now: NOW, lastLabT: null, labIntervalDays: 90, patchAgeDays: 5, quality: 0.4, stats: { n: 10, belowPct: 8, cv: 40 }, fastingHighDays: 4, calibratedThisPatch: false }); eq(hi.level, 'high'); ok(hi.reasons.length >= 5);
    const br = AI.bloodTestNeed({ now: NOW, lastLabT: NOW, quality: 0.9, patchAgeDays: 0, bleedingUrgent: true }); ok(br.reasons[0].code === 'BLEEDING_RED_FLAG');
  });
  await t('ai', 'مراجعة الخطة: لا تنفّذ ولا تتجاوز الخطة', () => {
    const r = AI.dosePlanReview({ quality: 0.4, stats: { n: 5, belowPct: 9 }, adherencePct: 60, deviceAlerts: [{ code: 'FLOW_MISMATCH' }] });
    ok(r.length === 4); ok(r.every(x => x.canExecute === false && x.withinPlan === true));
    eq(AI.dosePlanReview({ quality: 0.9, stats: { n: 5, belowPct: 0 }, adherencePct: 95 })[0].code, 'KEEP');
  });
  await t('ai', 'الغذاء: لا أقل من 1200 وضمن ±10% من الهدف ولا أرز بسمتي', () => {
    for (const p of [{ weightKg: 78, heightCm: 162, age: 27, activity: 'low', goal: 'lose' }, { weightKg: 50, heightCm: 155, age: 40, activity: 'low', goal: 'lose' }, { weightKg: 90, heightCm: 170, age: 30, activity: 'high', goal: 'maintain' }]) {
      for (let s = 0; s < 6; s++) { const d = AI.dietPlan(p, s); ok(d.energy.target >= 1200); ok(Math.abs(d.totals.kcal - d.energy.target) / d.energy.target < 0.1, 'kcal ' + d.totals.kcal + ' vs ' + d.energy.target); ok(!d.meals.some(m => m.items.some(i => i.id === 'basmati'))); }
    }
  });
  await t('ai', 'المكملات: تحذيرات وامتناع عن التخمين', () => {
    ok(!AI.supplementCheck('زعفران').found); ok(AI.supplementCheck('زعفران').text.includes('لا أخمّن'));
    ok(AI.supplementCheck('عرق السوس', { hypertension: true }).warnings.length === 1);
    ok(AI.supplementCheck('أوميغا 3', { meds: 'وارفارين' }).warnings.length === 1);
    ok(AI.supplementCheck('بربرين', { meds: '' }).warnings.length === 0); ok(AI.supplementCheck('بربرين', { meds: 'ميتفورمين' }).warnings.length === 1);
    ok(AI.supplementCheck('فيتامين د').warnings.length === 1);
  });
  // ---- التوأم ----
  await t('twin', 'الأساس بلا تغيير، والوزن يتناقص مع العجز، والالتزام صفر = لا أثر', () => {
    const b = { weightKg: 78, heightCm: 162, fastingGlucose: 98, fastingInsulin: 14, horizonDays: 180 };
    const cur = TW.simulate(Object.assign({}, b, { deficitKcal: 0, activityMinPerWeek: 0, adherence: 1 })); eq(cur.summary.weightDelta, 0); eq(cur.summary.fgEnd, 98);
    const a = TW.simulate(Object.assign({}, b, { deficitKcal: 300, activityMinPerWeek: 0, adherence: 1 })), c = TW.simulate(Object.assign({}, b, { deficitKcal: 500, activityMinPerWeek: 0, adherence: 1 }));
    ok(c.summary.weightDelta < a.summary.weightDelta && a.summary.weightDelta < 0);
    const z = TW.simulate(Object.assign({}, b, { deficitKcal: 500, activityMinPerWeek: 300, adherence: 0 })); eq(z.summary.weightDelta, 0); eq(z.summary.fgEnd, 98);
  });
  await t('twin', 'نطاقات السكر والإنسولين تطابق مراجعة Domecq عند الأفق الطويل', () => {
    const r = TW.simulate({ weightKg: 78, heightCm: 162, fastingGlucose: 98, fastingInsulin: 14, deficitKcal: 300, activityMinPerWeek: 150, adherence: 1, horizonDays: 360 });
    const i = r.days.length - 1;
    near(r.fg.mid[i] - 98, -2.3, 0.1); near(r.fg.lo[i] - 98, -4.5, 0.15); near(r.fg.hi[i] - 98, -0.1, 0.05);
    near(r.fi.mid[i] - 14, -2.1, 0.1); near(r.fi.lo[i] - 14, -3.3, 0.15); near(r.fi.hi[i] - 14, -1.0, 0.05);
    eq(r.days[i], 360, 'last day equals horizon');
    ok(r.weight.lo[i] < r.weight.mid[i] && r.weight.mid[i] < r.weight.hi[i]);
  });
  await t('twin', 'افتراض الطبيب يظهر صراحة ولا يُفترض افتراضياً', () => {
    const b = { weightKg: 78, heightCm: 162, fastingGlucose: 98, horizonDays: 180, deficitKcal: 0, activityMinPerWeek: 0, adherence: 1 };
    ok(TW.simulate(b).notes.some(n => n.includes('لا أثر دوائي'))); const r = TW.simulate(Object.assign({}, b, { fgAssumption: -5 })); ok(r.summary.fgEnd < 98); ok(r.notes.some(n => n.includes('افتراضاً أدخله الطبيب')));
    eq(TW.simulate(b).fi, null);
  });
  await t('twin', 'لا نمذجة للدورة الشهرية', () => ok(!JSON.stringify(Object.keys(TW.simulate({ weightKg: 70, heightCm: 160, fastingGlucose: 90 }))).includes('cycle')));
  // ---- الجهاز ----
  await t('device', 'المعايرة تقلل الخطأ، والجودة تنخفض بعمر الرقعة', () => {
    const s = D.newState(5), dev = D.create(s, () => []); const t0 = Date.UTC(2026, 10, 1, 6);
    dev.applyPatch(t0); const t1 = t0 + 6 * U.DAY + 10 * U.HOUR; // 6.4 يوم
    const err = tt => Math.abs(dev.senseGlucose(tt).value - dev.trueGlucose(tt));
    const before = U.mean([0, 1, 2, 3, 4, 5].map(i => err(t1 + i * 5 * U.MIN)));
    const qOld = dev.senseGlucose(t1).q, qNew = dev.senseGlucose(t0 + U.HOUR).q; dev.calibrate(t1, dev.trueGlucose(t1)); ok(dev.senseGlucose(t1 + 10 * U.MIN).q > qOld, 'calibration restores quality'); const err2 = tt => Math.abs(dev.senseGlucose(tt).value - dev.trueGlucose(tt)); const after = U.mean([0, 1, 2, 3, 4, 5].map(i => err2(t1 + 10 * U.MIN + i * 5 * U.MIN)));
    ok(after < before, 'before ' + before + ' after ' + after);
    ok(qNew > qOld + 0.1, 'quality drops with age ' + qNew + ' ' + qOld);
  });
  await t('device', 'حساب الخزان: 4×25 µL × 7 أيام ≤ 1000', () => ok(4 * 25 * 7 + 100 <= D.RESERVOIR_UL, 'مع هامش'));
  await t('device', 'استجابة الوجبة: ارتفاع ثم عودة', () => {
    const meals = [{ t: Date.UTC(2026, 10, 1, 10), carbs: 60 }], dev = D.create(D.newState(9), () => meals);
    const base = dev.trueGlucose(Date.UTC(2026, 10, 1, 9)), peak = dev.trueGlucose(Date.UTC(2026, 10, 1, 10, 50)), later = dev.trueGlucose(Date.UTC(2026, 10, 1, 14));
    ok(peak - base > 35); ok(Math.abs(later - base) < 10);
  });
  // ---- المحرك والأمان (على بيانات العرض) ----
  const env = await E.seedDemo(NOW);
  await t('engine', 'العرض التجريبي: قراءات، جرعات منفّذة، سلسلة سليمة', () => {
    ok(env.S.readings.filter(r => r.type === 'glucose').length > 3500); ok(env.S.gate.deliveries.length >= 50); ok(env.S.gate.deliveries.every(d => d.source === 'plan'));
    ok(SEC.verifyChain(env.S.gate.audit).ok); eq(AI.adherence(env.S.gate.plan, env.S.gate.deliveries, NOW, 7), 100);
    ok(env.S.device.reservoirUL > 0);
  });
  await t('engine', 'الاشتقاق: سياق المساعد كامل', () => {
    const d = E.derive(env, NOW); ok(d.latestGlucose && d.stats7.n > 1000); ok(d.bloodNeed.reasons.some(r => r.code === 'LAB_DUE')); ok(d.nextDose); ok(d.twinRes.summary); ok(d.diet.totals.kcal > 1000);
    ok(d.bleeding.patterns.some(p => p.code === 'LONG_CYCLES'));
  });
  await t('security', 'كل هجمات المختبر تُصَدّ', async () => {
    for (const a of E.attacks) { const r = await E.runAttack(env, a.id, NOW + 5 * U.MIN); ok(r.pass, a.id + ' got ' + r.got); }
  });
  await t('security', 'خطة تتجاوز الحدود الصلبة ترفض', async () => {
    const r = await E.signAndInstallPlan(env, { doseUL: 60, times: ['09:00'], singleMaxUL: 60, dailyCapUL: 100, minIntervalMin: 60 }, NOW + 6 * U.MIN); eq(r.code, 'PLAN_EXCEEDS_HARD_LIMIT');
  });
  await t('security', 'خطة جديدة بإصدار أعلى تُقبل وتحل محل القديمة', async () => {
    const v0 = env.S.gate.plan.version; const r = await E.signAndInstallPlan(env, { doseUL: 20, times: ['08:00', '14:00', '20:00'], singleMaxUL: 25, dailyCapUL: 70, minIntervalMin: 240 }, NOW + 7 * U.MIN); ok(r.ok); eq(env.S.gate.plan.version, v0 + 1);
  });
  await t('security', 'مفتاح مُلغى لا يوقّع خطة جديدة', async () => {
    const e2 = await E.seedDemo(NOW); const old = e2.S.doctor.keyId; e2.gate.revokeKey(old, NOW); const r = await E.signAndInstallPlan(e2, { doseUL: 20, times: ['08:00'], singleMaxUL: 25, dailyCapUL: 70, minIntervalMin: 240 }, NOW + U.MIN); eq(r.code, 'KEY_REVOKED');
  });
  await t('security', 'السقف اليومي والفاصل الزمني يُفرضان على الأوامر الموقَّعة', async () => {
    const e2 = await E.seedDemo(NOW); const day = U.dayStart(NOW) + 23 * U.HOUR;
    E.advance(e2, day); // بعد كل جرعات اليوم المجدولة (4×25=100)
    const r1 = await E.sendCommand(e2, { doseUL: 15 }, day); eq(r1.code, 'DAILY_CAP_EXCEEDED');
    const next = day + 2 * U.HOUR; E.advance(e2, next); // اليوم التالي 01:00 — لا جرعات جديدة بعد، وآخر جرعة 22:00 (>180 د)
    const r2 = await E.sendCommand(e2, { doseUL: 10 }, next); eq(r2.code, 'OK');
    const r3 = await E.sendCommand(e2, { doseUL: 10 }, next + 5 * U.MIN); eq(r3.code, 'MIN_INTERVAL');
  });
  await t('device', 'انسداد: توقف تلقائي، قفل العطل، ورفض ما بعده', async () => {
    const e2 = await E.seedDemo(NOW); e2.S.device.faults.occlusion = true; const nd = E.nextDose(e2.gate.s.plan, NOW);
    E.advance(e2, nd.t + 6 * U.MIN); const last = e2.gate.s.audit.slice(-1)[0]; eq(last.type, 'HALT');
    eq(e2.S.device.faultLatched, 'FLOW_MISMATCH'); ok(e2.device.alerts(nd.t + 6 * U.MIN).some(a => a.lvl === 'danger'));
    const dl = e2.gate.s.deliveries.slice(-1)[0]; ok(dl.deliveredUL < 0.25 * dl.commandedUL + 0.01, 'delivered ' + dl.deliveredUL);
    const r = await E.sendCommand(e2, { doseUL: 10 }, nd.t + 4 * U.HOUR); eq(r.code, 'DEVICE_FAULT');
    e2.device.clearFault(); ok(!e2.S.device.faultLatched);
  });
  await t('device', 'تدفق زائد يوقف التوصيل أيضاً', async () => {
    const e2 = await E.seedDemo(NOW); e2.S.device.faults.overflow = true; const nd = E.nextDose(e2.gate.s.plan, NOW); E.advance(e2, nd.t + 6 * U.MIN); eq(e2.S.device.faultLatched, 'FLOW_MISMATCH');
  });
  await t('device', 'انقطاع البلوتوث: «متابعة الخطة» تنفّذ و«تعليق» لا تنفّذ', async () => {
    const run = async policy => {
      const e2 = await E.seedDemo(NOW); await E.signAndInstallPlan(e2, { doseUL: 20, times: ['23:00'], singleMaxUL: 25, dailyCapUL: 110, minIntervalMin: 60, onSignalLoss: policy }, NOW + U.MIN);
      e2.S.device.bleUp = false; const before = e2.gate.s.deliveries.length; E.advance(e2, U.dayStart(NOW) + 23 * U.HOUR + 6 * U.MIN); return e2.gate.s.deliveries.length - before;
    };
    eq(await run('continue_plan'), 1); eq(await run('hold'), 0);
  });
  await t('security', 'العبث بسجل التدقيق يُكتشف', () => {
    const a = JSON.parse(JSON.stringify(env.S.gate.audit)); ok(SEC.verifyChain(a).ok); a[5].code = 'X'; const v = SEC.verifyChain(a); ok(!v.ok); eq(v.brokenAt, 5);
    const b = JSON.parse(JSON.stringify(env.S.gate.audit)); b.splice(3, 1); ok(!SEC.verifyChain(b).ok);
  });
  await t('engine', 'القياس المرجعي يعاير ويُسجَّل', () => {
    const e = env; const before = e.S.device.calib; E.addReading(e, 'lab_glucose', 95); ok(e.S.device.calib && e.S.device.calib.t === e.S.clock.now); ok(e.S.device.calib !== before);
    ok(E.derive(e).bloodNeed.reasons.every(r => r.code !== 'NO_CALIBRATION'));
  });
  // ---- المحادثة ----
  const ctx = E.derive(env, NOW);
  const ask = q => CH.reply(q, ctx);
  await t('chat', 'النوايا الأساسية', () => {
    const m = { 'وش يقرأ الجهاز بالضبط؟': 'device_read', 'كم قراءة السكر الحالية؟': 'glucose', 'متى جرعتي القادمة؟': 'dose', 'هل أحتاج تحليل دم؟': 'blood', 'كيف نزيفي؟': 'bleeding', 'اقترح لي وجبات اليوم': 'diet', 'ماذا لو التزمت بالنظام؟': 'twin', 'هل ميو إينوزيتول مناسب؟': 'supplement', 'ما حالة البطارية؟': 'device', 'من أنت؟': 'about', 'مرحبا': 'greet' };
    for (const q in m) eq(ask(q).intent, m[q], q);
  });
  await t('chat', 'يرفض تغيير الجرعة ويحيل للطبيب', () => { for (const q of ['هل أزيد الجرعة؟', 'ابي اضاعف الجرعة', 'أعدل الدواء بنفسي']) { const r = ask(q); eq(r.intent, 'dose_change', q); ok(r.text.includes('لا أستطيع') && r.text.includes('طبيبك')); } });
  await t('chat', 'الطوارئ والامتناع', () => {
    const r = ask('عندي نزيف شديد وإغماء'); eq(r.intent, 'emergency'); eq(r.tone, 'danger'); ok(r.text.includes('997'));
    eq(ask('هل الزعفران جيد؟').intent === 'fallback' || ask('هل الزعفران جيد؟').intent === 'supplement', true);
    eq(ask('').intent, 'empty'); eq(ask('بلا معنى xyz').intent, 'fallback');
  });
  await t('chat', 'الإجابات مبنية على بيانات السجل (قيم حقيقية)', () => {
    const g = ask('كم السكر؟'); ok(g.text.includes(String(ctx.latestGlucose.value)) && g.text.includes(String(ctx.stats7.tirPct)));
    const d = ask('متى جرعتي'); ok(d.text.includes(ctx.nextDose.when)); const b = ask('تحليل دم'); ok(b.text.includes(String(ctx.bloodNeed.score)));
    ok(ask('وش يقرأ الجهاز').text.includes('HM1')); ok(ask('من انت').text.includes('نموذجاً لغوياً مدرَّباً'));
  });

  await t('fertility', 'دورات منتظمة 28 يوماً: متوسط، موعد قادم، إباضة = القادمة − 14، نافذة 6 أيام', () => {
    const a = F.analyze(['2026-08-01', '2026-08-29', '2026-09-26', '2026-10-24'], [], NOW);
    eq(a.mean, 28); eq(a.irregular, false); eq(a.nextStart.key, '2026-11-21'); eq(a.ovulation.key, '2026-11-07');
    eq(F.diff(a.fertile.from, a.fertile.to) + 1, 6); eq(a.fertile.to, a.ovulation.key); eq(a.dayOfCycle, 12);
  });
  await t('fertility', 'دورة 39 يوماً تُصنَّف غير منتظمة وفق معيار >35', () => {
    const a = F.analyze(['2026-09-10', '2026-10-19'], [], NOW); eq(a.irregular, true); ok(a.reasons[0].includes('35')); eq(a.confidence, 'low');
  });
  await t('fertility', 'دورة أطول من 90 يوماً تُعلَّم', () => { const a = F.analyze(['2026-05-01', '2026-08-15'], [], NOW); ok(a.reasons.some(r => r.includes('90'))); });
  await t('fertility', 'اختبار LH إيجابي يحدد الإباضة بعده بيوم', () => {
    const a = F.analyze(['2026-09-10', '2026-10-19'], [{ date: '2026-10-30', lh: 'pos' }], NOW); eq(a.ovulation.basis, 'LH'); eq(a.ovulation.key, '2026-10-31');
  });
  await t('fertility', 'LH إيجابي من دورة سابقة لا يُستخدم', () => {
    const a = F.analyze(['2026-09-10', '2026-10-19'], [{ date: '2026-09-25', lh: 'pos' }], NOW); eq(a.ovulation.basis, 'calendar');
  });
  await t('fertility', 'بلا بيانات: لا تقدير ولا أخطاء', () => { eq(F.analyze([], [], NOW).empty, true); eq(F.calendar(F.analyze([], [], NOW), []).length, 0); });
  await t('fertility', 'بيانات العرض التجريبي تنتج تقديراً وسياقاً للمساعد', async () => {
    const env = await E.seedDemo(NOW), c = E.derive(env); ok(!c.fert.empty && c.fert.irregular === false || c.fert.insufficient); ok(c.bmi.v > 25);
    const r = CH.reply('متى نافذة الخصوبة؟', c); eq(r.intent, 'fertility'); ok(r.text.includes('تقدير')); ok(!/%\s*احتمال|احتمال الحمل/.test(r.text));
  });
  await t('device', 'الإيقاف الطارئ يمنع الجرعات ويُستأنف يدوياً', async () => {
    const env = await E.seedDemo(NOW); env.S.device.faultLatched = 'USER_STOP';
    ok(env.device.alerts(NOW).some(a => a.code === 'USER_STOP')); env.device.clearFault(); eq(env.S.device.faultLatched, null);
  });
  await t('kb', 'المراجع: روابط https ومعرّفات فريدة', () => { const ids = new Set(OvaKB.REFERENCES.map(r => r.id)); eq(ids.size, OvaKB.REFERENCES.length); ok(OvaKB.REFERENCES.every(r => /^https:\/\//.test(r.url))); });

  // ---- المطبخ: وجبة من المكوّنات ----
  await t('kitchen', 'تحليل نص المكوّنات: فواصل وواو العطف والعبارات المركبة', () => {
    const r = KT.parse('بيض، طماطم وبصل, رز بني و توت');
    ['egg', 'tomato', 'onion', 'brownrice', 'berries'].forEach(i => ok(r.ids.includes(i), i)); ok(!r.ids.includes('rice'), 'رز بني لا يُحسب رزاً أبيض'); eq(r.unknown.length, 0);
    ok(KT.parse('ورق عنب').unknown.length === 2, 'كلمات غير معروفة تُعاد');
  });
  await t('kitchen', 'الاقتراح لا يتطلب أكثر من مكوّن أساسي واحد ناقص ويحترم نوع الوجبة', () => {
    const s = KT.suggest(['egg', 'tomato', 'onion'], { slot: 'b', limit: 5 });
    ok(s.length > 0); ok(s.every(r => r.slot === 'b')); ok(s.every(r => r.missing.length <= 1)); eq(s[0].id, 'shakshuka');
    eq(KT.suggest(['nuts'], { slot: 'any' }).length, 0);
  });
  await t('kitchen', 'الحصة تُضبط على هدف الوجبة في الخطة', async () => {
    const env = await E.seedDemo(NOW), d = E.derive(env), p = env.S.patient;
    const plan = AI.dietPlan({ weightKg: d.weight, heightCm: p.heightCm, age: p.age, activity: p.activity, goal: p.goal }, 3);
    const s = KT.suggest(['lentil', 'onion', 'carrot'], { slot: 'l', plan }); const tg = KT.slotTarget(plan, 'l');
    ok(s.length && tg > 0); ok(Math.abs(s[0].kcal - tg) <= s[0].kcal / s[0].servings * 0.25 + 1 || s[0].servings === 0.5 || s[0].servings === 1.5, 'servings ' + s[0].servings);
  });
  // ---- توأم الجسم ----
  await t('body', 'القيم الافتراضية والتحقق من النطاقات', () => {
    const m = BD.defaults(162, 78); eq(BD.validate(m).length, 0); ok(m.estimated);
    ok(BD.validate(Object.assign({}, m, { waist: 400 })).includes('الخصر'));
    const r = BD.ratios({ heightCm: 160, weightKg: 64, waist: 80, hip: 100 }); eq(r.whtr, 0.5); eq(r.whr, 0.8); eq(r.whtrHigh, true);
  });
  await t('body', 'الإسقاط: نقص الوزن يقلّل القياسات تدريجياً، ودون خطة لا تغيير', () => {
    const m = BD.defaults(162, 78), base = { weightKg: 78, heightCm: 162, fastingGlucose: 95, horizonDays: 365, stepDays: 1 };
    const plan = TW.simulate(Object.assign({ deficitKcal: 300, activityMinPerWeek: 150, adherence: 0.8 }, base));
    const a = BD.project(m, plan, 'm', 3), b = BD.project(m, plan, 'm', 9);
    ok(a.delta.waist < 0 && b.delta.waist < a.delta.waist, 'monotonic'); near(a.delta.waist, a.delta.weightKg * BD.CM_PER_KG.waist, 0.15);
    eq(BD.project(m, plan, 'd', 0).delta.waist, 0);
    const none = TW.simulate(Object.assign({ deficitKcal: 0, activityMinPerWeek: 0, adherence: 1 }, base)); eq(BD.project(m, none, 'm', 12).delta.hip, 0);
  });
  await t('body', 'حلقات المجسّم موجبة ومتناظرة، والخصر أضيق من الورك', () => {
    const R = BD.rings({ heightCm: 165, weightKg: 70, bust: 92, waist: 76, hip: 102, thigh: 56, arm: 28 });
    ok([...R.torso, ...R.leg, ...R.arm, ...R.head].every(r => r.rx > 0 && r.rz > 0 && r.y > 0 && r.y <= 1));
    const w = R.torso.find(r => r.y === 0.61), h = R.torso.find(r => r.y === 0.49); ok(w.rx < h.rx);
    near(Math.PI * (3 * (w.rx + w.rz) - Math.sqrt((3 * w.rx + w.rz) * (w.rx + 3 * w.rz))), 76, 0.01, 'circumference');
  });
  await t('body', 'المسح: يعيد قناع ظلّ ونسباً فقط، دون بكسلات الصورة', () => {
    const w = 60, h = 120, data = new Uint8ClampedArray(w * h * 4);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const o = (y * w + x) * 4, cx = Math.abs(x - 30), yy = y / h;
      const half = yy < 0.12 ? 0 : yy < 0.2 ? 5 : yy < 0.32 ? 12 : yy < 0.42 ? 9 : yy < 0.56 ? 13 : 0;
      const legs = yy >= 0.56 && yy < 0.97 && cx >= 2 && cx <= 9;
      const fg = (half && cx <= half) || legs || (yy >= 0.04 && yy < 0.12 && cx <= 4);
      data[o] = fg ? 60 : 210; data[o + 1] = fg ? 50 : 205; data[o + 2] = fg ? 80 : 195; data[o + 3] = 255;
    }
    const s = BD.silhouette(data, w, h);
    eq(s.ok, true); ok(s.shape && s.shape.waist < 1.15 && s.shape.waist > 0.85, JSON.stringify(s.shape));
    ok(s.mask instanceof Uint8Array && s.mask.every(v => v === 0 || v === 1), 'binary mask only'); ok(!('data' in s) && !('pixels' in s));
    const blank = BD.silhouette(new Uint8ClampedArray(w * h * 4).fill(200), w, h); eq(blank.ok, false); eq(blank.shape, null);
  });
  const summary = { when: new Date().toISOString(), total: results.length, passed: results.filter(r => r.pass).length, failed, groups: results.reduce((a, r) => { a[r.group] = a[r.group] || { passed: 0, total: 0 }; a[r.group].total++; if (r.pass) a[r.group].passed++; return a; }, {}), tests: results };
  fs.writeFileSync(path.join(__dirname, 'test-results.json'), JSON.stringify(summary, null, 1));
  console.log(summary.passed + '/' + summary.total + ' passed', JSON.stringify(summary.groups));
  process.exit(failed ? 1 : 0);
})();
