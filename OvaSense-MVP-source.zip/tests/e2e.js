/* اختبار المتصفح الشامل (Playwright) — تشغيل: node tests/e2e.js */
'use strict';
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const url = 'file://' + path.resolve(__dirname, '..', 'index.html');
const shots = path.resolve(__dirname, '..', 'shots');
const res = [];
const step = async (name, fn) => { try { await fn(); res.push({ name, pass: true }); } catch (e) { res.push({ name, pass: false, error: e.message.split('\n')[0] }); console.error('FAIL', name, e.message.split('\n')[0]); } };

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 2, locale: 'ar-SA' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(m.text()); });
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  const go = async v => { await page.click('#nav button[data-v="' + v + '"]'); await page.waitForTimeout(150); };
  const txt = () => page.locator('#view').innerText();

  await step('تحميل الصفحة من file:// وعرض الرئيسية', async () => {
    await page.goto(url); await page.waitForSelector('.welcome'); await page.screenshot({ path: shots + '/00-welcome.png' }); await page.click('.welcome [data-act=wDone]'); await page.waitForSelector('.tile'); const t = await txt();
    if (!t.includes('الجلوكوز الحالي') || !t.includes('الجرعة القادمة')) throw new Error('home content');
    await page.screenshot({ path: shots + '/01-home.png' });
  });
  await step('كل التبويبات تُعرض بلا أخطاء', async () => {
    for (const v of ['measure', 'food', 'symptoms', 'fertility', 'twin', 'chat', 'doctor', 'device', 'lab', 'about', 'home']) { await go(v); if ((await txt()).length < 80) throw new Error('empty ' + v); }
  });
  await step('تسجيل قياس وزن ثم قياس دم مرجعي (معايرة)', async () => {
    await go('measure'); await page.selectOption('#m-type', 'weight'); await page.fill('#m-val', '77.5'); await page.click('[data-act=addMeasure]');
    if (!(await txt()).includes('77.5')) throw new Error('weight not logged');
    await page.selectOption('#m-type', 'lab_glucose'); await page.fill('#m-val', '96'); await page.click('[data-act=addMeasure]');
    const t = await txt(); if (!t.includes('معايرة المستشعر')) throw new Error('no calibration msg');
    await page.fill('#m-val', '5'); await page.click('[data-act=addMeasure]'); if (!(await txt()).includes('خارج النطاق')) throw new Error('validation missing');
    await page.screenshot({ path: shots + '/02-measure.png' });
  });
  await step('الغذاء: تحديث الخطة وتسجيل وجبة والتحقق من مكمل', async () => {
    await go('food'); await page.click('[data-act=shuffleDiet]'); await page.fill('#ml-c', '70'); await page.click('[data-act=addMeal]');
    await page.fill('#sp-q', 'عرق السوس'); await page.check('#sp-h'); await page.click('[data-act=checkSupp]');
    const t = await txt(); if (!t.includes('عرق السوس') || !t.includes('الضغط')) throw new Error('supp warning'); await page.screenshot({ path: shots + '/03-food.png', fullPage: true });
  });
  await step('الأعراض والنزيف: حفظ وتحليل وتحذير الخطر', async () => {
    await go('symptoms'); await page.fill('#s-acne', '3').catch(() => { }); await page.click('[data-act=saveSymptoms]');
    await page.fill('#b-pm', '2'); await page.check('#b-dz'); await page.click('[data-act=saveBleeding]');
    const t = await txt(); if (!t.includes('دوخة') && !t.includes('طوارئ')) throw new Error('urgent not shown'); await page.screenshot({ path: shots + '/04-symptoms.png', fullPage: true });
  });
  await step('التوأم الرقمي: سيناريو جاهز ورسوم', async () => {
    await go('twin'); await page.click('.chip[data-act=preset]:nth-of-type(4)'); await page.waitForSelector('svg.chart');
    if ((await page.locator('svg.chart').count()) < 2) throw new Error('charts'); await page.selectOption('#t-hor', '360'); await page.waitForTimeout(150);
    const t = await txt(); if (!t.includes('الخلاصة بعد 360 يوم')) throw new Error('horizon'); await page.screenshot({ path: shots + '/05-twin.png', fullPage: true });
  });
  await step('المساعد: أسئلة وجواب مخصص ورفض تغيير الجرعة', async () => {
    await go('chat'); await page.fill('#chat-in', 'وش يقرأ الجهاز بالضبط؟'); await page.press('#chat-in', 'Enter');
    await page.waitForSelector('.msg.b'); await page.fill('#chat-in', 'هل أزيد الجرعة؟'); await page.press('#chat-in', 'Enter');
    await page.click('.chip[data-q="كم قراءة السكر الحالية؟"]'); await page.click('.chip[data-q="هل أحتاج تحليل دم؟"]');
    const t = await txt(); if (!t.includes('HM1') || !t.includes('لا أستطيع تغيير الجرعة') || !t.includes('آخر قراءة')) throw new Error('chat content');
    await page.screenshot({ path: shots + '/06-chat.png' });
  });
  await step('الطبيب: توقيع خطة وأمر ورفض/قبول', async () => {
    await go('doctor'); await page.fill('#pl-dose', '20'); await page.fill('#pl-times', '08:00,14:00,20:00'); await page.fill('#pl-sm', '25'); await page.fill('#pl-dc', '100'); await page.fill('#pl-mi', '240');
    await page.click('[data-act=signPlan]'); await page.waitForSelector('.alert.ok'); if (!(await txt()).includes('إصدار 2')) throw new Error('plan v2');
    await page.fill('#cmd-dose', '90'); await page.click('[data-act=sendCmd]'); if (!(await txt()).includes('تتجاوز الحد الأقصى')) throw new Error('over-limit not rejected');
    await page.fill('#pl-times', '8am'); await page.click('[data-act=signPlan]'); if (!(await txt()).includes('تحقق من الحقول')) throw new Error('validation');
    await page.screenshot({ path: shots + '/07-doctor.png', fullPage: true });
  });
  await step('الجهاز: تركيب رقعة وحقن انسداد ومسح العطل', async () => {
    await go('device'); await page.click('[data-act=newPatch]'); await page.check('input[data-k=occlusion]'); await page.click('[data-act=jump][data-h="24"]').catch(() => { });
    await page.waitForTimeout(200); const t = await txt(); if (!t.includes('متوقف') && !t.includes('عدم تطابق')) throw new Error('fault not latched');
    await page.screenshot({ path: shots + '/08-device-fault.png', fullPage: true });
    await page.uncheck('input[data-k=occlusion]'); await page.click('[data-act=clearFault]'); if ((await txt()).includes('يلزم مسح العطل')) throw new Error('fault not cleared');
  });
  await step('مختبر الأمان: كل الهجمات تُصَدّ', async () => {
    await go('lab'); await page.click('[data-act=runAll]'); await page.waitForSelector('table'); const ok = await page.locator('.pill.ok', { hasText: 'تم الصد' }).count();
    if (ok !== 11) throw new Error('blocked ' + ok + '/11'); await page.screenshot({ path: shots + '/09-lab.png', fullPage: true });
  });
  await step('الخصوبة: تقدير وتسجيل LH وبدء دورة، بلا نسبة حمل', async () => {
    await go('fertility'); let t = await txt();
    if (!t.includes('نافذة الخصوبة المقدّرة') || !t.includes('ليست وسيلة لمنع الحمل')) throw new Error('fertility content');
    if (/احتمال الحمل|%\s*حمل/.test(t)) throw new Error('pregnancy probability shown');
    await page.selectOption('#f-lh', 'pos'); await page.click('[data-act=saveFert]'); t = await txt(); if (!t.includes('من اختبار LH إيجابي')) throw new Error('LH not applied');
    await page.screenshot({ path: shots + '/04-fertility.png', fullPage: true });
  });
  await step('الإيقاف الطارئ والاستئناف + رسالة الطبيب + BMI', async () => {
    await go('home'); let t = await txt(); if (!t.includes('كتلة الجسم') || !t.includes('الدورة')) throw new Error('bmi/cycle tiles');
    await page.click('[data-act=estop]'); t = await txt(); if (!t.includes('أوقفتِ التوصيل يدوياً')) throw new Error('estop alert');
    await page.click('[data-act=clearFault]'); if ((await txt()).includes('أوقفتِ التوصيل يدوياً')) throw new Error('resume');
    await go('doctor'); await page.fill('#dn-t', 'راجعي القراءات الأسبوع القادم'); await page.click('[data-act=saveNote]'); await go('home');
    if (!(await txt()).includes('راجعي القراءات الأسبوع القادم')) throw new Error('doctor note not shown');
  });
  await step('الحفظ المحلي يبقى بعد إعادة التحميل', async () => {
    await page.reload(); await page.waitForSelector('.tile'); await go('measure'); if (!(await txt()).includes('77.5')) throw new Error('not persisted');
  });
  await step('الجولة الإرشادية تعمل حتى النهاية', async () => {
    await go('about'); await page.click('[data-act=tour]'); for (let i = 0; i < 7; i++) { await page.waitForSelector('#tour:not([hidden])'); await page.screenshot({ path: shots + '/tour-' + (i + 1) + '.png' }).catch(() => { }); await page.click('[data-act=tourNext]'); await page.waitForTimeout(250); }
    await page.waitForFunction(() => document.querySelector('#tour').hidden);
  });
  await step('تشغيل المحاكاة بسرعة 3600× يقدّم الزمن', async () => {
    await go('home'); const before = await page.locator('#simnow').innerText(); await page.selectOption('#scale', '3600'); await page.click('[data-act=runToggle]'); await page.waitForTimeout(2300); await page.click('[data-act=runToggle]');
    const after = await page.locator('#simnow').innerText(); if (before === after) throw new Error('time did not advance');
  });
  await step('إعادة ضبط البيانات', async () => {
    await go('about'); page.once('dialog', d => d.accept()); await page.click('[data-act=reset]'); await page.waitForSelector('.welcome'); await page.click('.welcome [data-act=wDone]'); await page.waitForSelector('.tile'); if (!(await txt()).includes('الجلوكوز الحالي')) throw new Error('reset');
  });
  await step('بدون localStorage يعمل التطبيق', async () => {
    const c2 = await browser.newContext(); const p2 = await c2.newPage(); const errs = [];
    p2.on('pageerror', e => errs.push(e.message));
    await p2.addInitScript(() => { Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked'); } }); });
    await p2.goto(url); await p2.waitForSelector('.welcome'); await p2.click('.welcome [data-act=wDone]'); await p2.waitForSelector('.tile'); if (errs.length) throw new Error(errs[0]); await c2.close();
  });
  // لقطات الجوال والوضع الداكن
  const m = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, colorScheme: 'dark', locale: 'ar-SA' });
  const mp = await m.newPage(); const merr = []; mp.on('pageerror', e => merr.push(e.message)); mp.on('console', x => { if (x.type() === 'error' && !/Failed to load resource/.test(x.text())) merr.push(x.text()); });
  await step('الجوال: لا تمرير أفقي للصفحة والوضع الداكن', async () => {
    await mp.goto(url); await mp.waitForSelector('.welcome'); await mp.click('.welcome [data-act=wDone]'); await mp.waitForSelector('.tile');
    for (const v of ['home', 'chat', 'twin', 'lab']) { await mp.click('#nav button[data-v="' + v + '"]'); await mp.waitForTimeout(150); const ov = await mp.evaluate(() => document.documentElement.scrollWidth - window.innerWidth); if (ov > 2) throw new Error('overflow ' + v + ' ' + ov); await mp.screenshot({ path: shots + '/m-' + v + '.png' }); }
    if (merr.length) throw new Error(merr[0]);
  });
  await m.close();
  if (errors.length) res.push({ name: 'لا أخطاء في وحدة التحكم (سطح المكتب)', pass: false, error: errors[0] }); else res.push({ name: 'لا أخطاء في وحدة التحكم (سطح المكتب)', pass: true });
  await browser.close();
  const failed = res.filter(r => !r.pass).length;
  fs.writeFileSync(path.join(__dirname, 'e2e-results.json'), JSON.stringify({ when: new Date().toISOString(), total: res.length, passed: res.length - failed, tests: res }, null, 1));
  console.log((res.length - failed) + '/' + res.length + ' e2e passed'); process.exit(failed ? 1 : 0);
})();
