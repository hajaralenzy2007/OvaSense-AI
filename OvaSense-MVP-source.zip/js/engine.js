/* OvaEngine — حالة التطبيق، تقدّم الزمن المحاكى، بيانات العرض التجريبي، والسياق للمساعد */
(function (g) {
  'use strict';
  const F = g.OvaFertility, U = g.OvaUtil, C = g.OvaCrypto, D = g.OvaDevice, SEC = g.OvaSecurity, AI = g.OvaAI, TW = g.OvaTwin;
  const E = {};
  const STEP = 5 * U.MIN;
  E.SUBSTANCE = 'مادة أ (يحدد الطبيب)';

  E.newState = function (now) {
    return {
      v: 1, demo: false,
      clock: { now, lastT: now, scale: 60, running: false },
      patient: { id: 'PT-DEMO-01', name: 'مريضة تجريبية', age: 27, heightCm: 162, weightKg: 78, activity: 'low', goal: 'lose', pregnant: false, hypertension: false, meds: '' },
      doctor: null, labs: { lastLabT: null, fastingInsulin: null, hba1c: null, labIntervalDays: 90 },
      range: { low: 70, high: 140 }, fastingThreshold: 100,
      readings: [], meals: [], symptoms: [], bleeding: [], events: [],
      device: D.newState(20260), gate: SEC.newState('OVA-POD-0001', 'PT-DEMO-01'),
      seq: 0, lastEnv: null, chat: [], twin: { scenario: 'diet_act', horizon: 180, deficit: 300, act: 150, adh: 80, fgAssumption: 0 },
      proposals: [], fertility: [], onboarded: false, doctorNote: null, role: 'patient'
    };
  };

  E.attach = function (S) {
    if (!S.fertility) S.fertility = []; if (S.onboarded === undefined) S.onboarded = true; if (S.doctorNote === undefined) S.doctorNote = null;
    const device = D.create(S.device, () => S.meals);
    const gate = SEC.createGate(device, S.gate);
    return { S, device, gate };
  };

  E.advance = function (env, toT) {
    const { S, device, gate } = env;
    let t = S.clock.lastT;
    while (t + STEP <= toT) {
      t += STEP;
      device.tick(5);
      const sg = device.senseGlucose(t);
      if (sg) S.readings.push({ t, type: 'glucose', value: sg.value, q: sg.q, src: 'device' });
      if (Math.round(t / STEP) % 12 === 0) { const h = device.senseHM1(t); if (h != null) S.readings.push({ t, type: 'hm1', value: h, src: 'device' }); }
      gate.runSchedule(t);
    }
    S.clock.lastT = t; S.clock.now = Math.max(toT, S.clock.now);
    const cut = toT - 30 * U.DAY;
    if (S.readings.length && S.readings[0].t < cut) S.readings = S.readings.filter(r => r.t >= cut);
  };

  // ---- أفعال المستخدمة ----
  E.addReading = function (env, type, value, o) {
    const { S, device } = env, now = S.clock.now;
    o = o || {};
    const r = Object.assign({ t: now, type, value: Number(value), src: 'manual' }, o);
    S.readings.push(r);
    if (type === 'lab_glucose') { const ok = device.calibrate(now, Number(value)); env.gate.audit(now, 'CALIB', ok ? 'OK' : 'NO_PATCH', 'ref=' + value); }
    return r;
  };
  E.addMeal = (env, name, carbs) => { env.S.meals.push({ t: env.S.clock.now, name, carbs: Number(carbs) }); env.S.meals.sort((a, b) => a.t - b.t); };

  // ---- الطبيب ----
  E.nextPlanVersion = env => (env.gate.s.plan ? env.gate.s.plan.version : 0) + 1;
  E.buildPlan = function (env, spec, now) {
    const S = env.S;
    return {
      planId: 'PLAN-' + E.nextPlanVersion(env), version: E.nextPlanVersion(env), keyId: S.doctor.keyId,
      patientId: S.patient.id, deviceId: S.device.deviceId, issuedAt: spec.issuedAt || now, expiresAt: spec.expiresAt || now + 30 * U.DAY,
      onSignalLoss: spec.onSignalLoss || 'continue_plan',
      items: [{ substance: spec.substance || E.SUBSTANCE, doseUL: spec.doseUL, rateULmin: spec.rateULmin || 5, times: spec.times, singleMaxUL: spec.singleMaxUL, dailyCapUL: spec.dailyCapUL, minIntervalMin: spec.minIntervalMin }]
    };
  };
  E.signAndInstallPlan = async function (env, spec, now) {
    const plan = E.buildPlan(env, spec, now);
    const env_ = await SEC.signPlan(env.S.doctor.privateJwk, plan);
    return env.gate.installPlan(env_, now);
  };
  E.issueCommand = async function (env, o, now, keyOverride) {
    const S = env.S, key = keyOverride || S.doctor;
    S.seq += 1;
    const cmd = SEC.nextCmd({ keyId: key.keyId, deviceId: S.device.deviceId, patientId: S.patient.id, seq: S.seq, now }, Object.assign({ substance: E.SUBSTANCE }, o));
    return SEC.signCmd(key.privateJwk, cmd);
  };
  E.sendCommand = async function (env, o, now) {
    const e = await E.issueCommand(env, o, now);
    const r = await env.gate.execute(e, now);
    if (r.ok !== false || r.code === 'HALTED_FLOW_MISMATCH' || r.status) env.S.lastEnv = e;
    return r;
  };
  E.provisionDoctor = async function (env, now) {
    const kp = await C.generateKeyPair();
    env.S.doctor = { name: 'د. ريم (طبيبة افتراضية)', keyId: kp.keyId, publicJwk: kp.publicJwk, privateJwk: kp.privateJwk };
    env.gate.provisionKey(kp.keyId, kp.publicJwk, now);
  };

  // ---- مختبر الأمان: كل هجوم يُرجع {name, expected, got, pass} ----
  E.attacks = [
    { id: 'replay', name: 'إعادة إرسال أمر قديم', expected: ['REPLAY_NONCE'] },
    { id: 'tamper', name: 'تعديل الجرعة بعد التوقيع', expected: ['BAD_SIGNATURE'] },
    { id: 'expired', name: 'أمر منتهي الصلاحية', expected: ['EXPIRED'] },
    { id: 'revoked', name: 'مفتاح طبيب مُلغى', expected: ['KEY_REVOKED'] },
    { id: 'unknown', name: 'مفتاح غير معروف للجهاز', expected: ['UNKNOWN_KEY'] },
    { id: 'overdose', name: 'جرعة فوق الحد الأقصى للجرعة الواحدة', expected: ['DOSE_OVER_SINGLE_MAX'] },
    { id: 'limit', name: 'جرعة خارج السقف اليومي/الفاصل الزمني', expected: ['DAILY_CAP_EXCEEDED', 'MIN_INTERVAL'] },
    { id: 'ai', name: 'أمر من الذكاء الاصطناعي بلا توقيع', expected: ['UNSIGNED'] },
    { id: 'wrongdev', name: 'أمر موقَّع لجهاز آخر', expected: ['WRONG_DEVICE'] },
    { id: 'rollback', name: 'خطة بإصدار أقدم (رجوع للخلف)', expected: ['PLAN_ROLLBACK'] },
    { id: 'audit', name: 'العبث بسجل التدقيق', expected: ['CHAIN_BROKEN'] }
  ];
  E.runAttack = async function (env, id, now) {
    const { S, gate } = env;
    const def = E.attacks.find(a => a.id === id);
    let r;
    const fresh = async (o, t) => E.issueCommand(env, Object.assign({ doseUL: 10 }, o), t || now);
    if (id === 'replay') {
      // أمر صالح أولاً ثم إعادته حرفياً
      const e = await fresh({ doseUL: 5 });
      await gate.execute(e, now);
      r = await gate.execute(e, now + U.MIN);
    } else if (id === 'tamper') {
      const e = await fresh({ doseUL: 10 }); e.cmd = Object.assign({}, e.cmd, { doseUL: 45 });
      r = await gate.execute(e, now);
    } else if (id === 'expired') {
      const e = await fresh({ issuedAt: now - 20 * U.MIN, expiresAt: now - 10 * U.MIN });
      r = await gate.execute(e, now);
    } else if (id === 'revoked') {
      const kp = await C.generateKeyPair(); const ks = { keyId: kp.keyId, privateJwk: kp.privateJwk };
      gate.provisionKey(kp.keyId, kp.publicJwk, now); gate.revokeKey(kp.keyId, now);
      r = await gate.execute(await E.issueCommand(env, { doseUL: 10 }, now, ks), now);
    } else if (id === 'unknown') {
      const kp = await C.generateKeyPair();
      r = await gate.execute(await E.issueCommand(env, { doseUL: 10 }, now, { keyId: kp.keyId, privateJwk: kp.privateJwk }), now);
    } else if (id === 'overdose') {
      r = await gate.execute(await fresh({ doseUL: 45 }), now);
    } else if (id === 'limit') {
      const item = S.gate.plan && S.gate.plan.items[0];
      const room = item ? item.dailyCapUL - gate.deliveredToday(item.substance, now) : 0;
      // جرعة ضمن الحد الواحد لكنها تتجاوز المتبقي أو تخالف الفاصل
      r = await gate.execute(await fresh({ doseUL: item ? Math.min(item.singleMaxUL, Math.max(item.singleMaxUL, room + 1)) : 10 }), now);
    } else if (id === 'ai') {
      r = await gate.execute({ cmd: { cmdId: 'AI-1', keyId: 'ai-engine', substance: E.SUBSTANCE, doseUL: 10 }, sig: null }, now);
    } else if (id === 'wrongdev') {
      const e = await SEC.signCmd(S.doctor.privateJwk, SEC.nextCmd({ keyId: S.doctor.keyId, deviceId: 'OVA-POD-9999', patientId: S.patient.id, seq: ++S.seq, now }, { substance: E.SUBSTANCE, doseUL: 10 }));
      r = await gate.execute(e, now);
    } else if (id === 'rollback') {
      const cur = S.gate.plan; const old = Object.assign({}, cur, { version: cur.version, planId: 'OLD' });
      r = await gate.installPlan(await SEC.signPlan(S.doctor.privateJwk, old), now);
    } else if (id === 'audit') {
      const clone = JSON.parse(JSON.stringify(S.gate.audit));
      if (clone.length > 3) clone[Math.floor(clone.length / 2)].detail = 'تم العبث';
      const v = SEC.verifyChain(clone);
      r = { ok: false, code: v.ok ? 'CHAIN_OK' : 'CHAIN_BROKEN', label: v.ok ? 'السلسلة سليمة' : 'اكتشاف العبث عند السجل #' + v.brokenAt, brokenAt: v.brokenAt };
    }
    const got = r.ok === false || r.code ? (r.code || r.status) : 'ACCEPTED';
    return { id, name: def.name, expected: def.expected, got, label: r.label || '', pass: def.expected.includes(got) };
  };

  // ---- أدوات مشتقة ----
  E.nextDose = function (plan, now) {
    if (!plan || now > plan.expiresAt) return null;
    let best = null;
    for (let d = 0; d < 2; d++) {
      const base = U.dayStart(now) + d * U.DAY;
      for (const it of plan.items) for (const tm of it.times) {
        const due = base + U.parseHM(tm);
        if (due > now && (!best || due < best.t)) best = { t: due, substance: it.substance, doseUL: it.doseUL, when: U.fmtDT(due) };
      }
    }
    return best;
  };
  E.latest = (S, type) => { for (let i = S.readings.length - 1; i >= 0; i--) if (S.readings[i].type === type) return S.readings[i]; return null; };

  E.derive = function (env, now) {
    const { S, device, gate } = env;
    now = now || S.clock.now;
    const plan = gate.s.plan;
    const stats7 = AI.glucoseStats(S.readings, now - 7 * U.DAY, now, S.range);
    const stats1 = AI.glucoseStats(S.readings, now - U.DAY, now, S.range);
    const quality = AI.signalQuality(S.readings, now, 6);
    const bleeding = AI.bleedingAnalysis(S.bleeding, now);
    const fastDays = AI.fastingByDay(S.readings.filter(r => r.t > now - 7 * U.DAY));
    const fastingHighDays = fastDays.filter(f => f.mean > S.fastingThreshold).length;
    const age = device.ageDays(now);
    const calibratedThisPatch = !!(S.device.calib && S.device.patchAppliedAt && S.device.calib.t >= S.device.patchAppliedAt);
    const bloodNeed = AI.bloodTestNeed({ now, lastLabT: S.labs.lastLabT, labIntervalDays: S.labs.labIntervalDays, patchAgeDays: age, calibratedThisPatch, quality, stats: stats7, fastingHighDays, bleedingUrgent: bleeding.urgent });
    const alerts = device.alerts(now);
    const adherencePct = AI.adherence(plan, gate.s.deliveries, now, 7);
    const lg = E.latest(S, 'glucose');
    const wRead = E.latest(S, 'weight');
    const weight = wRead ? wRead.value : S.patient.weightKg;
    const fgBase = fastDays.length ? U.round(U.mean(fastDays.map(f => f.mean)), 1) : 95;
    const twinBase = { weightKg: weight, heightCm: S.patient.heightCm, fastingGlucose: fgBase, fastingInsulin: S.labs.fastingInsulin, horizonDays: S.twin.horizon };
    const tw = S.twin;
    const twinRes = TW.simulate(Object.assign({}, twinBase, { deficitKcal: tw.deficit, activityMinPerWeek: tw.act, adherence: tw.adh / 100, fgAssumption: tw.fgAssumption }));
    const corr = AI.symptomCorrelation(S.symptoms, S.readings);
    const diet = AI.dietPlan({ weightKg: weight, heightCm: S.patient.heightCm, age: S.patient.age, activity: S.patient.activity, goal: S.patient.goal }, Math.floor(now / U.DAY));
    const starts = bleeding.episodes.filter(e => !e.spottingOnly).map(e => e.start);
    const fert = F.analyze(starts, S.fertility, now);
    const hM = S.patient.heightCm / 100, bmiV = hM > 0 ? weight / (hM * hM) : null;
    const bmi = bmiV == null ? null : { v: U.round(bmiV, 1), cat: bmiV < 18.5 ? 'نحافة' : bmiV < 25 ? 'وزن طبيعي' : bmiV < 30 ? 'زيادة وزن' : 'سمنة' };
    const review = AI.dosePlanReview({ plan, stats: stats7, quality, adherencePct, deviceAlerts: alerts });
    return {
      name: S.patient.name, now, fert, bmi, doctorNote: S.doctorNote, plan, stats7, stats1, quality, bleeding, fastingHighDays, bloodNeed, alerts, adherencePct, corr, diet, review, weight, twinBase, twinRes,
      latestGlucose: lg ? { value: lg.value, q: lg.q, when: U.hhmm(lg.t) } : null,
      latestHM1: E.latest(S, 'hm1'), nextDose: E.nextDose(plan, now),
      deliveredTodayUL: plan ? gate.deliveredToday(plan.items[0].substance, now) : null,
      deviceBrief: 'البطارية ' + U.round(S.device.batteryPct) + '%، الخزان ' + U.round(S.device.reservoirUL) + ' µL.',
      twin: { name: 'نظام + نشاط', horizonDays: twinRes.summary.horizonDays, weightEnd: twinRes.summary.weightEnd, weightBand: twinRes.summary.weightBand, fgEnd: twinRes.summary.fgEnd, fgBand: twinRes.summary.fgBand },
      meds: S.patient.meds, pregnant: S.patient.pregnant, hypertension: S.patient.hypertension
    };
  };

  // ---- بيانات العرض التجريبي (تركيبية) ----
  E.seedDemo = async function (now) {
    const S = E.newState(0), env = E.attach(S);
    const today = U.dayStart(now), start = today - 14 * U.DAY;
    S.clock.now = start; S.clock.lastT = start; S.demo = true;
    const rng = U.rng(77);
    // وجبات
    const dayCarbs = {};
    for (let d = 0; d <= 14; d++) {
      const ds = start + d * U.DAY;
      const add = (h, name, c) => { const t = ds + h * U.HOUR + Math.floor(rng() * 20) * U.MIN; if (t <= now) { S.meals.push({ t, name, carbs: c }); dayCarbs[U.dayKey(ds)] = (dayCarbs[U.dayKey(ds)] || 0) + c; } };
      add(8, 'فطور', 35 + Math.round(rng() * 25));
      add(13.5, 'غداء', 55 + Math.round(rng() * 35));
      add(20, 'عشاء', 40 + Math.round(rng() * 30));
      if (rng() < 0.5) add(16.5, 'وجبة خفيفة', 20 + Math.round(rng() * 25));
    }
    S.meals.sort((a, b) => a.t - b.t);
    await E.provisionDoctor(env, start);
    const spec = { issuedAt: start - U.HOUR, expiresAt: now + 60 * U.DAY, doseUL: 25, times: ['07:00', '12:00', '17:00', '22:00'], singleMaxUL: 30, dailyCapUL: 110, minIntervalMin: 180 };
    const pr = await E.signAndInstallPlan(env, spec, start);
    if (!pr.ok) throw new Error('plan install failed ' + pr.code);
    // الرقعة 1 (يوم 0) والرقعة 2 (يوم 7)
    E.advance(env, start + 6.5 * U.HOUR); env.device.applyPatch(start + 6.5 * U.HOUR);
    E.advance(env, start + 3 * U.DAY + 8 * U.HOUR);
    E.addReading(env, 'lab_glucose', 92); // معايرة بقياس دم
    E.advance(env, start + 7 * U.DAY + 6.5 * U.HOUR); env.device.applyPatch(start + 7 * U.DAY + 6.5 * U.HOUR);
    gate_note(env, start + 7 * U.DAY + 6.5 * U.HOUR);
    E.advance(env, now);
    // أعراض يومية (ترتبط جزئياً بكربوهيدرات اليوم — بيانات تركيبية)
    for (let d = 0; d < 14; d++) {
      const k = U.dayKey(start + d * U.DAY), c = dayCarbs[k] || 120;
      const sc = (base) => U.clamp(Math.round(base + (c - 140) / 70 + (rng() - 0.5) * 1.6), 0, 3);
      S.symptoms.push({ date: k, acne: sc(1), hirsutism: U.clamp(Math.round(1 + (rng() - 0.5) * 1.2), 0, 3), fatigue: sc(1), mood: sc(1), cramps: U.clamp(Math.round(rng() * 1.5), 0, 3) });
    }
    // نزيف: دورتان (طول الدورة 39 يوماً)
    const bd = (offset, o) => S.bleeding.push(Object.assign({ date: U.dayKey(today + offset * U.DAY) }, o));
    const ep = (startOff, plan) => plan.forEach((o, i) => bd(startOff + i, o));
    ep(-54, [{ pads: { m: 3 } }, { pads: { m: 4, s: 1 }, clotsS: 1 }, { pads: { m: 3 } }, { pads: { l: 3 } }, { pads: { l: 2 } }]);
    ep(-15, [{ pads: { m: 3 } }, { pads: { m: 3, s: 1 } }, { pads: { m: 2, l: 2 } }, { pads: { l: 3 } }, { pads: { l: 2 } }, { spotting: true, pads: { l: 1 } }]);
    // وزن ومعطيات مخبرية
    S.readings.push({ t: start + 2 * U.HOUR, type: 'weight', value: 78.4, src: 'manual' }, { t: start + 7 * U.DAY + 2 * U.HOUR, type: 'weight', value: 78.1, src: 'manual' }, { t: today + 2 * U.HOUR <= now ? today + 2 * U.HOUR : now - U.HOUR, type: 'weight', value: 77.8, src: 'manual' });
    S.labs = { lastLabT: now - 100 * U.DAY, fastingInsulin: 14, hba1c: 5.6, labIntervalDays: 90 };
    S.clock.now = now; S.onboarded = false;
    return env;
  };
  function gate_note(env, t) { env.gate.audit(t, 'DEVICE', 'PATCH_APPLIED', 'رقعة جديدة'); }

  g.OvaEngine = E;
  if (typeof module !== 'undefined' && module.exports) module.exports = E;
})(globalThis);
