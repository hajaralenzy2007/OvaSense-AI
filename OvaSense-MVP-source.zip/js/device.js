/* OvaDevice — محاكي الجهاز (قرص إلكتروني + رقعة). بيانات تركيبية لأغراض العرض فقط. */
(function (g) {
  'use strict';
  const U = g.OvaUtil;
  const D = {};
  D.HARD = { singleMaxUL: 50, dailyMaxUL: 200 };       // حدود صلبة في برنامج الجهاز لا يتجاوزها أي مخطط
  D.PATCH_LIFE_DAYS = 7;
  D.RESERVOIR_UL = 1000;
  D.LOW_RESERVOIR_UL = 150;

  D.newState = function (seed) {
    return {
      deviceId: 'OVA-POD-0001', seed: seed || 20260, patchApplied: false, patchAppliedAt: null,
      reservoirUL: 0, batteryPct: 100, bleUp: true, faultLatched: null,
      faults: { occlusion: false, overflow: false, driftFast: false },
      driftPerDay: 0.012, calib: null, baseGlucose: 94
    };
  };

  D.create = function (state, getMeals) {
    const s = state;
    const dev = { state: s };
    const meals = () => (getMeals ? getMeals() : []);

    dev.ageDays = t => s.patchApplied ? Math.max(0, (t - s.patchAppliedAt) / U.DAY) : 0;
    dev.drift = () => s.faults.driftFast ? 0.05 : s.driftPerDay;

    dev.applyPatch = t => {
      s.patchApplied = true; s.patchAppliedAt = t; s.reservoirUL = D.RESERVOIR_UL;
      s.calib = null; s.faultLatched = null; s.batteryPct = 100;
    };
    dev.removePatch = () => { s.patchApplied = false; s.patchAppliedAt = null; s.reservoirUL = 0; s.calib = null; };
    dev.clearFault = () => { s.faultLatched = null; s.faults.occlusion = false; s.faults.overflow = false; };
    dev.tick = dtMin => { if (s.patchApplied) s.batteryPct = Math.max(0, s.batteryPct - 0.004 * dtMin); };

    // الجلوكوز «الحقيقي» (نموذج وجبات: استجابة غاما مبسّطة)
    dev.trueGlucose = t => {
      const h = U.hour(t);
      let gl = s.baseGlucose + 3 * Math.sin(2 * Math.PI * (h - 4) / 24);
      const dayN = U.gauss(U.rng((s.seed ^ Math.floor(U.dayStart(t) / U.DAY)) >>> 0));
      gl += 2.5 * dayN;
      for (const m of meals()) {
        const x = (t - m.t) / (50 * U.MIN);
        if (x >= 0 && x < 8) gl += m.carbs * 0.9 * x * Math.exp(1 - x);
      }
      return gl;
    };
    const noiseAt = t => {
      const r = U.rng((s.seed + Math.floor(t / U.MIN) * 2654435761) >>> 0);
      return U.gauss(r);
    };

    // قراءة السائل الخلالي: تأخر ~7 دقائق، انجراف الحساسية مع عمر الرقعة، ضجيج، ومعايرة بقياس دم
    dev.rawSens = t => {
      const age = dev.ageDays(t);
      return Math.max(0.3, 1 - dev.drift() * age);
    };
    dev.senseGlucose = t => {
      if (!s.patchApplied) return null;
      const age = dev.ageDays(t);
      const lagged = dev.trueGlucose(t - 7 * U.MIN);
      let sens = dev.rawSens(t);
      let ageEff = age;
      if (s.calib) { sens = sens / dev.rawSens(s.calib.t) * s.calib.factor; ageEff = Math.max(0, age - dev.ageDays(s.calib.t)); }
      const value = lagged * sens + noiseAt(t) * 2.0 * (1 + age * 0.04);
      const q = U.clamp(1 - ageEff * dev.drift() * 4 - (s.faults.driftFast ? 0.1 : 0), 0, 1);
      return { value: U.round(value, 1), q: U.round(q, 2) };
    };
    // معايرة بقياس دم مرجعي (إصبع/مختبر)
    dev.calibrate = (t, ref) => {
      if (!s.patchApplied) return false;
      const raw = dev.trueGlucose(t - 7 * U.MIN) * dev.rawSens(t);
      s.calib = { t, factor: U.clamp(ref / raw, 0.8, 1.25) };
      return true;
    };
    // مؤشر هرموني HM1 (وحدات اعتباطية): يُحدَّد المؤشر الفعلي بعد مرحلة التحقق
    dev.senseHM1 = t => {
      if (!s.patchApplied) return null;
      const v = 50 + 7 * Math.sin(2 * Math.PI * t / U.DAY) + 5 * Math.sin(2 * Math.PI * t / (28 * U.DAY)) + 1.5 * noiseAt(t + 17);
      return U.round(v, 1);
    };

    // التوصيل: حقن مُوجَّه + مراقبة تدفق (المأمور مقابل المقاس)
    dev.deliver = (now, doseUL, rateULmin) => {
      const rate = rateULmin || 5;
      if (!s.patchApplied) return { ok: false, status: 'NO_PATCH', commandedUL: doseUL, deliveredUL: 0 };
      let factor = 1 + 0.03 * U.gauss(U.rng((s.seed + Math.floor(now / U.MIN)) >>> 0));
      if (s.faults.occlusion) factor = 0.02;
      if (s.faults.overflow) factor = 1.35;
      const measuredFull = doseUL * factor;
      const dev_ = (measuredFull - doseUL) / doseUL;
      if (Math.abs(dev_) > 0.20) {
        const delivered = U.round(Math.min(doseUL * 0.2 * Math.max(0, factor), doseUL), 2);
        s.reservoirUL = Math.max(0, s.reservoirUL - delivered);
        s.faultLatched = 'FLOW_MISMATCH';
        return { ok: false, status: 'HALTED_FLOW_MISMATCH', commandedUL: doseUL, deliveredUL: delivered, measuredUL: U.round(measuredFull, 2), deviationPct: U.round(dev_ * 100, 1), durationMin: U.round(doseUL / rate * 0.2, 2) };
      }
      const delivered = U.round(measuredFull, 2);
      s.reservoirUL = Math.max(0, s.reservoirUL - delivered);
      return { ok: true, status: 'DELIVERED', commandedUL: doseUL, deliveredUL: delivered, measuredUL: delivered, deviationPct: U.round(dev_ * 100, 1), durationMin: U.round(doseUL / rate, 2) };
    };

    dev.alerts = now => {
      const a = [];
      if (!s.patchApplied) a.push({ lvl: 'warn', code: 'NO_PATCH', text: 'لا توجد رقعة مركّبة.' });
      else {
        const age = dev.ageDays(now);
        if (age >= D.PATCH_LIFE_DAYS) a.push({ lvl: 'warn', code: 'PATCH_EXPIRED', text: 'انتهى العمر التصميمي للرقعة (' + D.PATCH_LIFE_DAYS + ' أيام): يُنصح باستبدالها.' });
        if (s.reservoirUL <= D.LOW_RESERVOIR_UL) a.push({ lvl: 'warn', code: 'RESERVOIR_LOW', text: 'الخزان منخفض (' + U.round(s.reservoirUL) + ' µL).' });
        const sg = dev.senseGlucose(now);
        if (sg && sg.q < 0.6) a.push({ lvl: 'warn', code: 'SIGNAL_POOR', text: 'جودة الإشارة منخفضة؛ يُنصح بقياس دم مرجعي للمعايرة.' });
      }
      if (s.faultLatched) a.push(s.faultLatched === 'USER_STOP' ? { lvl: 'warn', code: 'USER_STOP', text: 'أوقفتِ التوصيل يدوياً (إيقاف طارئ). لن تُنفَّذ أي جرعة حتى تستأنفي. إن كان السبب أعراضاً فتواصلي مع طبيبك.' } : { lvl: 'danger', code: s.faultLatched, text: 'توقّف التوصيل تلقائياً: عدم تطابق التدفق المقاس مع المأمور به. يلزم تدخل.' });
      if (s.batteryPct <= 15) a.push({ lvl: 'warn', code: 'BATTERY_LOW', text: 'البطارية منخفضة (' + U.round(s.batteryPct) + '%).' });
      if (!s.bleUp) a.push({ lvl: 'info', code: 'BLE_DOWN', text: 'انقطاع اتصال البلوتوث؛ يستمر الجهاز بالمخطط الموقَّع وفق السياسة.' });
      return a;
    };
    return dev;
  };

  g.OvaDevice = D;
  if (typeof module !== 'undefined' && module.exports) module.exports = D;
})(globalThis);
