/* OvaKitchen — وجبة من المكوّنات الموجودة: تسجّل المريضة ما لديها، فتقترح وصفات تناسب خطتها اليومية.
   قواعد محلية فقط (لا خادم). القيم الغذائية تقريبية لكل حصة وتحتاج مراجعة أخصائية تغذية. */
(function (g) {
  'use strict';
  const U = g.OvaUtil;
  const K = {};

  // المكوّنات: id، الاسم، ومرادفات للبحث
  K.INGREDIENTS = [
    { id: 'egg', ar: 'بيض', syn: ['بيض', 'بيضه', 'بيضة', 'egg'] },
    { id: 'chicken', ar: 'دجاج', syn: ['دجاج', 'صدر دجاج', 'فراخ', 'chicken'] },
    { id: 'fish', ar: 'سمك', syn: ['سمك', 'هامور', 'سلمون', 'fish'] },
    { id: 'tuna', ar: 'تونة', syn: ['تونه', 'تونة', 'tuna'] },
    { id: 'meat', ar: 'لحم', syn: ['لحم', 'لحمه', 'لحم احمر', 'مفروم', 'meat'] },
    { id: 'lentil', ar: 'عدس', syn: ['عدس', 'lentil'] },
    { id: 'chickpea', ar: 'حمص', syn: ['حمص', 'chickpea'] },
    { id: 'beans', ar: 'فول', syn: ['فول', 'فاصوليا', 'beans'] },
    { id: 'oats', ar: 'شوفان', syn: ['شوفان', 'oats'] },
    { id: 'brownrice', ar: 'أرز بني', syn: ['رز بني', 'ارز بني', 'brown rice'] },
    { id: 'rice', ar: 'أرز أبيض', syn: ['رز', 'ارز', 'رز ابيض', 'ارز ابيض', 'rice'] },
    { id: 'quinoa', ar: 'كينوا', syn: ['كينوا', 'quinoa'] },
    { id: 'bread', ar: 'خبز بر', syn: ['خبز', 'خبز بر', 'خبز اسمر', 'توست', 'bread'] },
    { id: 'sweetpotato', ar: 'بطاطا حلوة', syn: ['بطاطا حلوه', 'بطاطا حلوة', 'sweet potato'] },
    { id: 'potato', ar: 'بطاطس', syn: ['بطاطس', 'بطاطا', 'potato'] },
    { id: 'yogurt', ar: 'زبادي', syn: ['زبادي', 'لبن', 'روب', 'yogurt'] },
    { id: 'labneh', ar: 'لبنة', syn: ['لبنه', 'لبنة'] },
    { id: 'cheese', ar: 'جبن', syn: ['جبن', 'جبنه', 'جبن قريش', 'فيتا', 'cheese'] },
    { id: 'milk', ar: 'حليب', syn: ['حليب', 'milk'] },
    { id: 'tomato', ar: 'طماطم', syn: ['طماطم', 'بندوره', 'tomato'] },
    { id: 'cucumber', ar: 'خيار', syn: ['خيار', 'cucumber'] },
    { id: 'onion', ar: 'بصل', syn: ['بصل', 'onion'] },
    { id: 'garlic', ar: 'ثوم', syn: ['ثوم', 'garlic'] },
    { id: 'spinach', ar: 'سبانخ', syn: ['سبانخ', 'spinach'] },
    { id: 'lettuce', ar: 'خس', syn: ['خس', 'جرجير', 'lettuce'] },
    { id: 'pepper', ar: 'فلفل رومي', syn: ['فلفل', 'فلفل رومي', 'فلفل الوان', 'pepper'] },
    { id: 'zucchini', ar: 'كوسة', syn: ['كوسه', 'كوسا', 'كوسة', 'zucchini'] },
    { id: 'eggplant', ar: 'باذنجان', syn: ['باذنجان', 'eggplant'] },
    { id: 'carrot', ar: 'جزر', syn: ['جزر', 'carrot'] },
    { id: 'broccoli', ar: 'بروكلي', syn: ['بروكلي', 'قرنبيط', 'زهره', 'broccoli'] },
    { id: 'mushroom', ar: 'فطر', syn: ['فطر', 'مشروم', 'mushroom'] },
    { id: 'lemon', ar: 'ليمون', syn: ['ليمون', 'lemon'] },
    { id: 'oliveoil', ar: 'زيت زيتون', syn: ['زيت زيتون', 'زيت', 'olive oil'] },
    { id: 'nuts', ar: 'مكسرات', syn: ['مكسرات', 'لوز', 'جوز', 'عين جمل', 'nuts'] },
    { id: 'apple', ar: 'تفاح', syn: ['تفاح', 'تفاحه', 'apple'] },
    { id: 'banana', ar: 'موز', syn: ['موز', 'banana'] },
    { id: 'berries', ar: 'توت', syn: ['توت', 'فراوله', 'فراولة', 'berries'] },
    { id: 'dates', ar: 'تمر', syn: ['تمر', 'dates'] },
    { id: 'chia', ar: 'بذور الشيا', syn: ['شيا', 'بذور الشيا', 'chia'] },
    { id: 'tahini', ar: 'طحينة', syn: ['طحينه', 'طحينة', 'tahini'] }
  ];
  // مكونات أساسية تُفترض متوفرة دائماً (بهارات/ملح/ماء)
  K.STAPLES = ['ملح وبهارات', 'ماء'];

  // slot: b فطور، l غداء/عشاء، s خفيفة. need: مكونات أساسية، opt: اختيارية. القيم لحصة واحدة (تقريبية).
  K.RECIPES = [
    { id: 'shakshuka', ar: 'شكشوكة بالخضار', slot: 'b', need: ['egg', 'tomato'], opt: ['onion', 'pepper', 'spinach', 'oliveoil', 'bread'], kcal: 260, carb: 14, protein: 15, fiber: 4, gi: 'منخفض', steps: 'شوّحي البصل والفلفل بملعقة صغيرة زيت، أضيفي الطماطم 5 دقائق ثم البيض وغطّي حتى ينضج.' },
    { id: 'omelette', ar: 'أومليت سبانخ وفطر', slot: 'b', need: ['egg'], opt: ['spinach', 'mushroom', 'cheese', 'onion', 'oliveoil'], kcal: 220, carb: 5, protein: 16, fiber: 2, gi: 'منخفض', steps: 'اخفقي بيضتين، أضيفي الخضار المقطعة، واطهي على نار هادئة.' },
    { id: 'oats_bowl', ar: 'شوفان بالزبادي والتوت', slot: 'b', need: ['oats'], opt: ['yogurt', 'milk', 'berries', 'chia', 'nuts', 'apple'], kcal: 290, carb: 40, protein: 13, fiber: 7, gi: 'منخفض', steps: 'انقعي نصف كوب شوفان في حليب أو زبادي، وأضيفي التوت والشيا. تجنبي السكر المضاف.' },
    { id: 'foul_plate', ar: 'فول بزيت الزيتون والخضار', slot: 'b', need: ['beans'], opt: ['tomato', 'cucumber', 'lemon', 'oliveoil', 'bread', 'garlic'], kcal: 280, carb: 33, protein: 13, fiber: 10, gi: 'منخفض', steps: 'سخّني الفول مع الثوم والليمون، وأضيفي ملعقة صغيرة زيت زيتون وخضاراً طازجة.' },
    { id: 'labneh_plate', ar: 'لبنة مع خضار وخبز بر', slot: 'b', need: ['labneh'], opt: ['cucumber', 'tomato', 'bread', 'oliveoil', 'egg'], kcal: 240, carb: 22, protein: 12, fiber: 4, gi: 'منخفض', steps: 'قدّمي ملعقتين لبنة مع شريحة خبز بر وخضار طازجة.' },
    { id: 'chicken_quinoa', ar: 'صدر دجاج مع كينوا وخضار', slot: 'l', need: ['chicken'], opt: ['quinoa', 'brownrice', 'broccoli', 'carrot', 'zucchini', 'lemon', 'garlic', 'oliveoil'], kcal: 450, carb: 38, protein: 38, fiber: 7, gi: 'منخفض', steps: 'اشوي الدجاج بالليمون والثوم، وقدّميه مع نصف كوب كينوا وطبق خضار مطهوة على البخار.' },
    { id: 'fish_veg', ar: 'سمك مشوي مع خضار وبطاطا حلوة', slot: 'l', need: ['fish'], opt: ['sweetpotato', 'zucchini', 'pepper', 'lemon', 'garlic', 'oliveoil', 'lettuce'], kcal: 420, carb: 34, protein: 32, fiber: 6, gi: 'منخفض', steps: 'اشوي السمك بالليمون، والبطاطا الحلوة شرائح في الفرن، مع سلطة.' },
    { id: 'lentil_soup', ar: 'شوربة عدس بالخضار', slot: 'l', need: ['lentil'], opt: ['onion', 'carrot', 'garlic', 'lemon', 'tomato', 'zucchini'], kcal: 300, carb: 42, protein: 18, fiber: 14, gi: 'منخفض', steps: 'اسلقي العدس مع البصل والجزر والثوم 25 دقيقة، واخلطيها وأضيفي الليمون.' },
    { id: 'chickpea_salad', ar: 'سلطة حمص وتونة', slot: 'l', need: ['chickpea'], opt: ['tuna', 'cucumber', 'tomato', 'lettuce', 'lemon', 'oliveoil', 'onion'], kcal: 380, carb: 34, protein: 28, fiber: 10, gi: 'منخفض', steps: 'اخلطي الحمص المسلوق مع التونة والخضار، وتبّلي بالليمون وملعقة صغيرة زيت.' },
    { id: 'tuna_salad', ar: 'سلطة تونة خضراء', slot: 'l', need: ['tuna'], opt: ['lettuce', 'cucumber', 'tomato', 'lemon', 'oliveoil', 'egg', 'bread'], kcal: 300, carb: 12, protein: 30, fiber: 4, gi: 'منخفض', steps: 'صفّي التونة واخلطيها مع الخضار والليمون. أضيفي بيضة مسلوقة لبروتين أعلى.' },
    { id: 'meat_eggplant', ar: 'مسقعة خفيفة باللحم والباذنجان', slot: 'l', need: ['meat', 'eggplant'], opt: ['tomato', 'onion', 'garlic', 'pepper', 'oliveoil'], kcal: 430, carb: 20, protein: 30, fiber: 8, gi: 'منخفض', steps: 'اشوي الباذنجان في الفرن بدل قليه، واطهي اللحم المفروم قليل الدهن مع الطماطم، ثم اجمعيهما.' },
    { id: 'stir_fry', ar: 'دجاج مقلّب بالخضار مع أرز بني', slot: 'l', need: ['chicken', 'brownrice'], opt: ['broccoli', 'pepper', 'carrot', 'mushroom', 'garlic', 'onion'], kcal: 470, carb: 45, protein: 36, fiber: 6, gi: 'متوسط', steps: 'قلّبي الدجاج والخضار بملعقة صغيرة زيت على نار عالية، وقدّميه مع نصف كوب أرز بني.' },
    { id: 'stuffed_zucchini', ar: 'كوسة محشية بالعدس', slot: 'l', need: ['zucchini', 'lentil'], opt: ['tomato', 'onion', 'garlic', 'rice'], kcal: 340, carb: 44, protein: 16, fiber: 11, gi: 'منخفض', steps: 'احشي الكوسة بالعدس المطبوخ والطماطم، واخبزيها 30 دقيقة.' },
    { id: 'yogurt_snack', ar: 'زبادي مع مكسرات وتوت', slot: 's', need: ['yogurt'], opt: ['nuts', 'berries', 'chia', 'apple'], kcal: 200, carb: 18, protein: 12, fiber: 3, gi: 'منخفض', steps: 'كوب زبادي سادة مع حفنة صغيرة مكسرات وتوت.' },
    { id: 'apple_tahini', ar: 'تفاح مع طحينة', slot: 's', need: ['apple'], opt: ['tahini', 'nuts'], kcal: 180, carb: 26, protein: 4, fiber: 5, gi: 'منخفض', steps: 'شرائح تفاح مع ملعقة صغيرة طحينة. البروتين والدهون الصحية تبطئ امتصاص السكر.' },
    { id: 'veg_sticks', ar: 'أصابع خضار مع حمص مهروس', slot: 's', need: ['chickpea'], opt: ['carrot', 'cucumber', 'tahini', 'lemon', 'garlic'], kcal: 170, carb: 18, protein: 7, fiber: 6, gi: 'منخفض', steps: 'اهرسي الحمص بالطحينة والليمون، وقدّميه مع جزر وخيار.' },
    { id: 'dates_nuts', ar: 'تمرتان مع لوز', slot: 's', need: ['dates'], opt: ['nuts', 'milk'], kcal: 190, carb: 30, protein: 4, fiber: 4, gi: 'متوسط', steps: 'تمرتان مع 6–8 حبات لوز لتخفيف ارتفاع السكر.' }
  ];

  K.SLOTS = { b: 'الفطور', l: 'الغداء أو العشاء', s: 'وجبة خفيفة' };

  // تحويل نص حر إلى مكونات معروفة
  K.parse = function (text) {
    const parts = String(text || '').split(/[،,\n؛;+]/).map(s => U.normAr(s).trim()).filter(Boolean);
    const ids = new Set(), unknown = [];
    const lookup = phrase => K.INGREDIENTS.find(i => i.syn.some(s => U.normAr(s) === phrase));
    parts.forEach(p => {
      // كلمات مفصولة بمسافة أو «و»؛ نطابق العبارات الأطول أولاً حتى لا تُحسب «رز بني» كـ«رز»
      const w = p.split(/\s+/).filter(x => x && x !== 'و').map(x => x.length > 2 && x[0] === 'و' && !lookup(x) && K.INGREDIENTS.some(i => i.syn.some(s => U.normAr(s).split(' ')[0] === x.slice(1))) ? x.slice(1) : x);
      let i = 0;
      while (i < w.length) {
        let hit = null, len = 0;
        for (let n = Math.min(3, w.length - i); n >= 1 && !hit; n--) { const ing = lookup(w.slice(i, i + n).join(' ')); if (ing) { hit = ing; len = n; } }
        if (hit) { ids.add(hit.id); i += len; } else { unknown.push(w[i]); i++; }
      }
    });
    return { ids: [...ids], unknown };
  };

  // هدف السعرات للوجبة من الخطة اليومية
  K.slotTarget = function (plan, slot) {
    if (!plan || !plan.meals) return null;
    const m = slot === 'b' ? plan.meals.filter(x => x.slot === 'b') : slot === 's' ? plan.meals.filter(x => x.slot === 's1' || x.slot === 's2') : plan.meals.filter(x => x.slot === 'l' || x.slot === 'd');
    if (!m.length) return null;
    return Math.round(m.reduce((a, x) => a + x.kcal, 0) / m.length);
  };

  // اقتراح وصفات: كل المكونات الأساسية متوفرة، أو ينقص مكوّن واحد فقط (يُذكر)
  K.suggest = function (have, opts) {
    opts = opts || {};
    const H = new Set(have || []), out = [];
    K.RECIPES.forEach(r => {
      if (opts.slot && opts.slot !== 'any' && r.slot !== opts.slot) return;
      const missing = r.need.filter(n => !H.has(n));
      if (missing.length > 1 || (missing.length === 1 && r.need.length === 1)) return;
      const used = r.need.filter(n => H.has(n)).concat(r.opt.filter(n => H.has(n)));
      const optCover = r.opt.length ? r.opt.filter(n => H.has(n)).length / r.opt.length : 1;
      const target = opts.plan ? K.slotTarget(opts.plan, r.slot) : null;
      const servings = target ? U.clamp(Math.round(target / r.kcal * 4) / 4, 0.5, 1.5) : 1;
      const why = [];
      if (r.gi === 'منخفض') why.push('مؤشر جلايسيمي منخفض يساعد على ثبات السكر');
      if (r.fiber * servings >= 6) why.push('غنية بالألياف (' + U.round(r.fiber * servings, 1) + ' جم)');
      if (r.protein * servings >= (r.slot === 's' ? 8 : 20)) why.push('بروتين كافٍ (' + U.round(r.protein * servings, 1) + ' جم) يطيل الشبع');
      if (target) why.push('الحصة مضبوطة على هدف ' + K.SLOTS[r.slot] + ' في خطتك (~' + target + ' سعراً)');
      let score = (missing.length ? 0 : 50) + optCover * 25 + (r.gi === 'منخفض' ? 15 : 0) + Math.min(10, r.fiber);
      out.push({ id: r.id, ar: r.ar, slot: r.slot, slotAr: K.SLOTS[r.slot], missing: missing.map(id => K.name(id)), used: used.map(id => K.name(id)), extra: r.opt.filter(n => !H.has(n)).slice(0, 3).map(id => K.name(id)), servings,
        kcal: Math.round(r.kcal * servings), carb: U.round(r.carb * servings, 1), protein: U.round(r.protein * servings, 1), fiber: U.round(r.fiber * servings, 1), gi: r.gi, steps: r.steps, why, score: U.round(score, 1) });
    });
    return out.sort((a, b) => b.score - a.score).slice(0, opts.limit || 3);
  };

  K.name = id => { const i = K.INGREDIENTS.find(x => x.id === id); return i ? i.ar : id; };

  g.OvaKitchen = K;
  if (typeof module !== 'undefined' && module.exports) module.exports = K;
})(globalThis);
