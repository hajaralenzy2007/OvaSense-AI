/* OvaUtil — أدوات مساعدة عامة (توقيت السعودية UTC+3 ثابت) */
(function (g) {
  'use strict';
  const U = {};
  U.MIN = 60000; U.HOUR = 3600000; U.DAY = 86400000; U.TZ = 3 * 3600000;
  const pad = n => String(n).padStart(2, '0');
  U.clamp = (x, a, b) => Math.min(b, Math.max(a, x));
  U.mean = a => a.length ? a.reduce((s, x) => s + x, 0) / a.length : NaN;
  U.sd = a => {
    if (a.length < 2) return NaN;
    const m = U.mean(a);
    return Math.sqrt(a.reduce((s, x) => s + (x - m) * (x - m), 0) / (a.length - 1));
  };
  U.round = (x, d = 0) => { const p = Math.pow(10, d); return Math.round(x * p) / p; };
  U.dayKey = t => new Date(t + U.TZ).toISOString().slice(0, 10);
  U.dayStart = t => Math.floor((t + U.TZ) / U.DAY) * U.DAY - U.TZ;
  U.dayKeyToT = k => Date.parse(k + 'T00:00:00Z') - U.TZ;
  U.hour = t => { const d = new Date(t + U.TZ); return d.getUTCHours() + d.getUTCMinutes() / 60; };
  U.hhmm = t => { const d = new Date(t + U.TZ); return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); };
  U.fmtDT = t => U.dayKey(t) + ' ' + U.hhmm(t);
  U.parseHM = s => { const p = String(s).split(':').map(Number); return ((p[0] || 0) * 60 + (p[1] || 0)) * U.MIN; };

  U.rng = seed => {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  U.gauss = r => { let u = 0; while (!u) u = r(); const v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };

  function ranks(a) {
    const idx = a.map((v, i) => [v, i]).sort((x, y) => x[0] - y[0]);
    const r = new Array(a.length);
    for (let i = 0; i < idx.length;) {
      let j = i;
      while (j + 1 < idx.length && idx[j + 1][0] === idx[i][0]) j++;
      const avg = (i + j) / 2 + 1;
      for (let k = i; k <= j; k++) r[idx[k][1]] = avg;
      i = j + 1;
    }
    return r;
  }
  U.spearman = (x, y) => {
    if (x.length !== y.length || x.length < 3) return NaN;
    const rx = ranks(x), ry = ranks(y), mx = U.mean(rx), my = U.mean(ry);
    let sxy = 0, sxx = 0, syy = 0;
    for (let i = 0; i < rx.length; i++) { sxy += (rx[i] - mx) * (ry[i] - my); sxx += (rx[i] - mx) ** 2; syy += (ry[i] - my) ** 2; }
    if (sxx === 0 || syy === 0) return NaN;
    return sxy / Math.sqrt(sxx * syy);
  };

  U.normAr = s => String(s == null ? '' : s).toLowerCase()
    .replace(/[ً-ْـ]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[؟?!.,،؛:]/g, ' ').replace(/\s+/g, ' ').trim();
  U.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  U.uid = (r) => { const f = r || Math.random; return Array.from({ length: 8 }, () => Math.floor(f() * 16).toString(16)).join(''); };

  g.OvaUtil = U;
  if (typeof module !== 'undefined' && module.exports) module.exports = U;
})(globalThis);
