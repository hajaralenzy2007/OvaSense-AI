/* OvaSecurity — بوابة الأوامر في الجهاز: توقيع الطبيب، الخطة الموقَّعة، حدود الجرعة، سجل تدقيق مترابط */
(function (g) {
  'use strict';
  const U = g.OvaUtil, C = g.OvaCrypto, D = g.OvaDevice;
  const S = {};

  S.CODES = {
    UNSIGNED: 'أمر بلا توقيع (مثل أمر من الذكاء الاصطناعي)',
    UNKNOWN_KEY: 'مفتاح غير معروف للجهاز',
    KEY_REVOKED: 'مفتاح الطبيب مُلغى',
    BAD_SIGNATURE: 'التوقيع غير صالح (تم العبث بالأمر)',
    WRONG_DEVICE: 'الأمر موجّه لجهاز آخر',
    WRONG_PATIENT: 'الأمر موجّه لمريضة أخرى',
    NOT_YET_VALID: 'الأمر لم يحن وقته',
    EXPIRED: 'انتهت صلاحية الأمر',
    REPLAY_NONCE: 'أمر مُعاد الإرسال (nonce مستخدم)',
    SEQ_NOT_INCREASING: 'رقم تسلسل غير متزايد',
    NO_PLAN: 'لا توجد خطة علاج موقَّعة',
    NOT_IN_PLAN: 'المادة غير مدرجة في الخطة',
    DOSE_OVER_SINGLE_MAX: 'الجرعة تتجاوز الحد الأقصى للجرعة الواحدة',
    DAILY_CAP_EXCEEDED: 'تجاوز السقف اليومي',
    MIN_INTERVAL: 'أقل من الفاصل الزمني الأدنى بين الجرعات',
    DEVICE_FAULT: 'عطل مُسجَّل في الجهاز (حالة آمنة)',
    NO_PATCH: 'لا توجد رقعة',
    RESERVOIR_LOW: 'الخزان غير كافٍ',
    BLE_DOWN: 'الاتصال منقطع',
    PLAN_ROLLBACK: 'رفض خطة بإصدار أقدم (حماية من الرجوع)',
    PLAN_EXPIRED: 'انتهت صلاحية الخطة',
    PLAN_EXCEEDS_HARD_LIMIT: 'الخطة تتجاوز الحدود الصلبة للجهاز',
    PLAN_INVALID: 'خطة غير مكتملة',
    LATE_WINDOW: 'فات موعد الجرعة (أكثر من 6 ساعات)',
    BLE_DOWN_HOLD: 'تعليق الجرعة (سياسة فقدان الإشارة: تعليق)',
    HALTED_FLOW_MISMATCH: 'توقف تلقائي: تدفق مقاس لا يطابق المأمور به'
  };

  S.newState = function (deviceId, patientId) {
    return { deviceId, patientId, trustedKeys: {}, plan: null, planKeyId: null, lastSeq: 0, nonces: [], deliveries: [], done: {}, audit: [], planExpiredLogged: false };
  };

  S.verifyChain = function (audit) {
    let prev = 'GENESIS';
    for (let i = 0; i < audit.length; i++) {
      const e = audit[i];
      const h = C.sha256Hex(prev + C.canonical({ i: e.i, t: e.t, type: e.type, code: e.code, detail: e.detail }));
      if (e.i !== i || e.prev !== prev || e.hash !== h) return { ok: false, brokenAt: i };
      prev = e.hash;
    }
    return { ok: true, brokenAt: -1, length: audit.length };
  };

  S.createGate = function (device, state) {
    const s = state;
    const gate = { s, device };

    gate.audit = (t, type, code, detail) => {
      const prev = s.audit.length ? s.audit[s.audit.length - 1].hash : 'GENESIS';
      const e = { i: s.audit.length, t, type, code: code || '', detail: detail || '' };
      e.prev = prev;
      e.hash = C.sha256Hex(prev + C.canonical({ i: e.i, t, type, code: e.code, detail: e.detail }));
      s.audit.push(e);
      return e;
    };
    gate.provisionKey = (keyId, jwk, t) => { s.trustedKeys[keyId] = { jwk, status: 'active' }; gate.audit(t, 'KEY', 'PROVISIONED', keyId); };
    gate.revokeKey = (keyId, t) => { if (s.trustedKeys[keyId]) { s.trustedKeys[keyId].status = 'revoked'; gate.audit(t, 'KEY', 'REVOKED', keyId); } };

    gate.deliveredToday = (substance, now) => {
      const k = U.dayKey(now);
      return s.deliveries.filter(d => d.substance === substance && U.dayKey(d.t) === k).reduce((a, d) => a + d.deliveredUL, 0);
    };
    gate.limitCheck = (item, doseUL, now) => {
      if (doseUL > item.singleMaxUL || doseUL > D.HARD.singleMaxUL) return 'DOSE_OVER_SINGLE_MAX';
      if (gate.deliveredToday(item.substance, now) + doseUL > Math.min(item.dailyCapUL, D.HARD.dailyMaxUL)) return 'DAILY_CAP_EXCEEDED';
      const last = s.deliveries.filter(d => d.substance === item.substance && d.deliveredUL > 0).slice(-1)[0];
      if (last && now - last.t < item.minIntervalMin * U.MIN) return 'MIN_INTERVAL';
      return null;
    };
    gate.deviceCheck = (doseUL, needBle) => {
      const d = device.state;
      if (d.faultLatched) return 'DEVICE_FAULT';
      if (!d.patchApplied) return 'NO_PATCH';
      if (d.reservoirUL < doseUL) return 'RESERVOIR_LOW';
      if (needBle && !d.bleUp) return 'BLE_DOWN';
      return null;
    };
    const reject = (now, code, detail) => { gate.audit(now, 'REJECT', code, detail); return { ok: false, code, label: S.CODES[code] || code }; };
    const keyCheck = async (env, payload, now) => {
      if (!env || !env.sig || !payload || !payload.keyId) return 'UNSIGNED';
      const k = s.trustedKeys[payload.keyId];
      if (!k) return 'UNKNOWN_KEY';
      if (k.status !== 'active') return 'KEY_REVOKED';
      if (!(await C.verify(k.jwk, payload, env.sig))) return 'BAD_SIGNATURE';
      return null;
    };

    gate.installPlan = async function (env, now) {
      const p = env && env.plan;
      const kc = await keyCheck(env, p, now);
      if (kc) return reject(now, kc, 'plan');
      if (!p.items || !p.items.length || !p.version) return reject(now, 'PLAN_INVALID', 'plan');
      if (p.deviceId !== s.deviceId) return reject(now, 'WRONG_DEVICE', 'plan');
      if (p.patientId !== s.patientId) return reject(now, 'WRONG_PATIENT', 'plan');
      if (now < p.issuedAt) return reject(now, 'NOT_YET_VALID', 'plan');
      if (now > p.expiresAt) return reject(now, 'EXPIRED', 'plan');
      if (s.plan && p.version <= s.plan.version) return reject(now, 'PLAN_ROLLBACK', 'v' + p.version + '<=v' + s.plan.version);
      for (const it of p.items) {
        if (it.singleMaxUL > D.HARD.singleMaxUL || it.dailyCapUL > D.HARD.dailyMaxUL) return reject(now, 'PLAN_EXCEEDS_HARD_LIMIT', it.substance);
      }
      s.plan = p; s.planKeyId = p.keyId; s.planExpiredLogged = false;
      gate.audit(now, 'PLAN', 'INSTALLED', 'v' + p.version + ' by ' + p.keyId);
      return { ok: true, version: p.version };
    };

    // أمر لمرة واحدة موقَّع
    gate.execute = async function (env, now) {
      const c = env && env.cmd;
      const kc = await keyCheck(env, c, now);
      if (kc) return reject(now, kc, c && c.cmdId);
      if (c.deviceId !== s.deviceId) return reject(now, 'WRONG_DEVICE', c.cmdId);
      if (c.patientId !== s.patientId) return reject(now, 'WRONG_PATIENT', c.cmdId);
      if (now < c.issuedAt) return reject(now, 'NOT_YET_VALID', c.cmdId);
      if (now > c.expiresAt) return reject(now, 'EXPIRED', c.cmdId);
      if (s.nonces.includes(c.nonce)) return reject(now, 'REPLAY_NONCE', c.cmdId);
      if (!(c.seq > s.lastSeq)) return reject(now, 'SEQ_NOT_INCREASING', c.cmdId);
      s.nonces.push(c.nonce); if (s.nonces.length > 200) s.nonces.shift();
      s.lastSeq = c.seq;
      if (!s.plan) return reject(now, 'NO_PLAN', c.cmdId);
      if (now > s.plan.expiresAt) return reject(now, 'PLAN_EXPIRED', c.cmdId);
      const item = s.plan.items.find(i => i.substance === c.substance);
      if (!item) return reject(now, 'NOT_IN_PLAN', c.cmdId);
      const lc = gate.limitCheck(item, c.doseUL, now);
      if (lc) return reject(now, lc, c.cmdId);
      const dc = gate.deviceCheck(c.doseUL, true);
      if (dc) return reject(now, dc, c.cmdId);
      const r = device.deliver(now, c.doseUL, c.rateULmin);
      if (r.deliveredUL > 0) s.deliveries.push({ t: now, substance: c.substance, commandedUL: c.doseUL, deliveredUL: r.deliveredUL, source: 'cmd' });
      gate.audit(now, r.ok ? 'DELIVER' : 'HALT', r.status, c.cmdId + ' ' + c.substance + ' cmd=' + c.doseUL + ' meas=' + r.measuredUL);
      return Object.assign({ code: r.ok ? 'OK' : r.status, label: r.ok ? 'تم التوصيل' : S.CODES[r.status] }, r);
    };

    // تنفيذ الخطة الموقَّعة تلقائياً (يعمل داخل الجهاز حتى عند انقطاع البلوتوث وفق السياسة)
    gate.runSchedule = function (now) {
      const p = s.plan, out = [];
      if (!p) return out;
      if (now > p.expiresAt) {
        if (!s.planExpiredLogged) { s.planExpiredLogged = true; gate.audit(now, 'PLAN', 'PLAN_EXPIRED', 'v' + p.version); }
        return out;
      }
      const day = U.dayKey(now);
      for (const it of p.items) {
        for (const tm of it.times) {
          const key = day + '|' + it.substance + '|' + tm;
          if (s.done[key]) continue;
          const due = U.dayStart(now) + U.parseHM(tm);
          if (now < due) continue;
          s.done[key] = 1;
          if (now - due > 6 * U.HOUR) { gate.audit(now, 'SKIP', 'LATE_WINDOW', key); out.push({ code: 'LATE_WINDOW', substance: it.substance, t: now }); continue; }
          if (!device.state.bleUp && p.onSignalLoss === 'hold') { gate.audit(now, 'SKIP', 'BLE_DOWN_HOLD', key); out.push({ code: 'BLE_DOWN_HOLD', substance: it.substance, t: now }); continue; }
          const lc = gate.limitCheck(it, it.doseUL, now) || gate.deviceCheck(it.doseUL, false);
          if (lc) { gate.audit(now, 'REJECT', lc, 'plan ' + key); out.push({ code: lc, substance: it.substance, t: now }); continue; }
          const r = device.deliver(now, it.doseUL, it.rateULmin || 5);
          if (r.deliveredUL > 0) s.deliveries.push({ t: now, substance: it.substance, commandedUL: it.doseUL, deliveredUL: r.deliveredUL, source: 'plan' });
          gate.audit(now, r.ok ? 'DELIVER' : 'HALT', r.status, 'plan ' + key + ' meas=' + r.measuredUL);
          out.push(Object.assign({ code: r.ok ? 'OK' : r.status, substance: it.substance, t: now }, r));
        }
      }
      const cutoff = U.dayKey(now - 3 * U.DAY);
      const keys = Object.keys(s.done);
      if (keys.length > 120) keys.forEach(k => { if (k.slice(0, 10) < cutoff) delete s.done[k]; });
      return out;
    };
    return gate;
  };

  // أدوات للطبيب: بناء وتوقيع الأوامر والخطط
  S.signPlan = async function (privJwk, plan) { return { plan, sig: await C.sign(privJwk, plan) }; };
  S.signCmd = async function (privJwk, cmd) { return { cmd, sig: await C.sign(privJwk, cmd) }; };
  S.nextCmd = function (ctx, o) {
    // ctx: {keyId, deviceId, patientId, seq, now}
    return Object.assign({
      cmdId: 'C' + ctx.seq, keyId: ctx.keyId, deviceId: ctx.deviceId, patientId: ctx.patientId,
      rateULmin: 5, issuedAt: ctx.now, expiresAt: ctx.now + 10 * U.MIN, seq: ctx.seq,
      nonce: C.sha256Hex(ctx.keyId + ':' + ctx.seq + ':' + ctx.now).slice(0, 16)
    }, o);
  };

  g.OvaSecurity = S;
  if (typeof module !== 'undefined' && module.exports) module.exports = S;
})(globalThis);
