/* OvaAI — دعم قرار محلي (قواعد + إحصاء). لا يشخّص ولا ينفّذ جرعات: أي اقتراح يحتاج توقيع الطبيب. */
(function (g) {
  'use strict';
  const U = g.OvaUtil, KB = g.OvaKB;
  const AI = {};

  const glu = (rs, a, b) => rs.filter(r => r.type === 'glucose' && r.t >= a && r.t <= b);

  AI.glucoseStats = function (readings, from, to, range) {
    range = range || { low: 70, high: 140 };
    const v = glu(readings, from, to).map(r => r.value);
    if (!v.length) return { n: 0 };
    const m = U.mean(v), s = U.sd(v);
    const below = v.filter(x => x < range.low).length, above = v.filter(x => x > range.high).length;
    return {
      n: v.length, mean: U.round(m, 1), sd: U.round(s, 1), cv: U.round(s / m * 100, 1),
      tirPct: U.round((v.length - below - above) / v.length * 100, 1),
      belowPct: U.round(below / v.length * 100, 1), abovePct: U.round(above / v.length * 100, 1),
      min: Math.min.apply(null, v), max: Math.max.apply(null, v)
    };
  };

  AI.signalQuality = function (readings, now, hours) {
    const q = glu(readings, now - (hours || 6) * U.HOUR, now).filter(r => r.q != null).map(r => r.q);
    return q.length ? U.round(U.mean(q), 2) : null;
  };

  // متوسط سكر الصيام (05:00–08:00) لكل يوم
  AI.fastingByDay = function (readings) {
    const by = {};
    readings.filter(r => r.type === 'glucose').forEach(r => {
      const h = U.hour(r.t);
      if (h >= 5 && h < 8) (by[U.dayKey(r.t)] = by[U.dayKey(r.t)] || []).push(r.value);
    });
    return Object.keys(by).sort().map(k => ({ day: k, mean: U.mean(by[k]) }));
  };

  AI.adherence = function (plan, deliveries, now, days) {
    if (!plan) return null;
    days = days || 7;
    const from = Math.max(now - days * U.DAY, plan.issuedAt);
    let sched = 0;
    for (let d = U.dayStart(from); d <= now; d += U.DAY) {
      for (const it of plan.items) for (const tm of it.times) { const due = d + U.parseHM(tm); if (due > from && due <= now) sched++; }
    }
    if (!sched) return null;
    const done = deliveries.filter(x => x.t > from && x.t <= now && x.deliveredUL > 0).length;
    return U.clamp(Math.round(done / sched * 100), 0, 100);
  };

  // ---------- تقدير حاجة التحليل (مع الأسباب) ----------
  AI.bloodTestNeed = function (c) {
    const R = [];
    const add = (code, pts, text) => R.push({ code, pts, text });
    if (c.quality != null && c.quality < 0.6) add('SIGNAL_POOR', 35, 'جودة إشارة المستشعر منخفضة (' + c.quality + ') — تلزم معايرة بقياس دم مرجعي.');
    else if (c.quality != null && c.quality < 0.75) add('SIGNAL_DRIFT', 15, 'بدأ انجراف الإشارة (جودة ' + c.quality + ').');
    const lastLab = c.lastLabT;
    if (!lastLab || c.now - lastLab > (c.labIntervalDays || 90) * U.DAY) add('LAB_DUE', 25, 'حان موعد التحليل الدوري الذي حدده الطبيب (كل ' + (c.labIntervalDays || 90) + ' يوماً).');
    if (c.patchAgeDays >= 3 && !c.calibratedThisPatch) add('NO_CALIBRATION', 10, 'الرقعة الحالية لم تُعايَر بقياس دم بعد.');
    if (c.stats && c.stats.n && c.stats.belowPct > 5) add('LOW_READINGS', 15, 'نسبة قراءات منخفضة مرتفعة (' + c.stats.belowPct + '%) — تُؤكَّد بقياس دم.');
    if (c.stats && c.stats.n && c.stats.cv > 36) add('HIGH_VARIABILITY', 10, 'تذبذب القراءات مرتفع (CV ' + c.stats.cv + '%).');
    if (c.fastingHighDays >= 3) add('FASTING_HIGH', 15, 'سكر صائم أعلى من حد الطبيب في ' + c.fastingHighDays + ' أيام حديثة.');
    if (c.bleedingUrgent) add('BLEEDING_RED_FLAG', 40, 'مؤشرات نزيف تستدعي تقييماً طبياً مباشراً (وليس مجرد تحليل).');
    R.sort((a, b) => b.pts - a.pts);
    const score = Math.min(100, R.reduce((s, r) => s + r.pts, 0));
    const level = score >= 60 ? 'high' : score >= 30 ? 'medium' : 'low';
    return {
      score, level, reasons: R,
      label: { high: 'يُنصح بتحليل دم قريباً', medium: 'تحليل دم قد يكون مفيداً', low: 'لا حاجة لتحليل دم الآن' }[level]
    };
  };

  // ---------- مراجعة خطة الجرعات (اقتراحات فقط، ضمن حدود الخطة، بلا تنفيذ) ----------
  AI.dosePlanReview = function (c) {
    const out = [];
    const P = (code, text) => out.push({ code, text, requiresDoctor: true, withinPlan: true, canExecute: false });
    const alerts = c.deviceAlerts || [];
    if (alerts.some(a => a.code === 'FLOW_MISMATCH')) P('CHECK_DEVICE', 'توقف التوصيل بسبب عدم تطابق التدفق: يُقترح فحص الجهاز وإبلاغ الطبيب قبل استئناف الجرعات.');
    if (c.quality != null && c.quality < 0.6) P('CONFIRM_READING', 'يُقترح قياس دم مرجعي ومعايرة المستشعر قبل الاعتماد على القراءات في أي قرار.');
    if (c.stats && c.stats.n && c.stats.belowPct > 5) P('REVIEW_LOWS', 'رُصدت قراءات منخفضة؛ يُقترح إبلاغ الطبيب لمراجعة توقيت الخطة (ضمن حدودها).');
    if (c.adherencePct != null && c.adherencePct < 80) P('ADHERENCE', 'نسبة الالتزام ' + c.adherencePct + '% — يُقترح تفعيل تذكيرات إضافية ومراجعة أسباب فوات الجرعات.');
    if (!out.length) out.push({ code: 'KEEP', text: 'لا اقتراح تعديل: الخطة الحالية مناسبة للقراءات المتاحة ضمن حدودها.', requiresDoctor: false, withinPlan: true, canExecute: false });
    return out;
  };

  // ---------- النزيف: PBAC + الأنماط ----------
  AI.pbacDay = function (e) {
    const p = e.pads || {}, t = e.tampons || {};
    return (p.l || 0) * 1 + (p.m || 0) * 5 + (p.s || 0) * 20 + (t.l || 0) * 1 + (t.m || 0) * 5 + (t.s || 0) * 10 +
      (e.clotsS || 0) * 1 + (e.clotsL || 0) * 5 + (e.flooding ? 5 : 0);
  };
  AI.bleedingAnalysis = function (entries, now) {
    const days = entries.slice().sort((a, b) => a.date < b.date ? -1 : 1);
    const T = d => U.dayKeyToT(d);
    const episodes = [];
    for (const e of days) {
      const last = episodes[episodes.length - 1];
      if (last && (T(e.date) - T(last.end)) <= 1 * U.DAY) { last.end = e.date; last.entries.push(e); }
      else episodes.push({ start: e.date, end: e.date, entries: [e] });
    }
    episodes.forEach(ep => {
      ep.days = Math.round((T(ep.end) - T(ep.start)) / U.DAY) + 1;
      ep.pbac = ep.entries.reduce((s, e) => s + AI.pbacDay(e), 0);
      ep.spottingOnly = ep.entries.every(e => e.spotting) && ep.days <= 2;
      ep.flags = [];
      ep.entries.forEach(e => {
        const sat = ((e.pads || {}).s || 0) + ((e.tampons || {}).s || 0);
        if (sat >= 8 || (e.flooding && sat >= 4)) ep.flags.push('SOAKING');
        if ((e.clotsL || 0) >= 1) ep.flags.push('LARGE_CLOTS');
        if (e.dizzy) ep.flags.push('DIZZY');
      });
      ep.heavy = ep.pbac > 100;
      ep.prolonged = ep.days > 8;
    });
    const periods = episodes.filter(e => !e.spottingOnly);
    const cycleLens = [];
    for (let i = 1; i < periods.length; i++) cycleLens.push(Math.round((T(periods[i].start) - T(periods[i - 1].start)) / U.DAY));
    const patterns = [];
    const lastP = periods[periods.length - 1];
    const urgent = !!(lastP && (lastP.flags.includes('DIZZY') || (lastP.flags.includes('SOAKING') && lastP.flags.includes('LARGE_CLOTS'))));
    if (lastP) {
      if (lastP.heavy) patterns.push({ code: 'HEAVY', sev: 'warn', text: 'نزيف غزير بحسب PBAC (' + lastP.pbac + ' > 100) — يُنصح بمراجعة الطبيب.' });
      if (lastP.prolonged) patterns.push({ code: 'PROLONGED', sev: 'warn', text: 'مدة النزيف ' + lastP.days + ' أيام (أكثر من 8).' });
      if (lastP.flags.includes('SOAKING')) patterns.push({ code: 'SOAKING', sev: 'warn', text: 'تشبّع شديد بالفوط في يوم واحد.' });
      if (lastP.flags.includes('LARGE_CLOTS')) patterns.push({ code: 'LARGE_CLOTS', sev: 'warn', text: 'خثرات كبيرة مسجّلة.' });
      if (lastP.flags.includes('DIZZY')) patterns.push({ code: 'DIZZY', sev: 'danger', text: 'دوخة مع النزيف — تقييم طبي عاجل.' });
    }
    if (urgent) patterns.unshift({ code: 'URGENT', sev: 'danger', text: 'مؤشرات خطر: توجهي للطوارئ أو تواصلي مع الطبيب فوراً.' });
    if (cycleLens.length) {
      const recent = cycleLens.slice(-3), m = U.mean(recent);
      if (m > 35) patterns.push({ code: 'LONG_CYCLES', sev: 'info', text: 'متوسط طول الدورة ≈ ' + U.round(m) + ' يوماً (أكثر من 35): نمط دورات متباعدة.' });
      else if (m < 21) patterns.push({ code: 'SHORT_CYCLES', sev: 'info', text: 'متوسط طول الدورة ≈ ' + U.round(m) + ' يوماً (أقل من 21): دورات متقاربة.' });
      else patterns.push({ code: 'NORMAL_LEN', sev: 'ok', text: 'متوسط طول الدورة ≈ ' + U.round(m) + ' يوماً (ضمن 21–35).' });
      if (Math.max.apply(null, recent) - Math.min.apply(null, recent) >= 9) patterns.push({ code: 'VARIABLE', sev: 'info', text: 'تفاوت كبير بين أطوال الدورات (9 أيام أو أكثر).' });
    }
    if (lastP && now) {
      const since = Math.round((now - T(lastP.end)) / U.DAY);
      if (since > 90) patterns.push({ code: 'NO_PERIOD_90', sev: 'warn', text: 'لا نزيف منذ ' + since + ' يوماً (أكثر من 90): يُنصح بمراجعة الطبيب.' });
    }
    if (episodes.some(e => e.spottingOnly)) patterns.push({ code: 'SPOTTING', sev: 'info', text: 'تم تسجيل تبقيع بين الدورات.' });
    return {
      episodes: episodes.map(e => ({ start: e.start, end: e.end, days: e.days, pbac: e.pbac, spottingOnly: e.spottingOnly, heavy: e.heavy, flags: Array.from(new Set(e.flags)) })),
      cycleLens, patterns, urgent,
      note: 'PBAC تقدير ذاتي وليس قياساً؛ القيمة فوق 100 تقابل غالباً فقداً أكثر من نحو 80 مل. لا يُعد تشخيصاً.'
    };
  };

  // ---------- ارتباط الأعراض بالقراءات (سبيرمان) ----------
  AI.symptomCorrelation = function (symptoms, readings) {
    const dayMean = (type) => {
      const by = {};
      readings.filter(r => r.type === type).forEach(r => (by[U.dayKey(r.t)] = by[U.dayKey(r.t)] || []).push(r.value));
      const o = {}; Object.keys(by).forEach(k => o[k] = U.mean(by[k])); return o;
    };
    const gm = dayMean('glucose'), hm = dayMean('hm1');
    const names = { acne: 'حب الشباب', hirsutism: 'نمو الشعر الزائد', fatigue: 'الإرهاق', mood: 'تقلب المزاج', cramps: 'ألم الحوض', bloating: 'الانتفاخ', hairloss: 'تساقط الشعر', headache: 'الصداع' };
    const res = [];
    const sources = [['متوسط الجلوكوز اليومي', gm], ['المؤشر الهرموني HM1', hm]];
    for (const [sn, map] of sources) {
      for (const k of Object.keys(names)) {
        const xs = [], ys = [];
        symptoms.forEach(s => { if (map[s.date] != null && s[k] != null) { xs.push(map[s.date]); ys.push(s[k]); } });
        if (xs.length < 10) { res.push({ a: sn, b: names[k], n: xs.length, rho: null, text: 'بيانات غير كافية (n=' + xs.length + ' < 10).' }); continue; }
        const rho = U.spearman(xs, ys);
        if (isNaN(rho)) { res.push({ a: sn, b: names[k], n: xs.length, rho: null, text: 'لا تباين كافٍ للحساب.' }); continue; }
        const ab = Math.abs(rho);
        const strength = ab < 0.3 ? 'لا ارتباط واضح' : ab < 0.6 ? 'ارتباط متوسط' : 'ارتباط قوي';
        res.push({ a: sn, b: names[k], n: xs.length, rho: U.round(rho, 2), strength, text: strength + (ab >= 0.3 ? (rho > 0 ? ' طردي' : ' عكسي') : '') + ' (ρ=' + U.round(rho, 2) + ', n=' + xs.length + ') — الارتباط لا يعني السببية.' });
      }
    }
    return res;
  };

  // ---------- النظام الغذائي ----------
  AI.energy = function (p) {
    const bmr = 10 * p.weightKg + 6.25 * p.heightCm - 5 * p.age - 161;
    const af = { low: 1.2, moderate: 1.375, high: 1.55 }[p.activity || 'low'];
    const tdee = bmr * af;
    const deficit = p.goal === 'lose' ? Math.min(500, tdee * 0.2) : 0;
    return { bmr: Math.round(bmr), tdee: Math.round(tdee), target: Math.max(1200, Math.round(tdee - deficit)) };
  };
  AI.dietPlan = function (p, seed) {
    const E = AI.energy(p), rng = U.rng(seed || 1);
    const F = id => KB.FOODS.find(f => f.id === id);
    const pick = arr => F(arr[Math.floor(rng() * arr.length)]);
    const slots = [
      { slot: 'b', label: 'الفطور', items: [{ f: pick(['egg', 'cottage']), q: 1 }, { f: pick(['oats', 'foul', 'wholebread']), q: 1, C: 1 }, { f: pick(['labneh', 'yogurt']), q: 1 }, { f: F('salad'), q: 0.5 }] },
      { slot: 's1', label: 'وجبة خفيفة', items: [{ f: F('apple'), q: 1, C: 1 }, { f: F('almond'), q: 0.5 }] },
      { slot: 'l', label: 'الغداء', items: [{ f: pick(['chicken', 'fish', 'lean']), q: 1 }, { f: pick(['lentil', 'chickpea', 'brownrice']), q: 1, C: 1 }, { f: F('salad'), q: 1 }, { f: F('cookedveg'), q: 1 }] },
      { slot: 's2', label: 'وجبة خفيفة', items: [{ f: pick(['yogurt', 'cottage']), q: 1 }, { f: F('cucumber'), q: 1 }] },
      { slot: 'd', label: 'العشاء', items: [{ f: pick(['fish', 'chicken']), q: 1 }, { f: pick(['lentil', 'chickpea', 'brownrice']), q: 0.5, C: 1 }, { f: F('salad'), q: 1 }, { f: F('cookedveg'), q: 1 }] }
    ];
    const tot = () => slots.reduce((s, m) => s + m.items.reduce((a, i) => a + i.f.kcal * i.q, 0), 0);
    const carbs = slots.flatMap(m => m.items.filter(i => i.C));
    let guard = 0;
    while (tot() < E.target - 90 && guard++ < 40) { const c = carbs.filter(i => i.q < 3).sort((a, b) => a.q - b.q)[0]; if (!c) break; c.q += 0.5; }
    const others0 = slots.flatMap(m => m.items.filter(i => !i.C));
    while (tot() < E.target - 90 && guard++ < 80) { const c = others0.filter(i => i.q < 2).sort((a, b) => a.f.kcal * a.q - b.f.kcal * b.q)[0]; if (!c) break; c.q += 0.5; }
    while (tot() > E.target + 90 && guard++ < 80) { const c = carbs.filter(i => i.q > 0.5).sort((a, b) => b.q - a.q)[0]; if (!c) break; c.q -= 0.5; }
    // إن بقي المجموع أعلى من الهدف، نخفّض حصص غير الكربوهيدرات الأكبر سعرات (حتى نصف حصة)
    const others = slots.flatMap(m => m.items.filter(i => !i.C));
    while (tot() > E.target + 90 && guard++ < 160) { const c = others.filter(i => i.q > 0.5).sort((a, b) => b.f.kcal * b.q - a.f.kcal * a.q)[0]; if (!c) break; c.q -= 0.5; }
    const sum = (items, k) => U.round(items.reduce((a, i) => a + i.f[k] * i.q, 0), 1);
    const meals = slots.map(m => {
      const items = m.items.map(i => ({ id: i.f.id, ar: i.f.ar, serving: i.f.serving, qty: i.q, kcal: Math.round(i.f.kcal * i.q), carb: U.round(i.f.carb * i.q, 1), protein: U.round(i.f.protein * i.q, 1), fiber: U.round(i.f.fiber * i.q, 1), gi: i.f.gi }));
      return { slot: m.slot, label: m.label, items, kcal: items.reduce((a, i) => a + i.kcal, 0), carb: U.round(items.reduce((a, i) => a + i.carb, 0), 1) };
    });
    const flat = meals.flatMap(m => m.items);
    return {
      energy: E, meals,
      totals: { kcal: flat.reduce((a, i) => a + i.kcal, 0), carb: U.round(flat.reduce((a, i) => a + i.carb, 0), 1), protein: U.round(flat.reduce((a, i) => a + i.protein, 0), 1), fiber: U.round(flat.reduce((a, i) => a + i.fiber, 0), 1) },
      notes: ['قيم الحصص تقريبية.', 'خطة عامة لا تغني عن أخصائية تغذية، وتُعدَّل مع حالات السكري/الكلى/الحمل.', 'الحد الأدنى للطاقة في المقترح 1200 سعر.']
    };
  };

  // ---------- المكملات والأعشاب ----------
  AI.supplementCheck = function (query, ctx) {
    ctx = ctx || {};
    const q = U.normAr(query);
    const entry = KB.SUPPLEMENTS.find(s => s.names.some(n => q.includes(U.normAr(n))));
    if (!entry) return { found: false, text: 'لا أملك معلومات موثوقة كافية عن «' + query + '». لا أخمّن؛ اسألي الصيدلي أو الطبيب.' };
    const w = [];
    const meds = U.normAr(ctx.meds || '');
    if (entry.flags.includes('pregnancy') && ctx.pregnant) w.push('تُجنَّب أثناء الحمل ما لم يوجّه الطبيب.');
    if (entry.flags.includes('hypertension') && ctx.hypertension) w.push('قد يرفع الضغط؛ لا يُستخدم مع ارتفاع الضغط دون إذن الطبيب.');
    if (entry.flags.includes('bleeding') && /وارفارين|مميع|اسبرين|warfarin|clopidogrel|aspirin|كلوبيدوجريل/.test(meds)) w.push('أدويتك المسجلة قد تزيد خطر النزف مع هذا المكمل.');
    if (entry.flags.includes('interaction') && meds) w.push('لديك أدوية مسجلة: اسألي الصيدلي عن التداخل قبل الاستخدام.');
    if (entry.flags.includes('needs_lab')) w.push('يُفضَّل قياس المستوى في الدم قبل أي جرعة.');
    return { found: true, entry, warnings: w, level: w.length ? 'caution' : 'info', text: entry.ar + ': ' + entry.evidence + ' ' + entry.cautions };
  };

  g.OvaAI = AI;
  if (typeof module !== 'undefined' && module.exports) module.exports = AI;
})(globalThis);
