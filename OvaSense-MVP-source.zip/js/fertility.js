/* OvaFertility — تقدير الدورة ونافذة الخصوبة بطريقة التقويم + اختبار LH.
   تقدير فقط: ليس وسيلة لمنع الحمل ولا تشخيصاً. في المتلازمة تكون الدورات غير منتظمة فتتّسع حدود عدم اليقين. */
(function (g) {
  'use strict';
  const U = g.OvaUtil, D = U.DAY;
  const F = {};
  const T = k => U.dayKeyToT(k);
  const diff = (a, b) => Math.round((T(b) - T(a)) / D);
  const add = (k, n) => U.dayKey(T(k) + n * D + 12 * U.HOUR - 12 * U.HOUR);
  F.add = add; F.diff = diff;

  // starts: مفاتيح أيام بدايات الدورات (مرتبة أو لا)، logs: [{date, lh:'pos'|'neg'|'', mucus}]
  F.analyze = function (starts, logs, nowT, o) {
    o = o || {};
    const today = U.dayKey(nowT);
    const S = Array.from(new Set(starts.filter(k => k <= today))).sort();
    const lens = []; for (let i = 1; i < S.length; i++) lens.push(diff(S[i - 1], S[i]));
    const recent = lens.slice(-6), n = recent.length;
    const mean = n ? recent.reduce((a, b) => a + b, 0) / n : null;
    const sd = n >= 2 ? Math.sqrt(recent.reduce((a, b) => a + (b - mean) * (b - mean), 0) / (n - 1)) : null;
    const res = { today, starts: S, lens: recent, n, mean: mean == null ? null : Math.round(mean * 10) / 10, sd: sd == null ? null : Math.round(sd * 10) / 10 };
    if (!S.length) { res.empty = true; return res; }
    const last = S[S.length - 1];
    res.lastStart = last; res.dayOfCycle = diff(last, today) + 1; res.daysSinceLast = diff(last, today);
    // عدم الانتظام (إرشاد 2023: <21 أو >35 يوماً، أو دورة >90 يوماً)
    const reasons = [];
    if (mean != null && mean > 35) reasons.push('متوسط طول الدورة ' + res.mean + ' يوماً (أكثر من 35).');
    if (mean != null && mean < 21) reasons.push('متوسط طول الدورة ' + res.mean + ' يوماً (أقل من 21).');
    if (recent.some(x => x > 90)) reasons.push('وُجدت دورة تجاوزت 90 يوماً.');
    if (sd != null && sd > 7) reasons.push('تباين كبير بين الدورات (الانحراف المعياري ' + res.sd + ' أيام).');
    res.irregular = reasons.length > 0; res.reasons = reasons;
    res.longGap = res.daysSinceLast > 90;
    res.insufficient = n < 2;
    res.confidence = (res.irregular || res.insufficient) ? 'low' : 'medium';
    const base = mean != null ? Math.round(mean) : (o.defaultLen || 28);
    const hw = Math.max(3, Math.round(sd != null ? sd : 5));
    res.nextStart = { key: add(last, base), lo: add(last, base - hw), hi: add(last, base + hw), hw };
    res.late = today > res.nextStart.hi;
    // الإباضة: LH موجب في الدورة الحالية يُرجِّح التاريخ؛ وإلا تقويم (بداية القادمة − 14)
    const lhPos = (logs || []).filter(l => l.lh === 'pos' && l.date >= last && l.date <= today).map(l => l.date).sort();
    let ov;
    if (lhPos.length) { const d0 = lhPos[lhPos.length - 1]; ov = { key: add(d0, 1), lo: add(d0, 1), hi: add(d0, 2), basis: 'LH', lhDate: d0 }; }
    else { const w = Math.round(Math.sqrt(hw * hw + 4)); ov = { key: add(res.nextStart.key, -14), lo: add(res.nextStart.key, -14 - w), hi: add(res.nextStart.key, -14 + w), basis: 'calendar' }; }
    res.ovulation = ov;
    res.fertile = { from: add(ov.key, -5), to: ov.key, broadFrom: add(ov.lo, -5), broadTo: ov.hi };
    // الطور اليوم
    let phase;
    if (res.dayOfCycle <= 5) phase = 'menses';
    else if (today >= res.fertile.from && today <= res.fertile.to) phase = 'fertile';
    else if (today < res.fertile.from) phase = 'follicular';
    else if (today <= res.nextStart.hi) phase = 'luteal';
    else phase = 'late';
    res.phase = phase;
    res.lhPositiveRecent = lhPos.length > 0;
    return res;
  };
  F.PHASE_AR = { menses: 'أيام الدورة', follicular: 'الطور الجريبي (قبل النافذة)', fertile: 'نافذة الخصوبة المقدّرة', luteal: 'بعد الإباضة المقدّرة', late: 'متأخرة عن المتوقع' };

  // شريط تقويم: كل يوم من بداية الدورة الحالية
  F.calendar = function (a, bleedDays) {
    if (a.empty) return [];
    const L = Math.max(Math.round(a.mean || 28) + 8, 36), out = [], bd = new Set(bleedDays || []);
    for (let i = 0; i < L; i++) {
      const k = add(a.lastStart, i), cls = [];
      if (bd.has(k)) cls.push('bl');
      if (k >= a.fertile.from && k <= a.fertile.to) cls.push('fr');
      if (k === a.ovulation.key) cls.push('ov');
      if (k >= a.nextStart.lo && k <= a.nextStart.hi) cls.push('np');
      if (k === a.today) cls.push('td');
      out.push({ key: k, day: i + 1, cls: cls.join(' ') });
    }
    return out;
  };
  g.OvaFertility = F;
  if (typeof module !== 'undefined' && module.exports) module.exports = F;
})(globalThis);
