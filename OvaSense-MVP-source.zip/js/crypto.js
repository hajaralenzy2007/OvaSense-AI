/* OvaCrypto — SHA-256 (JS صرف، متزامن) + ECDSA P-256 عبر WebCrypto */
(function (g) {
  'use strict';
  const K = [], H0 = [];
  (function () {
    const primes = [];
    for (let n = 2; primes.length < 64; n++) {
      let ok = true;
      for (const p of primes) { if (p * p > n) break; if (n % p === 0) { ok = false; break; } }
      if (ok) primes.push(n);
    }
    const frac = x => x - Math.floor(x);
    for (let i = 0; i < 64; i++) K.push(Math.floor(frac(Math.cbrt(primes[i])) * 4294967296) >>> 0);
    for (let i = 0; i < 8; i++) H0.push(Math.floor(frac(Math.sqrt(primes[i])) * 4294967296) >>> 0);
  })();

  const C = {};
  C.utf8 = s => new TextEncoder().encode(s);
  C.hex = b => Array.from(b, x => x.toString(16).padStart(2, '0')).join('');

  C.sha256 = function (bytes) {
    const l = bytes.length;
    const total = ((l + 9 + 63) >> 6) << 6;
    const buf = new Uint8Array(total);
    buf.set(bytes); buf[l] = 0x80;
    const dv = new DataView(buf.buffer);
    dv.setUint32(total - 8, Math.floor(l / 0x20000000));
    dv.setUint32(total - 4, (l << 3) >>> 0);
    const h = H0.slice(), w = new Uint32Array(64);
    for (let o = 0; o < total; o += 64) {
      for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
      for (let i = 16; i < 64; i++) {
        const a = w[i - 15], b = w[i - 2];
        const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
        const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      let a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], gg = h[6], hh = h[7];
      for (let i = 0; i < 64; i++) {
        const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        const ch = (e & f) ^ (~e & gg);
        const t1 = (hh + S1 + ch + K[i] + w[i]) >>> 0;
        const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        const maj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + maj) >>> 0;
        hh = gg; gg = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      h[0] = (h[0] + a) >>> 0; h[1] = (h[1] + b) >>> 0; h[2] = (h[2] + c) >>> 0; h[3] = (h[3] + d) >>> 0;
      h[4] = (h[4] + e) >>> 0; h[5] = (h[5] + f) >>> 0; h[6] = (h[6] + gg) >>> 0; h[7] = (h[7] + hh) >>> 0;
    }
    const out = new Uint8Array(32), odv = new DataView(out.buffer);
    for (let i = 0; i < 8; i++) odv.setUint32(i * 4, h[i]);
    return out;
  };
  C.sha256Hex = s => C.hex(C.sha256(C.utf8(s)));

  // JSON قياسي بترتيب مفاتيح ثابت
  C.canonical = function canon(v) {
    if (v === null || typeof v !== 'object') return JSON.stringify(v === undefined ? null : v);
    if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']';
    return '{' + Object.keys(v).sort().filter(k => v[k] !== undefined).map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}';
  };

  const subtle = () => (g.crypto && g.crypto.subtle) || null;
  C.available = () => !!subtle();
  const ALG = { name: 'ECDSA', namedCurve: 'P-256' };
  const b64u = bytes => btoa(String.fromCharCode.apply(null, Array.from(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64u = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return Uint8Array.from(atob(s), c => c.charCodeAt(0)); };

  C.generateKeyPair = async function () {
    const kp = await subtle().generateKey(ALG, true, ['sign', 'verify']);
    const pub = await subtle().exportKey('jwk', kp.publicKey);
    const priv = await subtle().exportKey('jwk', kp.privateKey);
    return { publicJwk: pub, privateJwk: priv, keyId: C.keyIdOf(pub) };
  };
  C.keyIdOf = jwk => C.sha256Hex(jwk.x + '.' + jwk.y).slice(0, 12);
  C.sign = async function (privJwk, obj) {
    const key = await subtle().importKey('jwk', privJwk, ALG, false, ['sign']);
    const sig = await subtle().sign({ name: 'ECDSA', hash: 'SHA-256' }, key, C.utf8(C.canonical(obj)));
    return b64u(new Uint8Array(sig));
  };
  C.verify = async function (pubJwk, obj, sig) {
    try {
      const key = await subtle().importKey('jwk', pubJwk, ALG, false, ['verify']);
      return await subtle().verify({ name: 'ECDSA', hash: 'SHA-256' }, key, unb64u(sig), C.utf8(C.canonical(obj)));
    } catch (e) { return false; }
  };

  g.OvaCrypto = C;
  if (typeof module !== 'undefined' && module.exports) module.exports = C;
})(globalThis);
