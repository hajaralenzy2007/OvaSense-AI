/* OvaTwin — توأم رقمي تعليمي لسيناريوهات «ماذا لو؟» (نمط الحياة/الالتزام).
   - الوزن: نموذج توازن طاقة مبسّط (افتراض: ~22 سعراً لكل كغ لكل يوم، ثابت زمني ~365 يوماً، نطاق ±30% افتراضي).
   - سكر/إنسولين الصيام: نطاقات مستخرجة من مراجعة Domecq 2013 (برامج نمط الحياة)، تتدرّج خلال ~90 يوماً (افتراض).
   - لا يتنبأ بالدورة الشهرية ولا بالأعراض كمياً. أثر أي دواء/مكمل يدخله الطبيب كافتراض صريح. */
(function (g) {
  'use strict';
  const U = g.OvaUtil;
  const T = {};
  T.PARAMS = {
    kcalPerKgDay: 22, tauWeightDays: 365, tauMetabolicDays: 90, bandFrac: 0.3,
    fg: { mid: -2.3, lo: -4.5, hi: -0.1 }, fi: { mid: -2.1, lo: -3.3, hi: -1.0 },
    METnet: 2.5
  };

  T.simulate = function (p) {
    const P = T.PARAMS, step = p.stepDays || 7, H = p.horizonDays || 180;
    const adh = U.clamp(p.adherence == null ? 1 : p.adherence, 0, 1);
    const actKcal = (p.activityMinPerWeek || 0) / 7 * 0.0175 * P.METnet * p.weightKg;
    const eq = ((p.deficitKcal || 0) + actKcal) * adh / P.kcalPerKgDay;
    const lifestyle = (p.deficitKcal || 0) > 0 || (p.activityMinPerWeek || 0) > 0;
    const out = { days: [], weight: { mid: [], lo: [], hi: [] }, fg: { mid: [], lo: [], hi: [] }, fi: p.fastingInsulin != null ? { mid: [], lo: [], hi: [] } : null, homa: p.fastingInsulin != null ? [] : null, eqLossKg: U.round(eq, 1), actKcal: Math.round(actKcal) };
    for (let d = 0; d <= H; d = (d < H && d + step > H) ? H : d + step) {
      const loss = eq * (1 - Math.exp(-d / P.tauWeightDays));
      const r = 1 - Math.exp(-d / P.tauMetabolicDays);
      const ass = (p.fgAssumption || 0) * r;
      out.days.push(d);
      out.weight.mid.push(U.round(p.weightKg - loss, 2));
      out.weight.lo.push(U.round(p.weightKg - loss * (1 + P.bandFrac), 2));
      out.weight.hi.push(U.round(p.weightKg - loss * (1 - P.bandFrac), 2));
      const f = lifestyle ? adh * r : 0;
      out.fg.mid.push(U.round(p.fastingGlucose + P.fg.mid * f + ass, 1));
      out.fg.lo.push(U.round(p.fastingGlucose + P.fg.lo * f + ass, 1));
      out.fg.hi.push(U.round(p.fastingGlucose + P.fg.hi * f + ass, 1));
      if (out.fi) {
        out.fi.mid.push(U.round(p.fastingInsulin + P.fi.mid * f, 1));
        out.fi.lo.push(U.round(p.fastingInsulin + P.fi.lo * f, 1));
        out.fi.hi.push(U.round(p.fastingInsulin + P.fi.hi * f, 1));
        out.homa.push(U.round((out.fg.mid[out.fg.mid.length - 1] / 18) * out.fi.mid[out.fi.mid.length - 1] / 22.5, 2));
      }
    }
    const last = out.days.length - 1;
    out.summary = {
      horizonDays: out.days[last], weightEnd: out.weight.mid[last], weightDelta: U.round(out.weight.mid[last] - p.weightKg, 1),
      weightBand: [out.weight.lo[last], out.weight.hi[last]], fgEnd: out.fg.mid[last], fgBand: [out.fg.lo[last], out.fg.hi[last]],
      homaStart: p.fastingInsulin != null ? U.round((p.fastingGlucose / 18) * p.fastingInsulin / 22.5, 2) : null,
      homaEnd: out.homa ? out.homa[last] : null
    };
    out.notes = [
      'نموذج تعليمي: يعرض نطاقاً محتملاً لا وعداً.',
      'جودة الدليل في مراجعات نمط الحياة منخفضة (Cochrane) لذا النطاقات واسعة.',
      'الأعراض الأندروجينية (حب الشباب، الشعر الزائد) قد تتحسن مع نقص الوزن لكن لا نقدّرها كمياً.',
      'لا يتنبأ بالدورة الشهرية.',
      (p.fgAssumption ? 'يتضمن افتراضاً أدخله الطبيب لأثر دوائي على سكر الصيام: ' + p.fgAssumption + ' ملغ/دل — ليس تنبؤاً.' : 'لا أثر دوائي مفترض في هذا السيناريو.')
    ];
    return out;
  };

  T.compare = function (base, plan) {
    const a = T.simulate(Object.assign({}, base, { deficitKcal: 0, activityMinPerWeek: 0, adherence: 1, fgAssumption: 0 }));
    const b = T.simulate(Object.assign({}, base, plan));
    return { baseline: a, scenario: b };
  };

  T.scenarios = function (base) {
    return [
      { id: 'current', name: 'استمرار الوضع الحالي', plan: { deficitKcal: 0, activityMinPerWeek: 0, adherence: 1 } },
      { id: 'diet', name: 'نظام غذائي (عجز 300 سعر، التزام 80%)', plan: { deficitKcal: 300, activityMinPerWeek: 0, adherence: 0.8 } },
      { id: 'diet_act', name: 'نظام + مشي 150 دقيقة/أسبوع (التزام 80%)', plan: { deficitKcal: 300, activityMinPerWeek: 150, adherence: 0.8 } },
      { id: 'full', name: 'التزام كامل بالنظام والنشاط', plan: { deficitKcal: 300, activityMinPerWeek: 150, adherence: 1 } }
    ].map(s => Object.assign({ result: T.simulate(Object.assign({}, base, s.plan)) }, s));
  };

  // مرجع توضيحي (حالة واحدة منشورة): Shamanna 2025 — −12.4% وزن خلال 360 يوماً (تقريب خطي للرسم فقط)
  T.shamannaRef = function (w0, days) { return days.map(d => U.round(w0 * (1 - 0.124 * Math.min(1, d / 360)), 2)); };

  g.OvaTwin = T;
  if (typeof module !== 'undefined' && module.exports) module.exports = T;
})(globalThis);
