/* واجهة OvaSense — عرض وتفاعل. المنطق في OvaEngine/OvaAI/OvaSecurity. */
(function () {
  'use strict';
  const U = OvaUtil, E = OvaEngine, AI = OvaAI, SEC = OvaSecurity, KB = OvaKB, TW = OvaTwin, CH = OvaChat, KT = OvaKitchen, BD = OvaBody;
  const esc = U.esc, $ = s => document.querySelector(s);
  const LS = 'ovasense.v1';
  let env = null, tab = 'home', flash = {}, timer = null, dietSeed = 0, tourI = -1;

  const TABS = [['home', 'الرئيسية'], ['measure', 'قياساتي'], ['food', 'الغذاء'], ['symptoms', 'الأعراض والنزيف'], ['fertility', 'الخصوبة والدورة'], ['twin', 'التوأم الرقمي'], ['chat', 'المساعد'], ['doctor', 'الطبيب'], ['device', 'الجهاز'], ['lab', 'مختبر الأمان'], ['about', 'عن المشروع']];

  // ---------- حفظ/تحميل ----------
  function save() { try { localStorage.setItem(LS, JSON.stringify(env.S)); } catch (e) { /* التخزين غير متاح */ } }
  function load() { try { const j = localStorage.getItem(LS); if (j) { const s = JSON.parse(j); if (s && s.v === 1 && s.device && s.gate) return s; } } catch (e) { } return null; }

  // ---------- أدوات واجهة ----------
  const fl = k => flash[k] ? '<div class="alert ' + (flash[k].kind || 'info') + '" role="status">' + flash[k].html + '</div>' : '';
  const setFlash = (k, html, kind) => { flash[k] = { html, kind }; };
  const val = id => { const e = document.getElementById(id); return e ? e.value : ''; };
  const num = id => Number(val(id));
  const chk = id => { const e = document.getElementById(id); return !!(e && e.checked); };
  const pill = (t, k) => '<span class="pill ' + (k || '') + '">' + esc(t) + '</span>';
  const tile = (label, v, sub) => '<div class="tile"><small>' + esc(label) + '</small><div class="v">' + v + '</div><div class="s">' + (sub || '') + '</div></div>';

  function chart(o) {
    const W = o.w || 640, H = o.h || 220, m = { l: 42, r: 10, t: 10, b: 24 };
    const x = v => m.l + (v - o.x0) / (o.x1 - o.x0) * (W - m.l - m.r);
    const y = v => H - m.b - (v - o.y0) / (o.y1 - o.y0) * (H - m.t - m.b);
    let s = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(o.label || '') + '">';
    for (let i = 0; i <= 4; i++) { const v = o.y0 + (o.y1 - o.y0) * i / 4; s += '<line class="gridl" x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + y(v) + '" y2="' + y(v) + '"/><text x="' + (m.l - 4) + '" y="' + (y(v) + 4) + '" text-anchor="end">' + U.round(v, o.yd || 0) + '</text>'; }
    (o.xt || []).forEach(t => { s += '<text x="' + x(t.v) + '" y="' + (H - 6) + '" text-anchor="' + (t.v >= o.x1 ? 'end' : t.v <= o.x0 ? 'start' : 'middle') + '">' + esc(t.l) + '</text>'; });
    if (o.range) s += '<rect class="rng" x="' + m.l + '" width="' + (W - m.l - m.r) + '" y="' + y(o.range.high) + '" height="' + Math.max(0, y(o.range.low) - y(o.range.high)) + '"/>';
    (o.bands || []).forEach(b => {
      const top = b.hi.map(p => x(p[0]) + ',' + y(p[1])).join(' '), bot = b.lo.slice().reverse().map(p => x(p[0]) + ',' + y(p[1])).join(' ');
      s += '<polygon class="band" points="' + top + ' ' + bot + '"/>';
    });
    (o.lines || []).forEach(l => { if (l.pts.length) s += '<polyline class="' + l.cls + '" points="' + l.pts.map(p => x(p[0]).toFixed(1) + ',' + y(p[1]).toFixed(1)).join(' ') + '"/>'; });
    (o.dots || []).forEach(d => { s += '<circle class="' + d.cls + '" cx="' + x(d.x) + '" cy="' + y(d.y) + '" r="' + (d.r || 3.5) + '"><title>' + esc(d.title || '') + '</title></circle>'; });
    return s + '</svg>';
  }

  // ---------- جدول «ماذا يقرأ الجهاز» ----------
  const READ_TABLE = [
    ['جلوكوز السائل الخلالي', 'يقيسه الجهاز', 'كل 5 دقائق', 'ملغ/دل', 'مقدَّر وليس دماً مباشراً؛ يتأخر 5–10 دقائق ويُعايَر بقياس دم.'],
    ['مؤشر هرموني (HM1)', 'يقيسه الجهاز', 'كل ساعة', 'وحدات اعتباطية', 'المؤشر الفعلي يُحدَّد بعد مرحلة التحقق؛ لا يُشخّص.'],
    ['التدفق المقاس (حساس التدفق)', 'يقيسه الجهاز', 'عند كل جرعة', 'µL', 'مقارنة بالمأمور به؛ انحراف أكثر من 20% يوقف التوصيل.'],
    ['الخزان، البطارية، عمر الرقعة، جودة الإشارة', 'يقيسه الجهاز', 'مستمر', '% / µL / يوم', 'تنبيهات استباقية للاستبدال والمعايرة.'],
    ['الوزن، الضغط، قياس دم مرجعي', 'تُدخله المريضة', 'عند الحاجة', 'كغ / ملم زئبق / ملغ/دل', 'القياس المرجعي يعاير المستشعر.'],
    ['الوجبات، الأعراض، النزيف', 'تُدخله المريضة', 'يومياً', 'جم كربوهيدرات / 0–3 / PBAC', 'أساس الارتباطات وتحليل أنماط النزيف.'],
    ['التحاليل المخبرية، الخطة، الحدود', 'يُدخله الطبيب', 'دورياً', '—', 'الخطة موقَّعة رقمياً ويفرضها الجهاز.'],
    ['الوقت ضمن النطاق، حاجة التحليل، أنماط النزيف، الارتباطات', 'يستنتجه الذكاء الاصطناعي', 'مستمر', '—', 'دعم قرار فقط؛ لا ينفّذ جرعات.']
  ];
  const readTable = () => '<div class="scroll"><table><thead><tr><th>القيمة</th><th>المصدر</th><th>التكرار</th><th>الوحدة</th><th>ملاحظة</th></tr></thead><tbody>' + READ_TABLE.map(r => '<tr>' + r.map((c, i) => '<td>' + (i === 1 ? pill(c, c.startsWith('يقيس') ? 'ok' : c.startsWith('يستنتج') ? 'info' : '') : esc(c)) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';

  // ---------- العروض ----------
  function arrow(S) {
    const g = S.readings.filter(r => r.type === 'glucose');
    if (g.length < 7) return '→';
    const a = g[g.length - 1].value, b = g[g.length - 7].value, d = a - b;
    return d > 10 ? '↑' : d > 4 ? '↗' : d < -10 ? '↓' : d < -4 ? '↘' : '→';
  }
  function vHome() {
    const S = env.S, d = E.derive(env), now = S.clock.now;
    const g = d.latestGlucose, s7 = d.stats7;
    const w0 = now - U.DAY;
    const pts = S.readings.filter(r => r.type === 'glucose' && r.t >= w0).map(r => [r.t, r.value]);
    const maxY = Math.max(180, ...pts.map(p => p[1]) , 0) + 10;
    const xt = []; for (let h = 0; h <= 24; h += 6) xt.push({ v: w0 + h * U.HOUR, l: U.hhmm(w0 + h * U.HOUR) });
    const dots = env.gate.s.deliveries.filter(x => x.t >= w0).map(x => ({ x: x.t, y: 52, cls: 'd1', title: 'جرعة ' + x.deliveredUL + ' µL ' + U.hhmm(x.t) }))
      .concat(S.meals.filter(m => m.t >= w0 && m.t <= now).map(m => ({ x: m.t, y: maxY - 4, cls: 'd2', r: 4, title: m.name + ' ' + m.carbs + ' جم ' + U.hhmm(m.t) })));
    const bn = d.bloodNeed;
    const alerts = d.alerts.map(a => '<div class="alert ' + (a.lvl === 'danger' ? 'danger' : a.lvl === 'warn' ? 'warn' : 'info') + '">' + esc(a.text) + '</div>').join('');
    const f = d.fert, ds0 = S.device, due = S.labs.lastLabT ? Math.ceil(S.labs.labIntervalDays - (now - S.labs.lastLabT) / U.DAY) : null;
    const rem = [];
    if (due != null) rem.push(due <= 0 ? 'موعد تحليل الدم متأخر (الفاصل ' + S.labs.labIntervalDays + ' يوماً).' : 'تحليل الدم القادم بعد ' + due + ' يوماً.');
    if (f && !f.empty && f.phase === 'fertile') rem.push('أنتِ ضمن نافذة الخصوبة المقدّرة؛ إن كنتِ تتابعين LH فسجّلي اختبار اليوم.');
    if (f && !f.empty && f.late) rem.push('الدورة متأخرة عن المتوقع (اليوم ' + f.dayOfCycle + '). سجّلي النزيف عند بدئه.');
    if (ds0.patchApplied && !(ds0.calib && ds0.calib.t >= ds0.patchAppliedAt)) rem.push('لم تُعايَر الرقعة الحالية بقياس دم مرجعي بعد.');
    const note = d.doctorNote ? '<div class="alert info"><b>رسالة الطبيب</b> · ' + U.fmtDT(d.doctorNote.t) + '<br>' + esc(d.doctorNote.text) + '</div>' : '';
    const stop = ds0.faultLatched ? '<button class="btn" data-act="clearFault">استئناف التوصيل</button>' : '<button class="btn dng" data-act="estop" aria-label="إيقاف التوصيل فوراً">⏹ إيقاف التوصيل فوراً</button>';
    return '<h2>أهلاً، ' + esc(S.patient.name) + '</h2>' + fl('home') + alerts + note +
      '<div class="card" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;justify-content:space-between"><div><b>الإيقاف الطارئ</b><div class="small mut">يوقف أي جرعة قادمة فوراً. الاستئناف يدوي، ويُسجَّل الحدث في سجل التدقيق.</div></div>' + stop + '</div>' +
      '<div class="grid g3" style="margin-top:12px">' +
      tile('الجلوكوز الحالي (سائل خلالي)', g ? g.value + ' <span class="small">ملغ/دل ' + arrow(S) + '</span>' : '—', g ? 'عند ' + g.when + (g.q != null ? ' · جودة ' + g.q : '') : 'لا قراءة') +
      tile('الوقت ضمن النطاق (7 أيام)', s7.n ? s7.tirPct + '%' : '—', s7.n ? 'النطاق ' + S.range.low + '–' + S.range.high + ' · المتوسط ' + s7.mean : '') +
      tile('الجرعة القادمة', d.nextDose ? d.nextDose.doseUL + ' µL' : '—', d.nextDose ? esc(d.nextDose.when) : 'لا خطة') +
      tile('الالتزام (7 أيام)', d.adherencePct != null ? d.adherencePct + '%' : '—', 'جرعات منفّذة/مجدولة') +
      tile('جودة الإشارة', d.quality != null ? d.quality : '—', d.quality != null && d.quality < 0.6 ? 'منخفضة: عايري' : 'آخر 6 ساعات') +
      tile('كتلة الجسم BMI', d.bmi ? d.bmi.v : '—', d.bmi ? esc(d.bmi.cat) + ' · ' + d.weight + ' كغ' : '') +
      tile('الدورة', f && !f.empty ? 'يوم ' + f.dayOfCycle : '—', f && !f.empty ? esc(OvaFertility.PHASE_AR[f.phase]) : 'سجّلي أول يوم نزيف') +
      tile('هل أحتاج تحليل دم؟', pill(bn.label, bn.level === 'high' ? 'danger' : bn.level === 'medium' ? 'warn' : 'ok'), 'الدرجة ' + bn.score + '/100') +
      '</div>' +
      (rem.length ? '<div class="card" style="margin-top:12px"><h3>تذكيرات</h3><ul>' + rem.map(r => '<li>' + esc(r) + '</li>').join('') + '</ul></div>' : '') +
      '<div class="card" style="margin-top:12px"><h3>الجلوكوز خلال 24 ساعة</h3>' +
      chart({ label: 'الجلوكوز خلال 24 ساعة', x0: w0, x1: now, y0: 50, y1: maxY, range: S.range, xt, lines: [{ cls: 'l1', pts: pts.filter((p, i) => i % 2 === 0) }], dots }) +
      '<p class="small mut">المنطقة الخضراء = النطاق الذي حدده الطبيب · النقاط الوردية = جرعات الجهاز · الصفراء = وجبات.</p></div>' +
      '<div class="grid g2" style="margin-top:12px"><div class="card"><h3>لماذا هذا التقدير؟</h3>' + (bn.reasons.length ? '<ul>' + bn.reasons.map(r => '<li>' + esc(r.text) + '</li>').join('') + '</ul>' : '<p>لا أسباب تستدعي التحليل الآن.</p>') +
      '<div class="row"><button class="btn sec sm" data-act="goto" data-v="measure">سجّلي قياس دم مرجعي</button></div></div>' +
      '<div class="card"><h3>مراجعة الذكاء الاصطناعي للخطة</h3>' + d.review.map(r => '<div class="alert info">' + esc(r.text) + (r.requiresDoctor ? ' <span class="small mut">(يتطلب موافقة وتوقيع الطبيب)</span>' : '') + '</div>').join('') + '<p class="small mut">الاقتراحات ضمن حدود الخطة فقط ولا تُنفَّذ تلقائياً.</p></div></div>' +
      '<details class="card" style="margin-top:12px"><summary><b>ماذا يقرأ الجهاز بالضبط؟</b></summary>' + readTable() + '</details>';
  }

  function vMeasure() {
    const S = env.S;
    const man = S.readings.filter(r => r.src === 'manual').slice(-12).reverse();
    const lbl = { weight: 'وزن (كغ)', bp: 'ضغط (ملم زئبق)', lab_glucose: 'قياس دم مرجعي (ملغ/دل)' };
    return '<h2>قياساتي</h2>' + fl('measure') +
      '<div class="card"><h3>تسجيل قياس جديد</h3><div class="row">' +
      '<label>النوع<select id="m-type"><option value="weight">الوزن (كغ)</option><option value="bp">الضغط (انقباضي/انبساطي)</option><option value="lab_glucose">قياس دم مرجعي — يعاير المستشعر</option></select></label>' +
      '<label>القيمة<input id="m-val" type="number" step="0.1" inputmode="decimal" style="width:110px"></label>' +
      '<label>انبساطي (للضغط)<input id="m-dia" type="number" step="1" inputmode="numeric" style="width:110px"></label>' +
      '<button class="btn" data-act="addMeasure">حفظ</button></div>' +
      '<p class="small mut">القياس المرجعي للجلوكوز يُستخدم لمعايرة قراءة السائل الخلالي ويرفع جودة الإشارة.</p></div>' +
      '<div class="card" style="margin-top:12px"><h3>آخر القياسات اليدوية</h3>' + (man.length ? '<div class="scroll"><table><thead><tr><th>الوقت</th><th>النوع</th><th>القيمة</th></tr></thead><tbody>' + man.map(r => '<tr><td>' + U.fmtDT(r.t) + '</td><td>' + esc(lbl[r.type] || r.type) + '</td><td>' + r.value + (r.dia ? '/' + r.dia : '') + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="mut">لا توجد قياسات يدوية بعد.</p>') +
      '<div class="row"><button class="btn sec sm" data-act="exportCsv">تنزيل القراءات (CSV)</button></div></div>';
  }

  function vFood() {
    const S = env.S, d = E.derive(env), p = S.patient, plan = AI.dietPlan({ weightKg: d.weight, heightCm: p.heightCm, age: p.age, activity: p.activity, goal: p.goal }, Math.floor(S.clock.now / U.DAY) + dietSeed);
    return '<h2>الغذاء الشخصي</h2>' + fl('food') +
      '<div class="card"><h3>ملفي</h3><div class="row">' +
      '<label>الطول (سم)<input id="p-h" type="number" value="' + p.heightCm + '" style="width:90px"></label>' +
      '<label>العمر<input id="p-a" type="number" value="' + p.age + '" style="width:80px"></label>' +
      '<label>النشاط<select id="p-act">' + [['low', 'خفيف'], ['moderate', 'متوسط'], ['high', 'عالٍ']].map(o => '<option value="' + o[0] + '"' + (p.activity === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></label>' +
      '<label>الهدف<select id="p-goal"><option value="maintain"' + (p.goal === 'maintain' ? ' selected' : '') + '>تثبيت الوزن</option><option value="lose"' + (p.goal === 'lose' ? ' selected' : '') + '>إنقاص تدريجي</option></select></label>' +
      '<button class="btn" data-act="saveProfile">تحديث الخطة</button></div></div>' +
      '<div class="card" style="margin-top:12px"><h3>خطة اليوم · ' + plan.energy.target + ' سعراً</h3><div class="scroll"><table><thead><tr><th>الوجبة</th><th>المكوّنات</th><th>سعرات</th><th>كربوهيدرات</th></tr></thead><tbody>' +
      plan.meals.map(m => '<tr><td><b>' + m.label + '</b></td><td>' + m.items.map(i => esc(i.ar) + (i.qty !== 1 ? ' ×' + i.qty : '') + ' <span class="small mut">(' + esc(i.serving) + ')</span>').join('<br>') + '</td><td>' + m.kcal + '</td><td>' + m.carb + ' جم</td></tr>').join('') +
      '</tbody></table></div><p><b>المجموع:</b> ' + plan.totals.kcal + ' سعراً · كربوهيدرات ' + plan.totals.carb + ' جم · بروتين ' + plan.totals.protein + ' جم · ألياف ' + plan.totals.fiber + ' جم</p>' +
      '<p class="small mut">' + plan.notes.map(esc).join(' ') + '</p><div class="row"><button class="btn sec sm" data-act="shuffleDiet">بدّلي الخيارات</button></div></div>' +
      vKitchen(plan) +
      '<div class="card" style="margin-top:12px"><h3>سجّلي وجبة (تؤثر على نموذج الجلوكوز)</h3><div class="row"><label>الاسم<input id="ml-n" value="وجبة" style="width:140px"></label><label>كربوهيدرات (جم)<input id="ml-c" type="number" value="60" style="width:110px"></label><button class="btn" data-act="addMeal">تسجيل الآن</button></div></div>' +
      '<div class="card" style="margin-top:12px"><h3>مكمل أو عشب؟ اسألي قبل الاستخدام</h3><div class="row"><label>الاسم<input id="sp-q" placeholder="مثال: ميو إينوزيتول" style="width:220px"></label><label>أدويتي (اختياري)<input id="sp-m" value="' + esc(p.meds) + '" style="width:200px"></label><label><span>حامل؟</span><input id="sp-p" type="checkbox"' + (p.pregnant ? ' checked' : '') + '></label><label><span>ضغط مرتفع؟</span><input id="sp-h" type="checkbox"' + (p.hypertension ? ' checked' : '') + '></label><button class="btn" data-act="checkSupp">تحقق</button></div>' + fl('supp') + '<p class="small mut">محتوى تعليمي يحتاج مراجعة الطبيب/الصيدلي. إن لم أجد معلومة موثوقة لا أخمّن.</p></div>';
  }

  // ---------- وجبة من المكوّنات الموجودة ----------
  function pantry() { const S = env.S; if (!S.pantry) S.pantry = { have: [], slot: 'any', res: null, unknown: [] }; return S.pantry; }
  function vKitchen(plan) {
    const pt = pantry(), H = new Set(pt.have);
    const chips = KT.INGREDIENTS.map(i => '<button class="chip' + (H.has(i.id) ? ' on' : '') + '" data-act="pantryToggle" data-v="' + i.id + '" aria-pressed="' + H.has(i.id) + '">' + esc(i.ar) + '</button>').join(' ');
    const res = pt.res ? KT.suggest(pt.have, { slot: pt.slot, plan, limit: 3 }) : null;
    return '<div class="card" style="margin-top:12px" id="kitchen"><h3>وجبة من الموجود عندك</h3>' +
      '<p class="small mut">سجّلي المكوّنات المتوفرة في مطبخك، وأقترح لك وجبة تناسب خطتك اليومية (سعرات الوجبة، مؤشر جلايسيمي منخفض، ألياف وبروتين).</p>' +
      '<div class="row"><label>اكتبي المكوّنات<input id="pt-txt" placeholder="مثال: بيض، طماطم، بصل وسبانخ" style="width:260px"></label><button class="btn sec sm" data-act="pantryAdd">أضيفي</button>' +
      '<label>الوجبة<select id="pt-slot">' + [['any', 'أي وجبة'], ['b', 'الفطور'], ['l', 'الغداء أو العشاء'], ['s', 'وجبة خفيفة']].map(o => '<option value="' + o[0] + '"' + (pt.slot === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></label>' +
      '<button class="btn" data-act="suggestMeal">اقترحي وجبة</button>' + (pt.have.length ? '<button class="btn sec sm" data-act="pantryClear">مسح الكل</button>' : '') + '</div>' +
      (pt.unknown && pt.unknown.length ? '<p class="small" style="color:var(--warn)">لم أتعرف على: ' + pt.unknown.map(esc).join('، ') + '</p>' : '') +
      '<div style="margin-top:8px;line-height:2.2">' + chips + '</div>' +
      '<p class="small mut">المختار: ' + (pt.have.length ? pt.have.map(id => esc(KT.name(id))).join('، ') : 'لا شيء بعد') + '</p>' + fl('kit') +
      (res ? (res.length ? '<div class="grid g3" style="margin-top:8px">' + res.map(r =>
        '<div class="recipe"><h4>' + esc(r.ar) + '</h4><div class="small mut">' + esc(r.slotAr) + ' · ' + (r.servings !== 1 ? r.servings + ' حصة · ' : '') + 'مؤشر جلايسيمي ' + esc(r.gi) + '</div>' +
        '<p style="margin:6px 0"><b>' + r.kcal + '</b> سعراً · كربوهيدرات ' + r.carb + ' جم · بروتين ' + r.protein + ' جم · ألياف ' + r.fiber + ' جم</p>' +
        '<div class="small">من مطبخك: ' + r.used.map(esc).join('، ') + '</div>' + (r.missing.length ? '<div class="small miss">ينقصك: ' + r.missing.map(esc).join('، ') + '</div>' : '') +
        (r.extra.length ? '<div class="small mut">تحسّنها إضافة (اختياري): ' + r.extra.map(esc).join('، ') + '</div>' : '') +
        '<ul class="why small">' + r.why.map(w => '<li>' + esc(w) + '</li>').join('') + '</ul><p class="small">' + esc(r.steps) + '</p>' +
        '<button class="btn sm" data-act="logRecipe" data-n="' + esc(r.ar) + '" data-c="' + r.carb + '">سجّليها كوجبة</button></div>').join('') + '</div>'
        : '<div class="alert warn" style="margin-top:8px">لا توجد وصفة مناسبة بالمكوّنات الحالية. أضيفي مصدر بروتين (بيض، دجاج، عدس، تونة) أو خضاراً.</div>') : '') +
      '<p class="small mut">القيم تقريبية، والوصفات عامة تحتاج مراجعة أخصائية تغذية، خاصة مع الحمل أو أمراض الكلى.</p></div>';
  }

  function vSymptoms() {
    const S = env.S, d = E.derive(env), b = d.bleeding, today = U.dayKey(S.clock.now);
    const te = S.symptoms.find(x => x.date === today) || {};
    const sl = (id, label) => '<label>' + label + ' (<output id="o-' + id + '">' + (te[id] != null ? te[id] : 0) + '</output>)<input type="range" id="s-' + id + '" min="0" max="3" step="1" value="' + (te[id] != null ? te[id] : 0) + '" data-out="o-' + id + '"></label>';
    const sevCls = s => s === 'danger' ? 'danger' : s === 'warn' ? 'warn' : s === 'ok' ? 'ok' : 'info';
    return '<h2>الأعراض والنزيف</h2>' + fl('sym') +
      '<div class="grid g2"><div class="card"><h3>يوميات الأعراض · ' + today + '</h3><div class="grid g3">' + sl('acne', 'حب الشباب') + sl('hirsutism', 'الشعر الزائد') + sl('fatigue', 'الإرهاق') + sl('mood', 'تقلب المزاج') + sl('cramps', 'ألم الحوض') + sl('bloating', 'الانتفاخ') + sl('hairloss', 'تساقط الشعر') + sl('headache', 'الصداع') + '</div><p class="small mut">0 = لا شيء، 3 = شديد.</p><button class="btn" data-act="saveSymptoms">حفظ اليوم</button></div>' +
      '<div class="card"><h3>تسجيل النزيف · ' + today + '</h3><div class="row">' +
      '<label>فوط خفيفة<input id="b-pl" type="number" min="0" value="0" style="width:70px"></label><label>متوسطة<input id="b-pm" type="number" min="0" value="0" style="width:70px"></label><label>مشبعة<input id="b-ps" type="number" min="0" value="0" style="width:70px"></label>' +
      '<label>خثرات صغيرة<input id="b-cs" type="number" min="0" value="0" style="width:70px"></label><label>خثرات كبيرة<input id="b-cl" type="number" min="0" value="0" style="width:70px"></label></div>' +
      '<div class="row"><label><span>تدفق مفاجئ</span><input id="b-fl" type="checkbox"></label><label><span>تبقيع فقط</span><input id="b-sp" type="checkbox"></label><label><span>دوخة</span><input id="b-dz" type="checkbox"></label><button class="btn" data-act="saveBleeding">حفظ</button></div></div></div>' +
      '<div class="card" style="margin-top:12px"><h3>تحليل نمط النزيف</h3>' + (b.patterns.length ? b.patterns.map(p => '<div class="alert ' + sevCls(p.sev) + '">' + esc(p.text) + '</div>').join('') : '<p class="mut">سجّلي دورتين على الأقل لاستخراج الأنماط.</p>') +
      (b.episodes.length ? '<div class="scroll"><table><thead><tr><th>البداية</th><th>النهاية</th><th>الأيام</th><th>PBAC</th><th>ملاحظات</th></tr></thead><tbody>' + b.episodes.map(e => '<tr><td>' + e.start + '</td><td>' + e.end + '</td><td>' + e.days + '</td><td>' + e.pbac + '</td><td>' + (e.spottingOnly ? 'تبقيع' : e.heavy ? 'غزير' : '') + '</td></tr>').join('') + '</tbody></table></div>' : '') +
      '<p class="small mut">' + esc(b.note) + '</p></div>' +
      '<div class="card" style="margin-top:12px"><h3>الأعراض مقابل القراءات</h3><div class="scroll"><table><thead><tr><th>القراءة</th><th>العرض</th><th>النتيجة</th></tr></thead><tbody>' + d.corr.map(c => '<tr><td>' + esc(c.a) + '</td><td>' + esc(c.b) + '</td><td>' + esc(c.text) + '</td></tr>').join('') + '</tbody></table></div><p class="small mut">سبيرمان على قيم يومية؛ يلزم 10 أيام على الأقل. الارتباط ليس سببية.</p></div>';
  }

  function vTwin() {
    const S = env.S, d = E.derive(env), tw = S.twin, bs = d.twinBase;
    const cmp = TW.compare(bs, { deficitKcal: tw.deficit, activityMinPerWeek: tw.act, adherence: tw.adh / 100, fgAssumption: tw.fgAssumption });
    const r = cmp.scenario, b = cmp.baseline, H = tw.horizon;
    const P = (arr) => r.days.map((x, i) => [x, arr[i]]);
    const w = chart({ label: 'الوزن المتوقع', x0: 0, x1: H, y0: Math.floor(Math.min(...r.weight.lo, bs.weightKg) - 1), y1: Math.ceil(bs.weightKg + 1), xt: [0, 0.25, 0.5, 0.75, 1].map(f => ({ v: H * f, l: String(Math.round(H * f)) })),
      bands: [{ lo: P(r.weight.lo), hi: P(r.weight.hi) }], lines: [{ cls: 'l1', pts: P(r.weight.mid) }, { cls: 'l3', pts: P(b.weight.mid) }, { cls: 'l4', pts: P(TW.shamannaRef(bs.weightKg, r.days)) }] });
    const gl = chart({ label: 'سكر الصيام المتوقع', x0: 0, x1: H, y0: Math.floor(Math.min(...r.fg.lo) - 2), y1: Math.ceil(Math.max(...r.fg.hi, bs.fastingGlucose) + 2), xt: [0, 0.5, 1].map(f => ({ v: H * f, l: String(Math.round(H * f)) })),
      bands: [{ lo: P(r.fg.lo), hi: P(r.fg.hi) }], lines: [{ cls: 'l1', pts: P(r.fg.mid) }, { cls: 'l3', pts: P(b.fg.mid) }] });
    const sm = r.summary;
    const sc = TW.scenarios(bs);
    const sld = (id, label, min, max, step, v, unit) => '<label>' + label + ' (<output id="o-' + id + '">' + v + '</output> ' + unit + ')<input type="range" id="' + id + '" min="' + min + '" max="' + max + '" step="' + step + '" value="' + v + '" data-out="o-' + id + '" data-twin="1"></label>';
    return '<h2>التوأم الرقمي · ماذا لو؟</h2>' + vBody(d) +
      '<div class="alert info" style="margin-top:12px">أداة تعليمية تعرض <b>نطاقاً محتملاً</b> لا وعداً. لا تتنبأ بالدورة الشهرية، ولا تقدّر الأعراض كمياً. بياناتك الحالية: وزن ' + bs.weightKg + ' كغ · سكر صائم ≈ ' + bs.fastingGlucose + ' ملغ/دل' + (bs.fastingInsulin != null ? ' · إنسولين صائم ' + bs.fastingInsulin : '') + '.</div>' +
      '<div class="card"><h3>سيناريوهات جاهزة</h3><div class="row">' + sc.map(s => '<button class="chip" data-act="preset" data-d="' + s.plan.deficitKcal + '" data-a="' + s.plan.activityMinPerWeek + '" data-p="' + Math.round(s.plan.adherence * 100) + '">' + esc(s.name) + '</button>').join('') + '</div>' +
      '<div class="grid g3" style="margin-top:8px">' + sld('t-def', 'عجز السعرات', 0, 600, 50, tw.deficit, 'سعر/يوم') + sld('t-act', 'نشاط', 0, 300, 30, tw.act, 'دقيقة/أسبوع') + sld('t-adh', 'الالتزام', 0, 100, 10, tw.adh, '%') +
      '<label>المدة<select id="t-hor" data-twin="1">' + [90, 180, 360].map(h => '<option' + (tw.horizon === h ? ' selected' : '') + '>' + h + '</option>').join('') + '</select></label>' +
      '<label>افتراض الطبيب لأثر دوائي على سكر الصيام (ملغ/دل)<input id="t-ass" type="number" step="1" value="' + tw.fgAssumption + '" data-twin="1"></label></div></div>' +
      '<div class="grid g2" style="margin-top:12px"><div class="card"><h3>الوزن (كغ) · المحور الأفقي: الأيام</h3>' + w + '<p class="small mut">الخط المتصل = السيناريو · المتقطع = دون تغيير · النقطي = مرجع توضيحي من حالة واحدة منشورة (Shamanna 2025، −12.4% خلال 360 يوماً) وليس توقعاً لك.</p></div>' +
      '<div class="card"><h3>سكر الصيام (ملغ/دل) · المحور الأفقي: الأيام</h3>' + gl + '<p class="small mut">النطاق من فترات الثقة المنشورة (Domecq 2013): −2.3 (−4.5 إلى −0.1).</p></div></div>' +
      '<div class="card" style="margin-top:12px"><h3>الخلاصة بعد ' + sm.horizonDays + ' يوماً</h3><ul><li>الوزن ≈ <b>' + sm.weightEnd + ' كغ</b> (تغيّر ' + sm.weightDelta + '، نطاق ' + sm.weightBand[0] + ' – ' + sm.weightBand[1] + ')</li><li>سكر الصيام ≈ <b>' + sm.fgEnd + '</b> (نطاق ' + sm.fgBand[0] + ' – ' + sm.fgBand[1] + ')</li>' + (sm.homaEnd != null ? '<li>HOMA-IR: ' + sm.homaStart + ' ← ' + sm.homaEnd + '</li>' : '') + '</ul>' + '<p class="small mut">' + r.notes.map(esc).join(' · ') + '</p></div>';
  }

  // ---------- توأم الجسم ثلاثي الأبعاد ----------
  function body(d) {
    const S = env.S;
    if (!S.body) S.body = { m: BD.defaults(S.patient.heightCm, d.weight), shape: null, unit: 'w', n: 12, scanAt: null };
    return S.body;
  }
  function bodyProjection() {
    const S = env.S, b = S.body, tw = S.twin, d = E.derive(env);
    const res = TW.simulate({ weightKg: b.m.weightKg, heightCm: b.m.heightCm, fastingGlucose: d.twinBase.fastingGlucose, fastingInsulin: null, horizonDays: 365, stepDays: 1, deficitKcal: tw.deficit, activityMinPerWeek: tw.act, adherence: tw.adh / 100 });
    return BD.project(b.m, res, b.unit, b.n);
  }
  function bodyTable(pr) {
    const rows = BD.FIELDS.filter(f => f.k !== 'heightCm').map(f => { const dl = pr.delta[f.k]; return '<tr><td>' + f.ar + '</td><td>' + pr.now[f.k] + '</td><td><b>' + pr.at[f.k] + '</b></td><td class="' + (dl < 0 ? 'dn' : dl > 0 ? 'up' : '') + '">' + (dl > 0 ? '+' : '') + dl + ' ' + f.unit + '</td></tr>'; }).join('');
    const rn = pr.ratiosNow, ra = pr.ratiosAt;
    return '<table class="deltas"><thead><tr><th>القياس</th><th>الآن</th><th>المتوقع</th><th>التغيّر</th></tr></thead><tbody>' + rows +
      '<tr><td>الخصر ÷ الطول</td><td>' + rn.whtr + '</td><td><b>' + ra.whtr + '</b></td><td>' + (ra.whtrHigh ? '<span style="color:var(--warn)">≥ 0.5</span>' : '<span style="color:var(--ok)">أقل من 0.5 ✓</span>') + '</td></tr>' +
      '<tr><td>الخصر ÷ الورك</td><td>' + rn.whr + '</td><td><b>' + ra.whr + '</b></td><td></td></tr>' +
      '<tr><td>مؤشر كتلة الجسم</td><td>' + rn.bmi + '</td><td><b>' + ra.bmi + '</b></td><td></td></tr></tbody></table>';
  }
  function vBody(d) {
    const b = body(d), m = b.m, u = BD.UNITS[b.unit], pr = bodyProjection();
    const inp = f => '<label>' + f.ar + ' (' + f.unit + ')<input id="bd-' + f.k + '" type="number" step="0.5" value="' + m[f.k] + '" style="width:88px"></label>';
    const label = b.n === 0 ? 'الآن' : 'بعد ' + b.n + ' ' + u.ar;
    return '<div class="card" id="bodytwin"><h3>توأم الجسم ثلاثي الأبعاد</h3>' + fl('body') +
      '<p class="small mut">أدخلي قياساتك بشريط القياس، فيُبنى مجسّم يشبه نسب جسمك. حرّكي شريط الزمن لترَي كيف قد تتغير هيئتك وقياساتك لو التزمتِ بالخطة الغذائية والرياضية الحالية في الأسفل (عجز ' + env.S.twin.deficit + ' سعر/يوم، نشاط ' + env.S.twin.act + ' دقيقة/أسبوع، التزام ' + env.S.twin.adh + '%).</p>' +
      (m.estimated ? '<div class="alert info">القياسات الحالية تقديرية من طولك ووزنك. أدخلي قياساتك الحقيقية ليصبح المجسّم أدق.</div>' : '') +
      '<div class="row">' + BD.FIELDS.map(inp).join('') + '<button class="btn" data-act="saveBody">بناء المجسّم</button></div>' +
      '<div class="body3d" style="margin-top:12px"><div><canvas id="holo" class="holo" width="420" height="560" aria-label="مجسّم ثلاثي الأبعاد للجسم: الحالي والمتوقع"></canvas>' +
      '<div class="legend3d"><span><i style="background:#ff9ccb"></i>الآن</span><span><i style="background:#2dd4c8"></i>' + esc(label) + '</span><span class="mut">اسحبي للتدوير</span></div></div>' +
      '<div><div class="row"><label>الوحدة<select id="bd-unit">' + Object.keys(BD.UNITS).map(k => '<option value="' + k + '"' + (b.unit === k ? ' selected' : '') + '>' + BD.UNITS[k].ar + '</option>').join('') + '</select></label>' +
      '<label style="flex:1;min-width:200px">شريط الزمن: <output id="bd-nl">' + esc(label) + '</output><input id="bd-n" type="range" min="0" max="' + u.max + '" step="1" value="' + Math.min(b.n, u.max) + '"></label></div>' +
      '<div class="scroll" id="bd-table">' + bodyTable(pr) + '</div>' +
      (pr.capped ? '<p class="small" style="color:var(--warn)">الإسقاط محدود بسنة واحدة.</p>' : '') +
      '<p class="small mut">تقدير تعليمي من مسار الوزن في التوأم الرقمي، مع افتراض تقريبي لتوزيع النقص (الخصر ~1 سم لكل 1 كغ). الأجسام تختلف، والنتيجة نطاق محتمل لا وعد. نسبة الخصر إلى الطول أقل من 0.5 مؤشر عام لخطر أيضي أقل.</p></div></div>' +
      '<div class="card" style="margin-top:12px;background:var(--card-s)"><h3>مسح الجسم بالكاميرا (اختياري)</h3>' +
      '<p class="small">يحسّن شكل المجسّم من صورة أمامية لكامل الجسم. <b>خصوصيتك محفوظة:</b> تُعالَج الصورة داخل جهازك فقط وتتحول فوراً إلى ظلّ بخطوط تشبه الأشعة، <b>لا تُعرض ولا تُحفظ ولا تُرسل</b>. يُحفظ فقط ثلاث نسب (الكتفان/الخصر/الورك).</p>' +
      '<p class="small mut">للحصول على نتيجة أدق: قفي أمام جدار بلون واحد، بملابس ضيقة نسبياً، والذراعان بعيدتان قليلاً عن الجسم، والجسم كاملاً في الصورة.</p>' +
      '<div class="row"><label class="btn sec sm" style="cursor:pointer">التقاط أو اختيار صورة<input id="bd-scan" type="file" accept="image/*" capture="environment" hidden></label>' + (b.shape ? '<button class="btn sec sm" data-act="clearShape">إلغاء نسب المسح</button>' : '') + '</div>' +
      '<canvas id="xray" class="xray" hidden></canvas>' + fl('scan') +
      (b.shape ? '<p class="small">النسب المطبّقة على المجسّم: الكتفان ' + b.shape.shoulder + ' · الخصر ' + b.shape.waist + ' · الورك ' + b.shape.hip + '</p>' : '') + '</div></div>';
  }
  let holo = null;
  function startHolo() {
    if (holo) { cancelAnimationFrame(holo.raf); holo = null; }
    const cv = document.getElementById('holo'); if (!cv) return;
    const S = env.S, b = S.body; if (!b) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1); cv.width = 420 * dpr; cv.height = 560 * dpr;
    const st = { cv, angle: 0.5, drag: null, auto: true, raf: 0 };
    const build = () => { const pr = bodyProjection(); st.models = [{ rings: BD.rings(pr.at, b.shape), color: '#2dd4c8', glow: 10, width: 1.3 * dpr }, { rings: BD.rings(pr.now, b.shape), color: '#ff9ccb', alpha: b.n ? 0.35 : 0, glow: 0, width: 1 * dpr }]; };
    build(); st.build = build;
    const frame = () => { if (!document.body.contains(cv)) { holo = null; return; } if (st.auto && !st.drag) st.angle += 0.006; BD.draw(cv, st.models, st.angle); st.raf = requestAnimationFrame(frame); };
    cv.addEventListener('pointerdown', e => { st.drag = { x: e.clientX, a: st.angle }; st.auto = false; cv.setPointerCapture(e.pointerId); });
    cv.addEventListener('pointermove', e => { if (st.drag) st.angle = st.drag.a + (e.clientX - st.drag.x) * 0.012; });
    cv.addEventListener('pointerup', () => { st.drag = null; });
    holo = st; frame();
  }
  function updateBodyLive() {
    const b = env.S.body, u = BD.UNITS[b.unit], pr = bodyProjection();
    const lbl = b.n === 0 ? 'الآن' : 'بعد ' + b.n + ' ' + u.ar;
    const o = document.getElementById('bd-nl'); if (o) o.textContent = lbl;
    const tb = document.getElementById('bd-table'); if (tb) tb.innerHTML = bodyTable(pr);
    const lg = document.querySelector('.legend3d span:nth-child(2)'); if (lg) lg.innerHTML = '<i style="background:#2dd4c8"></i>' + esc(lbl);
    if (holo) holo.build();
  }
  async function scanBody(file) {
    const S = env.S, b = S.body;
    if (!file || !/^image\//.test(file.type)) { setFlash('scan', 'اختاري صورة.', 'warn'); render(); return; }
    let bmp = null, url = null;
    try {
      // نحمّل الصورة في الذاكرة فقط ونصغّرها، ثم نتخلص منها فوراً
      if (window.createImageBitmap) bmp = await createImageBitmap(file);
      else { url = URL.createObjectURL(file); bmp = await new Promise((ok, no) => { const im = new Image(); im.onload = () => ok(im); im.onerror = no; im.src = url; }); }
      const h = 220, w = Math.max(60, Math.round(h * bmp.width / bmp.height));
      const c = document.createElement('canvas'); c.width = w; c.height = h; const cx = c.getContext('2d', { willReadFrequently: true });
      cx.drawImage(bmp, 0, 0, w, h); const data = cx.getImageData(0, 0, w, h).data;
      cx.clearRect(0, 0, w, h); c.width = c.height = 0;
      const sil = BD.silhouette(data, w, h); data.fill(0);
      const xr = document.getElementById('xray'); if (xr) { BD.drawXray(xr, sil, w, h); xr.hidden = false; }
      if (sil.ok && sil.shape) { b.shape = sil.shape; b.scanAt = S.clock.now; save(); setFlash('scan', 'تم المسح: طُبّقت نسب جسمك على المجسّم، ولم تُحفظ الصورة.', 'ok'); }
      else setFlash('scan', 'تعذّر عزل الجسم بوضوح. جرّبي خلفية بلون واحد وأن يظهر الجسم كاملاً. لم تُحفظ الصورة.', 'warn');
    } catch (e) { setFlash('scan', 'تعذّرت قراءة الصورة على هذا المتصفح.', 'warn'); }
    finally { if (bmp && bmp.close) bmp.close(); if (url) URL.revokeObjectURL(url); const fi = document.getElementById('bd-scan'); if (fi) fi.value = ''; }
    const keep = document.getElementById('xray'); const snap = keep && !keep.hidden ? keep : null;
    render();
    if (snap) { const nx = document.getElementById('xray'); if (nx) { nx.replaceWith(snap); } }
  }

  function vChat() {
    const S = env.S;
    const msgs = S.chat.map(m => '<div class="msg ' + (m.who === 'u' ? 'u' : 'b ' + (m.tone || '')) + '">' + esc(m.text) + (m.sources && m.sources.length ? '<small>المصدر: ' + m.sources.map(esc).join('، ') + '</small>' : '') + '</div>').join('');
    return '<h2>المساعد الشخصي</h2><div class="alert info">مساعد محلي يجيب من بياناتك المحفوظة على هذا الجهاز: قراءاتك، جرعاتك، تحاليلك، نزيفك، غذاؤك، والتوأم الرقمي. <b>ليس طبيباً ولا نموذجاً لغوياً مدرَّباً</b>، ولا يغيّر الجرعات.</div>' +
      '<div class="card"><div class="msgs" id="msgs" aria-live="polite">' + (msgs || '<p class="mut">اسأليني أي شيء عن بياناتك.</p>') + '</div>' +
      '<div class="row" style="margin-top:8px">' + CH.SUGGESTIONS.map(s => '<button class="chip" data-act="ask" data-q="' + esc(s) + '">' + esc(s) + '</button>').join('') + '</div>' +
      '<form id="chatform" class="row" style="margin-top:8px"><input id="chat-in" style="flex:1" placeholder="اكتبي سؤالك…" aria-label="سؤالك" autocomplete="off"><button class="btn" type="submit">إرسال</button><button type="button" class="btn sec" data-act="clearChat">مسح</button></form></div>';
  }

  function vDoctor() {
    const S = env.S, d = E.derive(env), gs = env.gate.s, plan = gs.plan, now = S.clock.now;
    const chain = SEC.verifyChain(gs.audit);
    const P = plan ? plan.items[0] : { doseUL: 25, times: ['07:00', '12:00', '17:00', '22:00'], singleMaxUL: 30, dailyCapUL: 110, minIntervalMin: 180 };
    const bn = d.bloodNeed, s7 = d.stats7;
    return '<h2>لوحة الطبيب</h2><div class="alert warn">في هذا النموذج، مفتاح الطبيب يُولَّد ويُحفظ داخل المتصفح للتجربة فقط. في المنتج الحقيقي يبقى المفتاح الخاص في جهاز/خدمة الطبيب ولا يُحفظ هنا.</div>' + fl('doc') +
      '<div class="grid g2"><div class="card"><h3>ملخص المريضة</h3><ul><li>الوقت ضمن النطاق (7 أيام): <b>' + (s7.n ? s7.tirPct + '%' : '—') + '</b> · CV ' + (s7.n ? s7.cv + '%' : '—') + '</li><li>جودة الإشارة: ' + (d.quality != null ? d.quality : '—') + '</li><li>الالتزام: ' + (d.adherencePct != null ? d.adherencePct + '%' : '—') + '</li><li>حاجة التحليل: ' + esc(bn.label) + ' (' + bn.score + ')</li><li>أنماط النزيف: ' + (d.bleeding.patterns.map(p => esc(p.text)).join('، ') || '—') + '</li></ul>' +
      '<h3>مقترحات الذكاء الاصطناعي (استشارية)</h3>' + d.review.map(r => '<div class="alert info">' + esc(r.text) + '</div>').join('') + '<p class="small mut">لا ينفّذ الذكاء الاصطناعي أي جرعة: أي إجراء يتطلب خطة أو أمراً موقَّعاً منك.</p></div>' +
      '<div class="card"><h3>التحاليل المخبرية</h3><div class="row"><label>إنسولين صائم<input id="l-ins" type="number" step="0.1" value="' + (S.labs.fastingInsulin != null ? S.labs.fastingInsulin : '') + '" style="width:110px"></label><label>HbA1c %<input id="l-a1c" type="number" step="0.1" value="' + (S.labs.hba1c != null ? S.labs.hba1c : '') + '" style="width:100px"></label><label>الفاصل (يوم)<input id="l-int" type="number" value="' + S.labs.labIntervalDays + '" style="width:90px"></label><button class="btn" data-act="saveLabs">حفظ وتسجيل تحليل اليوم</button></div><p class="small mut">آخر تحليل: ' + (S.labs.lastLabT ? U.fmtDT(S.labs.lastLabT) : '—') + '</p>' +
      '<h3>نطاق الجلوكوز المستهدف</h3><div class="row"><label>أدنى<input id="r-lo" type="number" value="' + S.range.low + '" style="width:80px"></label><label>أعلى<input id="r-hi" type="number" value="' + S.range.high + '" style="width:80px"></label><button class="btn sec" data-act="saveRange">حفظ</button></div></div></div>' +
      '<div class="card" style="margin-top:12px"><h3>خطة العلاج الموقَّعة ' + (plan ? '(إصدار ' + plan.version + ' · مفتاح ' + plan.keyId + ')' : '(لا خطة)') + '</h3>' +
      '<div class="row"><label>الجرعة (µL)<input id="pl-dose" type="number" value="' + P.doseUL + '" style="width:90px"></label><label>الأوقات<input id="pl-times" class="ltr" value="' + P.times.join(',') + '" style="width:200px"></label><label>الحد الأقصى للجرعة<input id="pl-sm" type="number" value="' + P.singleMaxUL + '" style="width:90px"></label><label>السقف اليومي<input id="pl-dc" type="number" value="' + P.dailyCapUL + '" style="width:90px"></label><label>الفاصل (دقيقة)<input id="pl-mi" type="number" value="' + P.minIntervalMin + '" style="width:90px"></label><label>عند فقدان الإشارة<select id="pl-sl"><option value="continue_plan">متابعة الخطة</option><option value="hold">تعليق</option></select></label><button class="btn" data-act="signPlan">توقيع وإرسال للجهاز</button></div>' +
      '<p class="small mut">حدود الجهاز الصلبة: جرعة واحدة ≤ ' + OvaDevice.HARD.singleMaxUL + ' µL، يومياً ≤ ' + OvaDevice.HARD.dailyMaxUL + ' µL؛ لا يقبل الجهاز خطة تتجاوزها. المادة: ' + esc(E.SUBSTANCE) + ' (نموذج عام).</p>' +
      '<h3>أمر لمرة واحدة</h3><div class="row"><label>الجرعة (µL)<input id="cmd-dose" type="number" value="10" style="width:90px"></label><button class="btn sec" data-act="sendCmd">توقيع وتنفيذ</button></div></div>' +
      '<div class="card" style="margin-top:12px"><h3>رسالة إلى المريضة</h3><div class="row"><label style="flex:1">النص<textarea id="dn-t" rows="2" style="width:100%" maxlength="400">' + esc(S.doctorNote ? S.doctorNote.text : '') + '</textarea></label><button class="btn" data-act="saveNote">إرسال</button></div><p class="small mut">تظهر في الصفحة الرئيسية للمريضة ويُسجَّل إرسالها. لا تغيّر الجرعات؛ التعديل يتطلب خطة موقَّعة.</p></div>' +
      '<div class="card" style="margin-top:12px"><h3>المفتاح</h3><p>المعرّف: <span class="mono">' + esc(S.doctor ? S.doctor.keyId : '—') + '</span> <button class="btn sec sm" data-act="rotateKey">إلغاء المفتاح وإصدار جديد</button></p></div>' +
      '<div class="card" style="margin-top:12px"><h3>سجل التدقيق المترابط (' + gs.audit.length + ' سجل) ' + (chain.ok ? pill('سليم ✓', 'ok') : pill('مكسور عند #' + chain.brokenAt, 'danger')) + '</h3><div class="scroll"><table><thead><tr><th>#</th><th>الوقت</th><th>النوع</th><th>الرمز</th><th>التفاصيل</th><th>البصمة</th></tr></thead><tbody>' +
      gs.audit.slice(-12).reverse().map(e => '<tr><td>' + e.i + '</td><td>' + U.fmtDT(e.t) + '</td><td>' + esc(e.type) + '</td><td>' + esc(e.code) + '</td><td>' + esc(e.detail) + '</td><td class="mono">' + e.hash.slice(0, 10) + '</td></tr>').join('') + '</tbody></table></div></div>';
  }

  function vDevice() {
    const S = env.S, ds = S.device, now = S.clock.now, age = env.device.ageDays(now), gs = env.gate.s;
    const sg = env.device.senseGlucose(now), hm = env.device.senseHM1(now);
    const alerts = env.device.alerts(now).map(a => '<div class="alert ' + (a.lvl === 'danger' ? 'danger' : a.lvl === 'warn' ? 'warn' : 'info') + '">' + esc(a.text) + '</div>').join('');
    const bar = (p) => '<div class="bar"><i style="width:' + U.clamp(p, 0, 100) + '%"></i></div>';
    const fb = (k, label) => '<label><span>' + label + '</span><input type="checkbox" data-act="fault" data-k="' + k + '"' + (ds.faults[k] ? ' checked' : '') + '></label>';
    return '<h2>محاكي الجهاز</h2>' + alerts + fl('dev') +
      '<div class="grid g3">' + tile('عمر الرقعة', ds.patchApplied ? U.round(age, 1) + ' يوم' : '—', 'العمر التصميمي ' + OvaDevice.PATCH_LIFE_DAYS + ' أيام') +
      tile('الخزان', U.round(ds.reservoirUL) + ' µL' + bar(ds.reservoirUL / OvaDevice.RESERVOIR_UL * 100), 'من 1000 µL') + tile('البطارية', U.round(ds.batteryPct) + '%' + bar(ds.batteryPct), ds.bleUp ? 'البلوتوث متصل' : 'البلوتوث منقطع') +
      tile('جلوكوز الآن', sg ? sg.value : '—', sg ? 'جودة ' + sg.q : '') + tile('HM1 الآن', hm != null ? hm : '—', 'وحدات اعتباطية') + tile('حالة التوصيل', ds.faultLatched ? pill('متوقف', 'danger') : pill('طبيعي', 'ok'), ds.faultLatched ? 'يلزم مسح العطل' : '') + '</div>' +
      '<div class="card" style="margin-top:12px"><h3>التحكم</h3><div class="row"><button class="btn" data-act="newPatch">تركيب رقعة جديدة</button><button class="btn sec" data-act="removePatch">إزالة الرقعة</button><button class="btn sec" data-act="toggleBle">' + (ds.bleUp ? 'قطع البلوتوث' : 'وصل البلوتوث') + '</button><button class="btn sec" data-act="clearFault">مسح العطل</button></div>' +
      '<h3 style="margin-top:10px">حقن أعطال (للاختبار)</h3><div class="row">' + fb('occlusion', 'انسداد') + fb('overflow', 'تدفق زائد') + fb('driftFast', 'انجراف سريع للحساس') + '</div></div>' +
      '<div class="card" style="margin-top:12px"><h3>ماذا يقرأ الجهاز بالضبط؟</h3>' + readTable() + '</div>' +
      '<div class="card" style="margin-top:12px"><h3>آخر الجرعات</h3>' + (gs.deliveries.length ? '<div class="scroll"><table><thead><tr><th>الوقت</th><th>المأمور</th><th>المُوصَّل</th><th>المصدر</th></tr></thead><tbody>' + gs.deliveries.slice(-8).reverse().map(x => '<tr><td>' + U.fmtDT(x.t) + '</td><td>' + x.commandedUL + ' µL</td><td>' + x.deliveredUL + ' µL</td><td>' + (x.source === 'plan' ? 'خطة موقَّعة' : 'أمر موقَّع') + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="mut">لا جرعات.</p>') + '</div>';
  }

  let labResults = [];
  function vLab() {
    const rows = labResults.map(r => '<tr><td>' + esc(r.name) + '</td><td class="mono">' + esc(r.expected.join(' / ')) + '</td><td class="mono">' + esc(r.got) + '</td><td>' + (r.pass ? pill('تم الصد ✓', 'ok') : pill('فشل', 'danger')) + '</td></tr>').join('');
    return '<h2>مختبر الأمان</h2><div class="alert info">جرّبي مهاجمة الجهاز بنفسك. كل محاولة تمر عبر البوابة نفسها التي تُنفَّذ بها الأوامر الحقيقية، وتُسجَّل في سجل التدقيق.</div>' +
      '<div class="card"><div class="row"><button class="btn" data-act="runAll">تشغيل كل الهجمات</button></div><div class="row" style="margin-top:8px">' + E.attacks.map(a => '<button class="chip" data-act="attack" data-id="' + a.id + '">' + esc(a.name) + '</button>').join('') + '</div></div>' +
      '<div class="card" style="margin-top:12px"><h3>النتائج</h3>' + (rows ? '<div class="scroll"><table><thead><tr><th>الهجوم</th><th>المتوقع</th><th>الناتج</th><th>الحالة</th></tr></thead><tbody>' + rows + '</tbody></table></div>' : '<p class="mut">لم تُشغَّل هجمات بعد.</p>') + '</div>' +
      '<div class="card" style="margin-top:12px"><h3>طبقات الحماية</h3><ol><li>توقيع ECDSA P-256 لكل خطة وأمر، ومفاتيح مُدرَجة وقابلة للإلغاء.</li><li>مدة صلاحية قصيرة + رقم تسلسل متزايد + nonce لمنع الإعادة.</li><li>الجهاز يفرض حدود الجرعة والسقف اليومي والفاصل ولو كانت الأوامر موقَّعة.</li><li>حدود صلبة في برنامج الجهاز لا يتجاوزها أي مخطط.</li><li>مراقبة التدفق: انحراف >20% يوقف التوصيل ويُنبّه.</li><li>الذكاء الاصطناعي لا يملك مفتاحاً: أوامره ترفض (UNSIGNED).</li><li>سجل تدقيق مترابط بالبصمات يكشف أي تعديل.</li></ol></div>';
  }

  function vAbout() {
    const refs = KB.REFERENCES.map(r => '<div class="ref"><span class="pill">' + r.lvl + '</span> <b>[' + r.id + ']</b> <a href="' + esc(r.url) + '" target="_blank" rel="noopener">' + esc(r.short) + '</a><div class="small mut">' + esc(r.full) + ' — ' + esc(r.use) + '</div></div>').join('');
    return '<h2>عن OvaSense AI</h2><div class="card"><p><b>الفكرة:</b> جهاز قابل للارتداء لإدارة متلازمة تكيّس المبايض <u>بعد</u> تشخيص الطبيب — لا يشخّص. قرص إلكتروني قابل لإعادة الاستخدام + رقعة حيوية قابلة للاستبدال بإبر دقيقة (استشعار وتوصيل بمسارين منفصلين) + تطبيق ودعم قرار بالذكاء الاصطناعي.</p>' +
      '<p><b>أهداف النظام:</b> تقليل الآثار الجانبية للأدوية، مراقبة يومية، تقليل تحاليل الدم غير الضرورية، التمييز بين أنماط النزيف، تتبع الأعراض، تغذية شخصية، جدولة الجرعات، ومتابعة الطبيب يومياً.</p>' +
      '<p><b>سير العمل:</b> الطبيب يشخّص ← الذكاء الاصطناعي يقرأ تحاليلها ← الرقعة تحمل ما اختاره الطبيب ← الجهاز يعطي قراءات يومية وجرعات حسب الوصفة ← مراجعة الذكاء الاصطناعي والطبيب.</p></div>' +
      '<div class="card" style="margin-top:12px"><h3>حدود هذا النموذج الأولي</h3><ul><li>بيانات الجهاز مُحاكاة؛ لا أجهزة حقيقية مرتبطة.</li><li>المساعد قواعد محلية، وليس نموذجاً لغوياً.</li><li>التوأم الرقمي تعليمي بنطاقات من دراسات منشورة.</li><li>قاعدة الأعشاب/المكملات تحتاج مراجعة سريرية.</li><li>مفتاح الطبيب محفوظ داخل المتصفح للتجربة فقط.</li></ul></div>' +
      '<div class="card" style="margin-top:12px"><h3>مفتاح مستوى الدليل</h3>' + KB.LEGEND.map(l => '<p><b>' + l.k + ' ' + l.t + ':</b> ' + l.d + '</p>').join('') + '</div>' +
      '<div class="card" style="margin-top:12px"><h3>المراجع</h3>' + refs + '</div>' +
      '<div class="card" style="margin-top:12px"><h3>الجولة</h3><div class="row"><button class="btn" data-act="tour">ابدأ الجولة (≈ 90 ثانية)</button><button class="btn dng sm" data-act="reset">إعادة ضبط البيانات التجريبية</button></div></div>';
  }


  // ---------- الخصوبة والدورة ----------
  function vFertility() {
    const S = env.S, d = E.derive(env), f = d.fert, today = U.dayKey(S.clock.now);
    const te = S.fertility.find(x => x.date === today) || {};
    const bl = new Set(S.bleeding.filter(b => !b.spotting).map(b => b.date));
    const head = '<h2>الخصوبة والدورة</h2>' + fl('fert') +
      '<div class="alert warn">تقديرات إحصائية من تواريخ دوراتك فقط؛ <b>ليست وسيلة لمنع الحمل</b> ولا تؤكد الإباضة ولا تشخّص. في المتلازمة قد تكون الدورات غير منتظمة فيصبح التقدير واسعاً. القرار الطبي لطبيبك.</div>';
    const logCard = '<div class="card" style="margin-top:12px"><h3>تسجيل اليوم · ' + today + '</h3><div class="row">' +
      '<button class="btn" data-act="startPeriod">بدأت دورتي اليوم</button>' +
      '<label>اختبار LH<select id="f-lh"><option value="">لم أُجرِ</option><option value="neg"' + (te.lh === 'neg' ? ' selected' : '') + '>سلبي</option><option value="pos"' + (te.lh === 'pos' ? ' selected' : '') + '>إيجابي</option></select></label>' +
      '<label>إفرازات عنق الرحم<select id="f-mu">' + [['', 'لم أسجّل'], ['dry', 'جافة'], ['sticky', 'لزجة'], ['creamy', 'كريمية'], ['eggwhite', 'شفافة مطاطية']].map(o => '<option value="' + o[0] + '"' + (te.mucus === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select></label>' +
      '<button class="btn sec" data-act="saveFert">حفظ</button></div>' +
      '<p class="small mut">نتيجة LH الإيجابية تُقرّب تقدير الإباضة (غالباً خلال يوم إلى يومين). في المتلازمة قد يرتفع LH مزمناً فتظهر نتائج إيجابية كاذبة. الإفرازات تُسجَّل للمتابعة ولا تدخل في الحساب.</p></div>';
    if (f.empty) return head + '<div class="card" style="margin-top:12px"><p>لا توجد بداية دورة مسجّلة. سجّلي أيام النزيف (تبويب «الأعراض والنزيف») أو اضغطي «بدأت دورتي اليوم».</p></div>' + logCard;
    const rng = (a, b) => a === b ? a : a + ' ← ' + b;
    const cal = OvaFertility.calendar(f, bl);
    const strip = '<div class="cal" role="img" aria-label="شريط أيام الدورة الحالية">' + cal.map(c => '<span class="cd ' + c.cls + '" title="' + c.key + '">' + c.day + '</span>').join('') + '</div>' +
      '<p class="small mut"><span class="lg bl"></span> نزيف · <span class="lg fr"></span> نافذة الخصوبة المقدّرة · <span class="lg ov"></span> الإباضة المقدّرة · <span class="lg np"></span> مجال الدورة القادمة · <span class="lg td"></span> اليوم</p>';
    const conf = f.confidence === 'low' ? pill('ثقة منخفضة', 'warn') : pill('ثقة متوسطة', 'info');
    const why = [];
    if (f.insufficient) why.push('عدد الدورات المسجّلة قليل (' + f.n + ')؛ سجّلي ثلاث دورات على الأقل لتحسين التقدير.');
    f.reasons.forEach(r => why.push(r));
    if (f.longGap) why.push('مرّ أكثر من 90 يوماً منذ آخر دورة: يُنصح بمراجعة الطبيب.');
    return head +
      '<div class="grid g3" style="margin-top:12px">' +
      tile('اليوم من الدورة', f.dayOfCycle, esc(OvaFertility.PHASE_AR[f.phase])) +
      tile('الدورة القادمة (تقدير)', '<span class="mono" style="font-size:15px">' + f.nextStart.lo.slice(5) + ' ← ' + f.nextStart.hi.slice(5) + '</span>', 'المنتصف ' + f.nextStart.key) +
      tile('متوسط طول الدورة', f.mean != null ? f.mean + ' يوماً' : '—', f.n ? 'من ' + f.n + ' دورة' + (f.sd != null ? ' · ±' + f.sd : '') : 'يلزم دورتان') +
      tile('الإباضة المقدّرة', '<span class="mono" style="font-size:15px">' + f.ovulation.key.slice(5) + '</span>', f.ovulation.basis === 'LH' ? 'من اختبار LH إيجابي' : 'من التقويم ±' + Math.round((U.dayKeyToT(f.ovulation.hi) - U.dayKeyToT(f.ovulation.lo)) / U.DAY / 2) + ' أيام') +
      tile('نافذة الخصوبة المقدّرة', '<span class="mono" style="font-size:15px">' + f.fertile.from.slice(5) + ' ← ' + f.fertile.to.slice(5) + '</span>', '6 أيام تنتهي بيوم الإباضة [23]') +
      tile('موثوقية التقدير', conf, f.irregular ? 'دورات غير منتظمة' : '') + '</div>' +
      '<div class="card" style="margin-top:12px"><h3>دورتك الحالية</h3>' + strip + '</div>' +
      '<div class="card" style="margin-top:12px"><h3>ماذا يعني هذا لحالتك؟</h3>' +
      (f.irregular ? '<div class="alert warn">دوراتك مصنّفة <b>غير منتظمة</b> وفق معايير الإرشاد الدولي [24]: ' + esc(f.reasons.join(' ')) + ' لذلك قد لا تحدث إباضة في كل دورة، وموعد النافذة أعلاه تقريبي جداً.</div>' : '') +
      (why.length && !f.irregular ? why.map(w => '<div class="alert info">' + esc(w) + '</div>').join('') : '') +
      (f.lens.length ? '<p class="small mut">أطوال دوراتك الأخيرة (أيام): <span class="mono">' + f.lens.join(' · ') + '</span></p>' : '') +
      '<p class="small mut">لم نحسب أي «نسبة احتمال حمل»: لا يوجد أساس موثوق لحسابها من هذه البيانات. التتبع يساعدك على فهم نمطك ومشاركته مع طبيبك.</p></div>' + logCard +
      (S.fertility.length ? '<div class="card" style="margin-top:12px"><h3>آخر التسجيلات</h3><div class="scroll"><table><thead><tr><th>التاريخ</th><th>LH</th><th>الإفرازات</th></tr></thead><tbody>' + S.fertility.slice(-8).reverse().map(x => '<tr><td>' + x.date + '</td><td>' + ({ pos: 'إيجابي', neg: 'سلبي' }[x.lh] || '—') + '</td><td>' + ({ dry: 'جافة', sticky: 'لزجة', creamy: 'كريمية', eggwhite: 'شفافة مطاطية' }[x.mucus] || '—') + '</td></tr>').join('') + '</tbody></table></div></div>' : '');
  }

  // ---------- الترحيب ----------
  let wstep = 0;
  function vWelcome() {
    const S = env.S, p = S.patient;
    const dots = '<div class="row" style="justify-content:center">' + [0, 1, 2].map(i => '<span class="pill ' + (i === wstep ? 'ok' : '') + '">' + (i + 1) + '</span>').join('') + '</div>';
    let body;
    if (wstep === 0) body = '<h2>مرحباً بك في OvaSense AI</h2><p>تطبيق لمتابعة إدارة متلازمة تكيّس المبايض <u>بعد</u> تشخيص الطبيب. لا يشخّص ولا يستبدل الطبيب. من أنتِ؟</p><div class="grid g2"><button class="btn" data-act="wRole" data-r="patient">أنا مريضة</button><button class="btn sec" data-act="wRole" data-r="doctor">أنا طبيب/ة (عرض لوحة الطبيب)</button></div>';
    else if (wstep === 1) body = '<h2>ملفك الشخصي</h2><div class="row">' +
      '<label>الاسم<input id="w-n" value="' + esc(p.name === 'مريضة تجريبية' ? '' : p.name) + '" placeholder="الاسم" style="width:160px"></label>' +
      '<label>العمر<input id="w-a" type="number" value="' + p.age + '" style="width:80px"></label>' +
      '<label>الطول (سم)<input id="w-h" type="number" value="' + p.heightCm + '" style="width:90px"></label>' +
      '<label>الوزن (كغ)<input id="w-w" type="number" step="0.1" value="' + p.weightKg + '" style="width:90px"></label></div>' +
      '<div class="row"><label><span>حامل؟</span><input id="w-p" type="checkbox"' + (p.pregnant ? ' checked' : '') + '></label><label><span>ضغط مرتفع؟</span><input id="w-hy" type="checkbox"' + (p.hypertension ? ' checked' : '') + '></label></div>' +
      '<div class="row"><button class="btn" data-act="wSave">التالي</button></div>';
    else body = '<h2>ربط الجهاز</h2><p>اربطي القرص (Pod) وركّبي الرقعة الحيوية. في هذا النموذج الجهاز محاكى، والربط يُنشئ رقعة جديدة ويسجّل الحدث.</p><div class="row"><button class="btn" data-act="wPair">ربط وتركيب رقعة</button><button class="btn sec" data-act="wDone">لاحقاً</button></div>';
    return '<div class="card welcome">' + fl('wel') + dots + body + '<hr><div class="row"><button class="btn sec sm" data-act="wDone">تخطي والبدء بالبيانات التجريبية</button></div><p class="small mut">البيانات تركيبية وتبقى في متصفحك فقط.</p></div>';
  }

  const VIEWS = { home: vHome, measure: vMeasure, food: vFood, symptoms: vSymptoms, twin: vTwin, chat: vChat, fertility: vFertility, doctor: vDoctor, device: vDevice, lab: vLab, about: vAbout };

  // ---------- العرض ----------
  function renderClock() {
    const c = env.S.clock;
    $('#clockbar').innerHTML = '<span class="t" id="simnow" title="الوقت المحاكى">' + U.fmtDT(c.now) + '</span>' +
      '<button class="btn sec sm" data-act="runToggle">' + (c.running ? '⏸ إيقاف' : '▶ تشغيل') + '</button>' +
      '<select id="scale" aria-label="سرعة المحاكاة">' + [[1, '1×'], [60, '60× (دقيقة/ث)'], [600, '600×'], [3600, '3600× (ساعة/ث)']].map(o => '<option value="' + o[0] + '"' + (c.scale === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select>' +
      '<button class="btn sec sm" data-act="jump" data-h="1">+1 ساعة</button><button class="btn sec sm" data-act="jump" data-h="24">+1 يوم</button>';
  }
  function renderNav() {
    const IC = {
      home: 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
      measure: 'M3 12h4l3-8 4 16 3-8h4',
      food: 'M12 6c-3-1-7 1-7 6.5S8 21 12 21s7-3 7-8.5S15 5 12 6zm0 0c0-2 1-3.5 3-4',
      symptoms: 'M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z',
      fertility: 'M12 21s-7-4.6-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.4-7 10-7 10z',
      twin: 'M12 2l9 5-9 5-9-5 9-5zM3 12l9 5 9-5M3 17l9 5 9-5',
      chat: 'M4 5h16v11H9l-5 4z',
      doctor: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3zM12 8v7M8.5 11.5h7',
      device: 'M5 8h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2zM12 12h.01',
      lab: 'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3',
      about: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 11v5M12 8h.01'
    };
    $('#nav').innerHTML = TABS.map(t => '<button data-act="goto" data-v="' + t[0] + '"' + (t[0] === tab ? ' aria-current="page"' : '') + '><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + (IC[t[0]] || IC.about) + '"/></svg><span>' + t[1] + '</span></button>').join('');
  }
  function render() {
    renderNav(); renderClock();
    $('#view').innerHTML = env.S.onboarded ? VIEWS[tab]() : vWelcome();
    const m = $('#msgs'); if (m) m.scrollTop = m.scrollHeight;
    if (tab === 'twin' && env.S.onboarded) startHolo();
  }
  const busyEditing = () => { const a = document.activeElement; return a && /INPUT|SELECT|TEXTAREA/.test(a.tagName) && a.id !== 'scale'; };

  // ---------- المؤقّت ----------
  function tick() {
    const c = env.S.clock;
    if (!c.running) return;
    E.advance(env, c.now + c.scale * 1000);
    save();
    const el = $('#simnow'); if (el) el.textContent = U.fmtDT(c.now);
    if (env.S.onboarded && (tab === 'home' || tab === 'device') && !busyEditing()) { $('#view').innerHTML = VIEWS[tab](); }
  }

  // ---------- الأفعال ----------
  async function act(name, el) {
    const S = env.S, now = S.clock.now, d = el ? el.dataset : {};
    switch (name) {
      case 'estop': S.device.faultLatched = 'USER_STOP'; env.gate.audit(now, 'DEVICE', 'USER_STOP', 'إيقاف طارئ من المريضة'); setFlash('home', 'أُوقف التوصيل. اضغطي «استئناف التوصيل» حين تكونين مستعدة.', 'warn'); break;
      case 'saveNote': { const t = val('dn-t').trim().slice(0, 400); if (!t) { setFlash('doc', 'اكتبي نص الرسالة.', 'warn'); break; } S.doctorNote = { text: t, t: now }; env.gate.audit(now, 'NOTE', 'DOCTOR_NOTE', 'رسالة من الطبيب'); setFlash('doc', 'أُرسلت الرسالة وستظهر في الصفحة الرئيسية للمريضة.', 'ok'); break; }
      case 'startPeriod': {
        const k = U.dayKey(now);
        if (!S.bleeding.some(x => x.date === k)) S.bleeding = S.bleeding.concat({ date: k, pads: { l: 0, m: 1, s: 0 } }).sort((a, b) => a.date < b.date ? -1 : 1);
        setFlash('fert', 'سُجّلت بداية الدورة اليوم. حدّثي كمية النزيف من تبويب «الأعراض والنزيف».', 'ok'); break;
      }
      case 'saveFert': { const k = U.dayKey(now); S.fertility = S.fertility.filter(x => x.date !== k).concat({ date: k, lh: val('f-lh'), mucus: val('f-mu') }).sort((a, b) => a.date < b.date ? -1 : 1); setFlash('fert', 'تم الحفظ وتحديث التقدير.', 'ok'); break; }
      case 'wRole': wstep = 1; if (d.r === 'doctor') { S.role = 'doctor'; } break;
      case 'wSave': {
        const a = num('w-a'), h = num('w-h'), w = num('w-w');
        if (!(a >= 10 && a <= 90 && h >= 120 && h <= 220 && w >= 30 && w <= 250)) { setFlash('wel', 'تحقّقي من العمر والطول والوزن.', 'warn'); break; }
        const p = S.patient; p.name = val('w-n').trim() || p.name; p.age = a; p.heightCm = h; p.weightKg = w; p.pregnant = chk('w-p'); p.hypertension = chk('w-hy');
        E.addReading(env, 'weight', w); wstep = 2; break;
      }
      case 'wPair': env.device.applyPatch(now); env.gate.audit(now, 'DEVICE', 'PATCH_APPLIED', 'ربط عند الإعداد'); S.onboarded = true; tab = S.role === 'doctor' ? 'doctor' : 'home'; wstep = 0; break;
      case 'wDone': S.onboarded = true; tab = S.role === 'doctor' ? 'doctor' : 'home'; wstep = 0; break;
      case 'goto': tab = d.v; flash = {}; render(); window.scrollTo(0, 0); return;
      case 'runToggle': S.clock.running = !S.clock.running; save(); renderClock(); return;
      case 'jump': E.advance(env, now + Number(d.h) * U.HOUR); break;
      case 'addMeasure': {
        const type = val('m-type'), v = num('m-val');
        if (!isFinite(v) || val('m-val') === '') { setFlash('measure', 'أدخلي قيمة صحيحة.', 'warn'); break; }
        if (type === 'weight' && (v < 30 || v > 250)) { setFlash('measure', 'الوزن خارج النطاق المعقول.', 'warn'); break; }
        if (type === 'lab_glucose' && (v < 20 || v > 600)) { setFlash('measure', 'قيمة الجلوكوز خارج النطاق المعقول.', 'warn'); break; }
        if (type === 'bp') { const dia = num('m-dia'); if (!(v >= 70 && v <= 260 && dia >= 40 && dia <= 160)) { setFlash('measure', 'قيم الضغط غير معقولة.', 'warn'); break; } E.addReading(env, 'bp', v, { dia }); }
        else E.addReading(env, type, v);
        setFlash('measure', type === 'lab_glucose' ? (S.device.patchApplied ? 'تم الحفظ ومعايرة المستشعر.' : 'تم الحفظ (لا رقعة للمعايرة).') : 'تم الحفظ.', 'ok'); break;
      }
      case 'exportCsv': {
        const rows = ['time,type,value,source'].concat(S.readings.filter(r => r.t > now - 7 * U.DAY).map(r => [U.fmtDT(r.t), r.type, r.value, r.src].join(',')));
        const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['﻿' + rows.join('\n')], { type: 'text/csv' })); a.download = 'ovasense-readings.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); return;
      }
      case 'saveProfile': { const p = S.patient; p.heightCm = num('p-h') || p.heightCm; p.age = num('p-a') || p.age; p.activity = val('p-act'); p.goal = val('p-goal'); setFlash('food', 'تم تحديث الملف والخطة.', 'ok'); break; }
      case 'shuffleDiet': dietSeed++; break;
      case 'pantryToggle': { const pt = pantry(), id = d.v; pt.have = pt.have.includes(id) ? pt.have.filter(x => x !== id) : pt.have.concat(id); if (pt.res) pt.res = Date.now(); break; }
      case 'pantryAdd': { const pt = pantry(), r = KT.parse(val('pt-txt')); pt.have = [...new Set(pt.have.concat(r.ids))]; pt.unknown = r.unknown; if (pt.res) pt.res = Date.now(); break; }
      case 'pantryClear': { const pt = pantry(); pt.have = []; pt.res = null; pt.unknown = []; break; }
      case 'suggestMeal': { const pt = pantry(); const r = KT.parse(val('pt-txt')); pt.have = [...new Set(pt.have.concat(r.ids))]; pt.unknown = r.unknown; pt.slot = val('pt-slot') || 'any'; if (!pt.have.length) { setFlash('kit', 'اختاري أو اكتبي مكوّنات أولاً.', 'warn'); pt.res = null; break; } pt.res = Date.now(); break; }
      case 'logRecipe': { const c = Number(d.c); E.addMeal(env, d.n, c); setFlash('kit', 'سُجّلت «' + esc(d.n) + '» (' + c + ' جم كربوهيدرات) وستظهر في نموذج الجلوكوز.', 'ok'); break; }
      case 'saveBody': {
        const b = body(E.derive(env)), m = {}; BD.FIELDS.forEach(f => m[f.k] = num('bd-' + f.k));
        const bad = BD.validate(m); if (bad.length) { setFlash('body', 'تحققي من: ' + bad.join('، '), 'warn'); break; }
        b.m = m; setFlash('body', 'تم بناء المجسّم من قياساتك.', 'ok'); break;
      }
      case 'clearShape': { if (S.body) S.body.shape = null; setFlash('scan', 'أُلغيت نسب المسح.', 'info'); break; }
      case 'addMeal': { const c = num('ml-c'); if (!(c >= 0 && c <= 300)) { setFlash('food', 'كربوهيدرات غير معقولة (0–300).', 'warn'); break; } E.addMeal(env, val('ml-n') || 'وجبة', c); setFlash('food', 'سُجّلت الوجبة. شغّلي المحاكاة أو اقفزي ساعة لترين الأثر.', 'ok'); break; }
      case 'checkSupp': {
        S.patient.meds = val('sp-m'); S.patient.pregnant = chk('sp-p'); S.patient.hypertension = chk('sp-h');
        const r = AI.supplementCheck(val('sp-q'), { meds: S.patient.meds, pregnant: S.patient.pregnant, hypertension: S.patient.hypertension });
        setFlash('supp', esc(r.text) + (r.warnings ? r.warnings.map(w => '<br>⚠ ' + esc(w)).join('') : ''), r.found ? (r.level === 'caution' ? 'warn' : 'info') : 'warn'); break;
      }
      case 'saveSymptoms': {
        const k = U.dayKey(now), e = { date: k }; ['acne', 'hirsutism', 'fatigue', 'mood', 'cramps', 'bloating', 'hairloss', 'headache'].forEach(f => e[f] = num('s-' + f));
        S.symptoms = S.symptoms.filter(x => x.date !== k).concat(e).sort((a, b) => a.date < b.date ? -1 : 1); setFlash('sym', 'تم حفظ أعراض اليوم.', 'ok'); break;
      }
      case 'saveBleeding': {
        const k = U.dayKey(now);
        const e = { date: k, pads: { l: num('b-pl'), m: num('b-pm'), s: num('b-ps') }, clotsS: num('b-cs'), clotsL: num('b-cl'), flooding: chk('b-fl'), spotting: chk('b-sp'), dizzy: chk('b-dz') };
        S.bleeding = S.bleeding.filter(x => x.date !== k).concat(e).sort((a, b) => a.date < b.date ? -1 : 1);
        const a = AI.bleedingAnalysis(S.bleeding, now);
        setFlash('sym', a.urgent ? 'مؤشرات خطر: توجهي للطوارئ أو تواصلي مع الطبيب فوراً.' : 'تم حفظ النزيف وتحديث التحليل.', a.urgent ? 'danger' : 'ok'); break;
      }
      case 'preset': S.twin.deficit = Number(d.d); S.twin.act = Number(d.a); S.twin.adh = Number(d.p); break;
      case 'ask': await ask(d.q); return;
      case 'clearChat': S.chat = []; break;
      case 'saveLabs': { const i = val('l-ins'), a = val('l-a1c'); S.labs.fastingInsulin = i === '' ? null : Number(i); S.labs.hba1c = a === '' ? null : Number(a); S.labs.labIntervalDays = Math.max(7, num('l-int') || 90); S.labs.lastLabT = now; env.gate.audit(now, 'LAB', 'ENTERED', 'by doctor'); setFlash('doc', 'حُفظت التحاليل وسُجّل تحليل اليوم.', 'ok'); break; }
      case 'saveRange': { const lo = num('r-lo'), hi = num('r-hi'); if (!(lo >= 40 && hi > lo && hi <= 300)) { setFlash('doc', 'نطاق غير صالح.', 'warn'); break; } S.range = { low: lo, high: hi }; setFlash('doc', 'حُفظ النطاق.', 'ok'); break; }
      case 'signPlan': {
        const times = val('pl-times').split(',').map(x => x.trim()).filter(Boolean);
        const spec = { doseUL: num('pl-dose'), times, singleMaxUL: num('pl-sm'), dailyCapUL: num('pl-dc'), minIntervalMin: num('pl-mi'), onSignalLoss: val('pl-sl') };
        const bad = !times.length || times.some(t => !/^([01]\d|2[0-3]):[0-5]\d$/.test(t)) || !(spec.doseUL > 0) || spec.doseUL > spec.singleMaxUL || spec.singleMaxUL > spec.dailyCapUL || !(spec.minIntervalMin >= 0);
        if (bad) { setFlash('doc', 'تحقق من الحقول: أوقات بصيغة HH:MM، والجرعة ≤ الحد الأقصى ≤ السقف اليومي.', 'warn'); break; }
        const need = spec.doseUL * times.length * 7;
        const r = await E.signAndInstallPlan(env, spec, now);
        setFlash('doc', r.ok ? 'تم توقيع الخطة (إصدار ' + r.version + ') وقبلها الجهاز.' + (need > 1000 ? ' ⚠ استهلاك أسبوعي ' + need + ' µL يتجاوز سعة الخزان 1000 µL.' : '') : 'رفض الجهاز الخطة: ' + esc(r.label), r.ok ? 'ok' : 'danger'); break;
      }
      case 'sendCmd': {
        const dose = num('cmd-dose'); if (!(dose > 0)) { setFlash('doc', 'جرعة غير صالحة.', 'warn'); break; }
        const r = await E.sendCommand(env, { doseUL: dose }, now);
        setFlash('doc', r.code === 'OK' ? 'نُفّذ الأمر: ' + r.deliveredUL + ' µL (انحراف ' + r.deviationPct + '%).' : 'لم يُنفَّذ: ' + esc(r.label || r.code), r.code === 'OK' ? 'ok' : 'danger'); break;
      }
      case 'rotateKey': { const old = S.doctor.keyId; await E.provisionDoctor(env, now); env.gate.revokeKey(old, now); setFlash('doc', 'أُلغي المفتاح ' + old + ' وأُصدر مفتاح جديد. الخطة المثبتة تبقى سارية.', 'ok'); break; }
      case 'newPatch': env.device.applyPatch(now); env.gate.audit(now, 'DEVICE', 'PATCH_APPLIED', 'رقعة جديدة'); setFlash('dev', 'رُكّبت رقعة جديدة وامتلأ الخزان.', 'ok'); break;
      case 'removePatch': env.device.removePatch(); env.gate.audit(now, 'DEVICE', 'PATCH_REMOVED', ''); break;
      case 'toggleBle': S.device.bleUp = !S.device.bleUp; env.gate.audit(now, 'DEVICE', S.device.bleUp ? 'BLE_UP' : 'BLE_DOWN', ''); break;
      case 'clearFault': env.device.clearFault(); env.gate.audit(now, 'DEVICE', 'FAULT_CLEARED', ''); break;
      case 'fault': S.device.faults[d.k] = el.checked; break;
      case 'attack': { const r = await E.runAttack(env, d.id, now); labResults = labResults.filter(x => x.id !== r.id).concat(r); break; }
      case 'runAll': labResults = []; for (const a of E.attacks) labResults.push(await E.runAttack(env, a.id, now)); break;
      case 'tour': startTour(); return;
      case 'tourNext': await tourStep(1); return;
      case 'tourPrev': await tourStep(-1); return;
      case 'tourClose': $('#tour').hidden = true; tourI = -1; return;
      case 'reset': if (confirm('سيتم حذف بياناتك التجريبية وإعادة إنشائها. متابعة؟')) { try { localStorage.removeItem(LS); } catch (e) { } labResults = []; env = await E.seedDemo(Date.now()); tab = 'home'; flash = {}; } else return; break;
      default: return;
    }
    save(); render();
  }

  async function ask(q) {
    const S = env.S;
    q = (q || '').trim(); if (!q) return;
    S.chat.push({ who: 'u', text: q });
    const r = CH.reply(q, E.derive(env));
    S.chat.push({ who: 'b', text: r.text, sources: r.sources, tone: r.tone });
    if (S.chat.length > 60) S.chat = S.chat.slice(-60);
    save(); if (tab !== 'chat') tab = 'chat'; render();
  }

  // ---------- جولة العرض ----------
  const TOUR = [
    { t: 'الرئيسية: ما يقرؤه الجهاز الآن', x: 'نلاحظ الجلوكوز الحالي، الوقت ضمن النطاق، الجرعة القادمة، وتقدير حاجة التحليل مع أسبابه.', f: async () => { tab = 'home'; } },
    { t: 'وجبة ← أثر على الجلوكوز', x: 'سجّلنا وجبة 70 جم كربوهيدرات وتقدّم الزمن ساعة: يرتفع الجلوكوز في الرسم.', f: async () => { tab = 'home'; E.addMeal(env, 'غداء', 70); E.advance(env, env.S.clock.now + U.HOUR); } },
    { t: 'المساعد المخصص لبياناتها', x: 'يسأل: «وش يقرأ الجهاز بالضبط؟» ثم «هل أحتاج تحليل دم؟».', f: async () => { await ask('وش يقرأ الجهاز بالضبط؟'); await ask('هل أحتاج تحليل دم؟'); } },
    { t: 'التوأم الرقمي: ماذا لو؟', x: 'نطاق متوقع للوزن وسكر الصيام لو التزمت بنظام ونشاط.', f: async () => { tab = 'twin'; } },
    { t: 'الطبيب: خطة موقَّعة وسجل تدقيق', x: 'الجهاز لا ينفّذ إلا ما وقّعه الطبيب ضمن الحدود.', f: async () => { tab = 'doctor'; } },
    { t: 'مختبر الأمان', x: 'كل الهجمات تُصَدّ: إعادة إرسال، تعديل جرعة، مفتاح مُلغى، أمر الذكاء الاصطناعي بلا توقيع…', f: async () => { tab = 'lab'; labResults = []; for (const a of E.attacks) labResults.push(await E.runAttack(env, a.id, env.S.clock.now)); } },
    { t: 'عطل: انسداد ← توقف تلقائي', x: 'نحقن انسداداً ونتقدم إلى موعد الجرعة: حساس التدفق يكشف الانحراف ويوقف التوصيل ويُنبّه.', f: async () => { tab = 'device'; env.S.device.faults.occlusion = true; const nd = E.nextDose(env.gate.s.plan, env.S.clock.now); if (nd) E.advance(env, nd.t + 6 * U.MIN); } }
  ];
  function drawTour() {
    const el = $('#tour'); if (tourI < 0) { el.hidden = true; return; }
    const s = TOUR[tourI];
    el.hidden = false;
    el.innerHTML = '<b>' + (tourI + 1) + '/' + TOUR.length + ' · ' + esc(s.t) + '</b><p>' + esc(s.x) + '</p><div class="row"><button class="btn sm" data-act="tourNext">' + (tourI === TOUR.length - 1 ? 'إنهاء' : 'التالي') + '</button><button class="btn sec sm" data-act="tourPrev">السابق</button><button class="btn sec sm" data-act="tourClose">إغلاق</button></div>';
  }
  async function tourStep(dir) {
    if (dir > 0 && tourI === TOUR.length - 1) { tourI = -1; drawTour(); return; }
    tourI = Math.max(0, tourI + dir);
    flash = {}; await TOUR[tourI].f(); save(); render(); drawTour();
  }
  async function startTour() { tourI = -1; await tourStep(1); }

  // ---------- الإقلاع ----------
  async function boot() {
    try {
      if (!OvaCrypto.available()) throw new Error('WebCrypto غير متاح في هذا المتصفح/السياق. افتحي الصفحة عبر https أو localhost.');
      const saved = load();
      env = saved ? E.attach(saved) : await E.seedDemo(Date.now());
      if (!saved) save();
      render();
      timer = setInterval(tick, 1000);
    } catch (e) {
      $('#view').innerHTML = '<div class="alert danger">تعذّر تشغيل التطبيق: ' + esc(e.message) + '</div>';
      console.error(e);
    }
  }

  document.addEventListener('click', e => {
    const b = e.target.closest('[data-act]');
    if (!b || b.type === 'checkbox') return;
    act(b.dataset.act, b).catch(err => { console.error(err); setFlash('home', 'خطأ: ' + esc(err.message), 'danger'); });
  });
  document.addEventListener('change', e => {
    const t = e.target;
    if (t.id === 'scale') { env.S.clock.scale = Number(t.value); save(); return; }
    if (t.dataset && t.dataset.act === 'fault') { act('fault', t); return; }
    if (t.id === 'bd-scan') { scanBody(t.files && t.files[0]); return; }
    if (t.id === 'pt-slot') { const pt = pantry(); pt.slot = t.value; save(); if (pt.res) render(); return; }
    if (t.id === 'bd-unit') { const b = env.S.body; b.unit = t.value; b.n = Math.min(b.n, BD.UNITS[b.unit].max); save(); render(); return; }
    if (t.dataset && t.dataset.twin) {
      const tw = env.S.twin;
      tw.deficit = num('t-def'); tw.act = num('t-act'); tw.adh = num('t-adh'); tw.horizon = num('t-hor'); tw.fgAssumption = num('t-ass') || 0;
      save(); render();
    }
  });
  document.addEventListener('input', e => {
    const t = e.target;
    if (t.dataset && t.dataset.out) { const o = document.getElementById(t.dataset.out); if (o) o.textContent = t.value; }
    if (t.id === 'bd-n') { env.S.body.n = Number(t.value); updateBodyLive(); save(); }
  });
  document.addEventListener('submit', e => {
    if (e.target.id === 'chatform') { e.preventDefault(); const i = $('#chat-in'); const q = i.value; i.value = ''; ask(q); }
  });
  window.addEventListener('beforeunload', () => { try { if (env) save(); } catch (e) { } });
  window.__ova = { get env() { return env; } };
  boot();
})();
