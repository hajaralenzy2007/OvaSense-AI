/* OvaBody — توأم الجسم ثلاثي الأبعاد: قياسات المريضة ← مجسّم سلكي يشبه نسبها، وإسقاط زمني لتغيّر القياسات
   والهيئة لو التزمت بالخطة الغذائية والرياضية (من مسار الوزن في OvaTwin).
   - افتراضات تعليمية (تقريبية): لكل 1 كغ نقص في الوزن ينقص الخصر ~1 سم، الورك ~0.7، الصدر ~0.6، الفخذ ~0.5، الذراع ~0.3.
   - المسح بالكاميرا يتم داخل الجهاز فقط: تُحوَّل الصورة فوراً إلى ظلّ (Silhouette) بخطوط تشبه الأشعة،
     ولا تُعرض الصورة ولا تُحفظ ولا تُرسل. يُحفظ فقط نسب عرض الكتفين/الخصر/الورك. */
(function (g) {
  'use strict';
  const U = g.OvaUtil;
  const B = {};

  B.FIELDS = [
    { k: 'heightCm', ar: 'الطول', unit: 'سم', min: 120, max: 220 },
    { k: 'weightKg', ar: 'الوزن', unit: 'كغ', min: 30, max: 250 },
    { k: 'bust', ar: 'الصدر', unit: 'سم', min: 60, max: 180 },
    { k: 'waist', ar: 'الخصر', unit: 'سم', min: 45, max: 180 },
    { k: 'hip', ar: 'الورك', unit: 'سم', min: 60, max: 200 },
    { k: 'thigh', ar: 'الفخذ', unit: 'سم', min: 30, max: 100 },
    { k: 'arm', ar: 'الذراع', unit: 'سم', min: 18, max: 60 }
  ];
  // تغيّر المحيط (سم) لكل 1 كغ تغيّر في الوزن — افتراض تعليمي تقريبي
  B.CM_PER_KG = { bust: 0.6, waist: 1.0, hip: 0.7, thigh: 0.5, arm: 0.3 };
  B.UNITS = { d: { ar: 'أيام', days: 1, max: 30 }, w: { ar: 'أسابيع', days: 7, max: 24 }, m: { ar: 'أشهر', days: 30, max: 12 } };

  // قيم ابتدائية تقديرية من الطول والوزن إن لم تُدخل المريضة قياساتها
  B.defaults = function (heightCm, weightKg) {
    const bmi = weightKg / Math.pow(heightCm / 100, 2);
    const f = U.clamp((bmi - 22) / 10, -0.5, 2);
    return { heightCm, weightKg, bust: U.round(88 + 9 * f), waist: U.round(72 + 13 * f), hip: U.round(97 + 10 * f), thigh: U.round(54 + 6 * f), arm: U.round(27 + 4 * f), estimated: true };
  };

  B.validate = function (m) {
    const bad = B.FIELDS.filter(f => !(Number(m[f.k]) >= f.min && Number(m[f.k]) <= f.max)).map(f => f.ar);
    if (!bad.length && m.waist >= m.hip * 1.4) bad.push('الخصر/الورك');
    return bad;
  };

  B.ratios = function (m) {
    const whr = U.round(m.waist / m.hip, 2), whtr = U.round(m.waist / m.heightCm, 2), bmi = U.round(m.weightKg / Math.pow(m.heightCm / 100, 2), 1);
    return { whr, whtr, bmi, whrHigh: whr >= 0.85, whtrHigh: whtr >= 0.5 };
  };

  // قياسات اليوم d حسب مسار الوزن (مصفوفتا days وweight من OvaTwin)
  B.atDay = function (m, days, weights, d) {
    let i = 0; while (i < days.length - 1 && days[i + 1] < d) i++;
    const j = Math.min(i + 1, days.length - 1), span = days[j] - days[i] || 1, f = U.clamp((d - days[i]) / span, 0, 1);
    const w = weights[i] + (weights[j] - weights[i]) * f, dw = w - weights[0];
    const o = { heightCm: m.heightCm, weightKg: U.round(m.weightKg + dw, 1) };
    Object.keys(B.CM_PER_KG).forEach(k => { o[k] = U.round(Math.max(m[k] * 0.75, m[k] + B.CM_PER_KG[k] * dw), 1); });
    return o;
  };

  B.project = function (m, twinRes, unit, n) {
    const d = (B.UNITS[unit] || B.UNITS.w).days * n;
    const now = B.atDay(m, twinRes.days, twinRes.weight.mid, 0), at = B.atDay(m, twinRes.days, twinRes.weight.mid, d);
    // نتجاوز الأفق إن طُلب أكثر منه (نثبّت عند آخر نقطة)
    const delta = {}; Object.keys(at).forEach(k => delta[k] = U.round(at[k] - now[k], 1));
    return { day: d, now, at, delta, ratiosNow: B.ratios(now), ratiosAt: B.ratios(at), capped: d > twinRes.days[twinRes.days.length - 1] };
  };

  // نصف قطر قطع ناقص (a) من المحيط ونسبة العمق k=b/a (تقريب رامانوجان)
  B.semiAxis = (C, k) => C / (Math.PI * (3 * (1 + k) - Math.sqrt((3 + k) * (1 + 3 * k))));

  // حلقات المقطع العرضي (سم). كل حلقة: y نسبة من الطول، rx/rz نصفا القطر، cx/cz إزاحة المركز. shape: نسب من المسح (اختياري)
  B.rings = function (m, shape) {
    const H = m.heightCm, s = shape || {};
    const sh = s.shoulder || 1, wa = s.waist || 1, hi = s.hip || 1;
    const E = (y, C, k, o) => { const a = B.semiAxis(C, k); return Object.assign({ y, rx: a, rz: a * k, cx: 0, cz: 0 }, o || {}); };
    const sx = (r, f) => { r.rx *= f; return r; };
    const torso = [
      sx(E(0.455, m.hip * 0.9, 0.7), hi), sx(E(0.49, m.hip, 0.74, { cz: -1.2 }), hi), sx(E(0.53, m.hip * 0.97, 0.74, { cz: -0.8 }), hi),
      sx(E(0.57, (m.hip + m.waist) / 2, 0.76), (hi + wa) / 2), sx(E(0.61, m.waist, 0.78), wa), sx(E(0.645, (m.waist + m.bust) / 2 * 0.96, 0.75), (wa + sh) / 2),
      sx(E(0.675, m.bust * 0.9, 0.7), sh), sx(E(0.705, m.bust, 0.72, { cz: 1.6 }), sh), sx(E(0.74, m.bust * 0.95, 0.6, { cz: 0.6 }), sh),
      sx(E(0.775, m.bust * 0.97, 0.48), sh), sx(E(0.80, m.bust * 0.78, 0.55), sh), E(0.82, 37, 0.9), E(0.85, 32, 0.92)
    ];
    const hipA = B.semiAxis(m.hip, 0.74) * hi, legX = hipA * 0.52;
    const leg = [[0.47, 1, 1], [0.42, 0.92, 0.98], [0.36, 0.8, 0.92], [0.30, 0.66, 0.86], [0.275, 0.6, 0.84], [0.22, 0.64, 0.82], [0.15, 0.55, 0.8], [0.08, 0.4, 0.78], [0.04, 0.38, 0.78]]
      .map(([y, f, xo]) => E(y, m.thigh * f, 0.95, { cx: legX * xo }));
    const shA = B.semiAxis(m.bust * 0.97, 0.48) * sh, armR = B.semiAxis(m.arm, 0.95);
    const arm = [[0.785, 1.02], [0.74, 1], [0.69, 0.9], [0.635, 0.78], [0.6, 0.72], [0.55, 0.66], [0.5, 0.56], [0.47, 0.52], [0.44, 0.6]]
      .map(([y, f]) => E(y, m.arm * f, 0.95, { cx: shA + armR * 0.9 + (0.785 - y) * H * 0.17 }));
    const head = []; for (let i = 0; i <= 12; i++) { const t = i / 12, r = Math.sqrt(Math.max(0, 1 - Math.pow(2 * t - 1, 2))) * 9.8 + 0.3; head.push({ y: 0.858 + t * 0.142, rx: r * 0.84, rz: r, cx: 0, cz: 0.6 }); }
    return { H, torso, leg, arm, head };
  };

  // ---------------- رسم المجسّم على Canvas (متصفح فقط) ----------------
  B.draw = function (cv, models, angle) {
    const ctx = cv.getContext('2d'), W = cv.width, Hh = cv.height;
    ctx.clearRect(0, 0, W, Hh);
    const bg = ctx.createRadialGradient(W / 2, Hh * 0.45, 10, W / 2, Hh * 0.5, Hh * 0.75);
    bg.addColorStop(0, '#0d2233'); bg.addColorStop(1, '#03070d'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, Hh);
    ctx.strokeStyle = 'rgba(45,212,200,.08)'; ctx.lineWidth = 1;
    for (let y = 0; y < Hh; y += 16) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    const maxH = Math.max(...models.map(o => o.rings.H));
    const sc = (Hh * 0.86) / maxH, cx = W / 2, base = Hh * 0.95;
    const ca = Math.cos(angle), sa = Math.sin(angle);
    const P = (x, y, z) => { const X = x * ca + z * sa, Z = -x * sa + z * ca; return [cx + X * sc, base - y * sc, Z]; };
    models.forEach(o => {
      const R = o.rings, H = R.H, col = o.color, seg = 28;
      ctx.lineWidth = o.width || 1.2; ctx.strokeStyle = col; ctx.shadowColor = col; ctx.shadowBlur = o.glow || 8; ctx.globalAlpha = o.alpha == null ? 1 : o.alpha;
      const part = (rings, mir, mer) => {
        const pts = rings.map(r => { const a = []; for (let i = 0; i < seg; i++) { const t = i / seg * 2 * Math.PI; a.push(P(mir * (r.cx || 0) + r.rx * Math.cos(t), r.y * H, (r.cz || 0) + r.rz * Math.sin(t))); } return a; });
        pts.forEach(ring => { ctx.beginPath(); ring.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath(); ctx.stroke(); });
        for (let i = 0; i < seg; i += mer) { ctx.beginPath(); pts.forEach((ring, j) => j ? ctx.lineTo(ring[i][0], ring[i][1]) : ctx.moveTo(ring[i][0], ring[i][1])); ctx.stroke(); }
      };
      part(R.torso, 1, 4); part(R.head, 1, 4);
      part(R.leg, -1, 4); part(R.leg, 1, 4);
      part(R.arm, -1, 7); part(R.arm, 1, 7);
      ctx.globalAlpha = 1; ctx.shadowBlur = 0;
    });
    // خطوط مستويات القياس
    const top = models[0].rings;
    [['الصدر', 0.705], ['الخصر', 0.61], ['الورك', 0.49], ['الفخذ', 0.43]].forEach(([t, y]) => {
      const py = base - y * top.H * sc; ctx.strokeStyle = 'rgba(255,111,165,.35)'; ctx.setLineDash([3, 4]); ctx.beginPath(); ctx.moveTo(cx - W * 0.33, py); ctx.lineTo(cx + W * 0.33, py); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(255,170,205,.85)'; ctx.font = '11px "IBM Plex Sans Arabic",sans-serif'; ctx.textAlign = 'right'; ctx.fillText(t, W - 8, py - 3);
    });
  };

  // ---------------- المسح بالكاميرا مع حفظ الخصوصية ----------------
  // يحوّل الصورة إلى قناع ظلّ: يقدّر لون الخلفية من الحواف، ويعزل ما يختلف عنها. لا يُعاد أي بكسل من الصورة.
  B.silhouette = function (data, w, h) {
    const lum = new Float32Array(w * h), R = new Float32Array(w * h), G = new Float32Array(w * h), Bl = new Float32Array(w * h);
    for (let i = 0; i < w * h; i++) { R[i] = data[i * 4]; G[i] = data[i * 4 + 1]; Bl[i] = data[i * 4 + 2]; lum[i] = 0.299 * R[i] + 0.587 * G[i] + 0.114 * Bl[i]; }
    // لون الخلفية: وسيط بكسلات الإطار الخارجي
    const border = []; for (let x = 0; x < w; x++) { border.push(x, (h - 1) * w + x); } for (let y = 0; y < h; y++) { border.push(y * w, y * w + w - 1); }
    const med = arr => { const s = arr.slice().sort((a, b) => a - b); return s[s.length >> 1]; };
    const br = med(border.map(i => R[i])), bgc = med(border.map(i => G[i])), bb = med(border.map(i => Bl[i]));
    const dists = border.map(i => Math.hypot(R[i] - br, G[i] - bgc, Bl[i] - bb));
    const thr = Math.max(38, med(dists) * 3 + 18);
    let mask = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) mask[i] = Math.hypot(R[i] - br, G[i] - bgc, Bl[i] - bb) > thr ? 1 : 0;
    // تنظيف: إغلاق ثم فتح بسيط
    const morph = (m, keep) => { const o = new Uint8Array(w * h); for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) { let s = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) s += m[(y + dy) * w + x + dx]; o[y * w + x] = s >= keep ? 1 : 0; } return o; };
    mask = morph(morph(mask, 3), 6);
    // أكبر مكوّن متصل فقط (الجسم)
    const lab = new Int32Array(w * h); let best = 0, bestN = 0, cur = 0;
    for (let i = 0; i < w * h; i++) if (mask[i] && !lab[i]) {
      cur++; let n = 0; const st = [i]; lab[i] = cur;
      while (st.length) { const p = st.pop(); n++; const x = p % w, y = (p / w) | 0; [[1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dx, dy]) => { const X = x + dx, Y = y + dy; if (X >= 0 && Y >= 0 && X < w && Y < h) { const q = Y * w + X; if (mask[q] && !lab[q]) { lab[q] = cur; st.push(q); } } }); }
      if (n > bestN) { bestN = n; best = cur; }
    }
    for (let i = 0; i < w * h; i++) mask[i] = lab[i] === best ? 1 : 0;
    const frac = bestN / (w * h);
    // خط المنتصف من الصفوف العليا، ثم عرض «الجذع» = المقطع المتصل حول المنتصف (يستبعد الذراعين المنفصلتين)
    let top = -1, bot = -1, sx = 0, sn = 0;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (mask[y * w + x]) { if (top < 0) top = y; bot = y; }
    for (let y = top; y >= 0 && y < top + (bot - top) * 0.5; y++) for (let x = 0; x < w; x++) if (mask[y * w + x]) { sx += x; sn++; }
    const cx0 = sn ? Math.round(sx / sn) : w >> 1;
    const run = y => { y = U.clamp(Math.round(y), 0, h - 1); let c = cx0; if (!mask[y * w + c]) { let k = 1; while (k < w / 4 && !mask[y * w + c + k] && !mask[y * w + c - k]) k++; c = mask[y * w + c + k] ? c + k : c - k; if (!mask[y * w + c]) return 0; } let l = c, r = c; while (l > 0 && mask[y * w + l - 1]) l--; while (r < w - 1 && mask[y * w + r + 1]) r++; return r - l + 1; };
    const ok = frac > 0.05 && frac < 0.85 && top >= 0 && bot - top > h * 0.4;
    let shape = null;
    if (ok) {
      const L = bot - top, at = f => run(top + L * f);
      const maxIn = (a, b) => { let mx = 0; for (let f = a; f <= b; f += 0.005) mx = Math.max(mx, at(f)); return mx; };
      const minIn = (a, b) => { let mn = 1e9; for (let f = a; f <= b; f += 0.005) { const v = at(f); if (v) mn = Math.min(mn, v); } return mn === 1e9 ? 0 : mn; };
      // من الأعلى: الكتفان 0.17–0.22، الخصر أضيق نقطة 0.33–0.45، الورك أعرض نقطة 0.45–0.55
      const s = maxIn(0.17, 0.22), wa = minIn(0.33, 0.45), hp = maxIn(0.45, 0.55);
      if (s && wa && hp) {
        // مقارنة بنسب أنثوية نموذجية للعرض الأمامي: الكتفان/الورك ≈ 1.0، الخصر/الورك ≈ 0.75
        shape = { shoulder: U.round(U.clamp((s / hp) / 1.0, 0.85, 1.15), 2), waist: U.round(U.clamp((wa / hp) / 0.75, 0.85, 1.15), 2), hip: 1 };
      }
    }
    return { mask, ok, frac: U.round(frac, 3), shape, top, bot };
  };

  // رسم القناع كأشعة: حواف متوهجة + تدرّج داخلي، بلا أي بكسل من الصورة الأصلية
  B.drawXray = function (cv, sil, w, h) {
    const ctx = cv.getContext('2d'); cv.width = w * 2; cv.height = h * 2;
    const img = ctx.createImageData(w, h), m = sil.mask;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = y * w + x, o = i * 4;
      const edge = m[i] && (!m[i - 1] || !m[i + 1] || !m[i - w] || !m[i + w]);
      let r = 3, gg = 8, b = 14, a = 255;
      if (edge) { r = 120; gg = 255; b = 240; }
      else if (m[i]) { const t = 0.35 + 0.25 * Math.sin(y / 3); r = 20 * t; gg = 120 * t; b = 140 * t; }
      img.data[o] = r; img.data[o + 1] = gg; img.data[o + 2] = b; img.data[o + 3] = a;
    }
    const tmp = document.createElement('canvas'); tmp.width = w; tmp.height = h; tmp.getContext('2d').putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true; ctx.shadowColor = '#2dd4c8'; ctx.shadowBlur = 6; ctx.drawImage(tmp, 0, 0, w * 2, h * 2);
    tmp.width = tmp.height = 0;
  };

  g.OvaBody = B;
  if (typeof module !== 'undefined' && module.exports) module.exports = B;
})(globalThis);
