/* OvaKB — قاعدة معرفة تعليمية: أغذية، مكملات/أعشاب، مراجع.
   تنبيه: محتوى تعليمي يحتاج مراجعة طبيب/صيدلي/أخصائية تغذية قبل أي استخدام سريري. */
(function (g) {
  'use strict';
  const KB = {};

  KB.LEGEND = [
    { k: '●', t: 'دليل بشري منشور', d: 'دراسة على بشر (تجربة أو مراجعة منهجية أو مسح).' },
    { k: '◐', t: 'دليل مخبري/حيواني', d: 'اختبار على نموذج حيواني أو على منضدة العمل.' },
    { k: '○', t: 'مخطَّط', d: 'لم يُختبر بعد؛ ضمن خطة التحقق.' }
  ];

  // حصة تقريبية لكل صنف (قيم تقريبية، تُراجع مع أخصائية تغذية)
  // slot: b=فطور l=غداء/عشاء s=وجبة خفيفة ; role: P بروتين، C كربوهيدرات، V خضار، F دهون صحية، D ألبان، U فاكهة
  KB.FOODS = [
    { id: 'egg', ar: 'بيضة مسلوقة', serving: '1 بيضة', kcal: 78, carb: 0.6, protein: 6.3, fat: 5.3, fiber: 0, gi: 'منخفض', role: 'P', slots: 'b' },
    { id: 'foul', ar: 'فول مدمس', serving: '½ كوب', kcal: 110, carb: 19, protein: 7, fat: 0.5, fiber: 6, gi: 'منخفض', role: 'C', slots: 'b' },
    { id: 'wholebread', ar: 'خبز بر (أسمر)', serving: 'شريحة 30 جم', kcal: 80, carb: 14, protein: 3, fat: 1, fiber: 2, gi: 'متوسط', role: 'C', slots: 'b' },
    { id: 'oats', ar: 'شوفان مطبوخ', serving: '1 كوب', kcal: 155, carb: 27, protein: 5.5, fat: 2.6, fiber: 4, gi: 'منخفض', role: 'C', slots: 'b' },
    { id: 'labneh', ar: 'لبنة قليلة الدسم', serving: '2 ملعقة كبيرة', kcal: 45, carb: 2, protein: 3, fat: 3, fiber: 0, gi: 'منخفض', role: 'D', slots: 'b' },
    { id: 'yogurt', ar: 'زبادي سادة قليل الدسم', serving: '1 كوب', kcal: 130, carb: 15, protein: 11, fat: 3, fiber: 0, gi: 'منخفض', role: 'D', slots: 'bs' },
    { id: 'chicken', ar: 'دجاج مشوي', serving: '100 جم', kcal: 165, carb: 0, protein: 31, fat: 3.6, fiber: 0, gi: '—', role: 'P', slots: 'l' },
    { id: 'fish', ar: 'سمك أبيض مشوي', serving: '100 جم', kcal: 125, carb: 0, protein: 22, fat: 3.5, fiber: 0, gi: '—', role: 'P', slots: 'l' },
    { id: 'lean', ar: 'لحم أحمر قليل الدهن', serving: '90 جم', kcal: 185, carb: 0, protein: 26, fat: 8, fiber: 0, gi: '—', role: 'P', slots: 'l' },
    { id: 'lentil', ar: 'عدس مطبوخ', serving: '½ كوب', kcal: 115, carb: 20, protein: 9, fat: 0.4, fiber: 8, gi: 'منخفض', role: 'C', slots: 'l' },
    { id: 'chickpea', ar: 'حمص مسلوق', serving: '½ كوب', kcal: 135, carb: 22, protein: 7, fat: 2, fiber: 6, gi: 'منخفض', role: 'C', slots: 'l' },
    { id: 'brownrice', ar: 'أرز بني مطبوخ', serving: '½ كوب', kcal: 110, carb: 23, protein: 2.5, fat: 1, fiber: 2, gi: 'متوسط', role: 'C', slots: 'l' },
    { id: 'basmati', ar: 'أرز بسمتي مطبوخ', serving: '½ كوب', kcal: 130, carb: 28, protein: 2.7, fat: 0.3, fiber: 0.5, gi: 'متوسط-مرتفع', role: 'C', slots: 'l' },
    { id: 'salad', ar: 'سلطة خضار بزيت زيتون', serving: 'طبق متوسط', kcal: 80, carb: 8, protein: 2, fat: 5, fiber: 3, gi: 'منخفض', role: 'V', slots: 'bl' },
    { id: 'cookedveg', ar: 'خضار مطبوخة', serving: '1 كوب', kcal: 55, carb: 10, protein: 3, fat: 0.5, fiber: 4, gi: 'منخفض', role: 'V', slots: 'l' },
    { id: 'almond', ar: 'لوز', serving: 'حفنة 28 جم', kcal: 165, carb: 6, protein: 6, fat: 14, fiber: 3.5, gi: 'منخفض', role: 'F', slots: 's' },
    { id: 'apple', ar: 'تفاحة متوسطة', serving: '1 حبة', kcal: 95, carb: 25, protein: 0.5, fat: 0.3, fiber: 4.4, gi: 'منخفض', role: 'U', slots: 's' },
    { id: 'date', ar: 'تمر', serving: '1 حبة', kcal: 66, carb: 18, protein: 0.4, fat: 0, fiber: 1.6, gi: 'متوسط', role: 'U', slots: 's' },
    { id: 'cucumber', ar: 'خيار وجزر', serving: '1 كوب', kcal: 25, carb: 6, protein: 1, fat: 0.1, fiber: 2, gi: 'منخفض', role: 'V', slots: 's' },
    { id: 'cottage', ar: 'جبن قريش', serving: '½ كوب', kcal: 90, carb: 4, protein: 12, fat: 2.5, fiber: 0, gi: 'منخفض', role: 'P', slots: 'bs' }
  ];

  // مكملات/أعشاب — محتوى تعليمي محافظ. level: ◐/● للدليل العام، لا يُعد توصية علاجية.
  KB.SUPPLEMENTS = [
    { id: 'myo', names: ['ميو اينوزيتول', 'ميو-اينوزيتول', 'اينوزيتول', 'inositol', 'myo-inositol'], ar: 'ميو-إينوزيتول',
      evidence: 'تجارب عشوائية صغيرة ومراجعات تشير إلى تحسن محتمل في حساسية الإنسولين وانتظام الدورة؛ جودة الدليل متفاوتة.',
      cautions: 'عادة جيد التحمل؛ قد يسبب اضطراباً هضمياً بجرعات عالية. يُناقش مع الطبيب خاصة في الحمل.', flags: [] },
    { id: 'vitd', names: ['فيتامين د', 'فيتامين دال', 'vitamin d', 'vit d'], ar: 'فيتامين د',
      evidence: 'الدليل على فائدته في أعراض المتلازمة متضارب؛ المنطقي قياس المستوى في الدم أولاً.',
      cautions: 'الجرعات الزائدة قد ترفع الكالسيوم؛ الجرعة يحددها الطبيب وفق التحليل.', flags: ['needs_lab'] },
    { id: 'omega3', names: ['اوميغا 3', 'اوميجا 3', 'أوميغا3', 'omega 3', 'omega-3', 'زيت السمك'], ar: 'أوميغا-3',
      evidence: 'قد يخفض الدهون الثلاثية؛ أثره على بقية أعراض المتلازمة غير مؤكد.',
      cautions: 'قد يزيد قابلية النزف مع مضادات التخثر/مميعات الدم؛ يُبلَّغ الطبيب قبل الاستخدام.', flags: ['bleeding'] },
    { id: 'spearmint', names: ['النعناع', 'شاي النعناع', 'سبيرمنت', 'spearmint'], ar: 'شاي النعناع الأخضر (Spearmint)',
      evidence: 'دراسات صغيرة وقصيرة المدة على الأندروجينات؛ الأدلة محدودة.',
      cautions: 'غالباً آمن بكميات الشاي المعتادة؛ الإفراط قد يزعج المعدة.', flags: [] },
    { id: 'cinnamon', names: ['القرفه', 'قرفة', 'cinnamon'], ar: 'القرفة',
      evidence: 'أدلة ضعيفة ومتفاوتة على تأثيرها في الجلوكوز.',
      cautions: 'قرفة «كاسيا» تحتوي كومارين بكميات قد تضر الكبد عند الإفراط؛ يُفضَّل الاعتدال.', flags: [] },
    { id: 'berberine', names: ['بربرين', 'berberine'], ar: 'بربرين',
      evidence: 'بعض التجارب تُظهر أثراً على الجلوكوز والدهون، لكن جودة الدليل متفاوتة.',
      cautions: 'له تداخلات دوائية محتملة (مثل أدوية السكر والأدوية المعالجة عبر الكبد)، ولا يُستخدم في الحمل. يلزم مراجعة الصيدلي/الطبيب.', flags: ['interaction', 'pregnancy'] },
    { id: 'nac', names: ['ان اسيتيل سيستين', 'nac', 'n-acetylcysteine'], ar: 'ن-أسيتيل سيستين (NAC)',
      evidence: 'تجارب صغيرة؛ الدليل أولي.',
      cautions: 'قد يسبب أعراضاً هضمية؛ يُناقش مع الطبيب.', flags: [] },
    { id: 'licorice', names: ['عرق السوس', 'licorice', 'liquorice'], ar: 'عرق السوس',
      evidence: 'استُخدم تقليدياً؛ الأدلة السريرية في المتلازمة محدودة.',
      cautions: 'قد يرفع ضغط الدم ويخفض البوتاسيوم؛ يُتجنب عند ارتفاع الضغط أو في الحمل ما لم يوجّه الطبيب.', flags: ['hypertension', 'pregnancy'] }
  ];

  KB.REFERENCES = [
    { id: 1, lvl: '●', short: 'WHO — Polycystic ovary syndrome (fact sheet)', full: 'World Health Organization. Polycystic ovary syndrome. Fact sheet, 2026.', url: 'https://www.who.int/news-room/fact-sheets/detail/polycystic-ovary-syndrome', use: 'الانتشار 10–13% من النساء في سن الإنجاب، وحتى 70% غير مشخَّصات.' },
    { id: 2, lvl: '●', short: 'Alenzi et al., BMC Women\'s Health 2024', full: 'Alenzi et al. BMC Womens Health 2024;24:623.', url: 'https://doi.org/10.1186/s12905-024-03446-9', use: 'مسح سعودي (عينة ملاءمة): 22.5% إبلاغ ذاتي.' },
    { id: 3, lvl: '●', short: 'Gibson-Helm et al., JCEM 2016', full: 'Gibson-Helm M, et al. J Clin Endocrinol Metab 2016. 1,385 امرأة.', url: 'https://mdedge.com/content/survey-commonly-delayed-pcos-diagnosis-suggests-room-clinical-improvement', use: 'تأخر التشخيص أكثر من سنتين لدى 34%، وعدم الرضا عن المعلومات.' },
    { id: 4, lvl: '●', short: 'Nair et al., ISPOR 2020', full: 'Nair et al. Value in Health 2020;23(5) Suppl.', url: 'https://www.ispor.org/heor-resources/presentations-database/presentation/intl2020-3182/101373', use: 'الالتزام بالعلاج الدوائي 21.7–86%.' },
    { id: 5, lvl: '●', short: 'Notaro & Neto, JARG 2022', full: 'Notaro ALG, Neto FTL. J Assist Reprod Genet 2022;39(3):573–579.', url: 'https://doi.org/10.1007/s10815-022-02429-9', use: 'الأعراض الهضمية شائعة مع الميتفورمين.' },
    { id: 6, lvl: '●', short: 'Domecq et al., JCEM 2013', full: 'Domecq JP, et al. J Clin Endocrinol Metab 2013;98(12):4655–63. مراجعة منهجية.', url: 'https://nutrition-evidence.com/article/199604/lifestyle-modification-programs-in-polycystic-ovary-syndrome-systematic-review-and-meta-analysis', use: 'نطاقات التوأم الرقمي: سكر صائم −2.3 (−4.5 إلى −0.1) ملغ/دل، إنسولين صائم −2.1 (−3.3 إلى −1.0).' },
    { id: 7, lvl: '●', short: 'Kaur et al., PLoS ONE 2021', full: 'Kaur et al. PLoS ONE 2021;16(8):e0255830.', url: 'https://doi.org/10.1371/journal.pone.0255830', use: 'شكاوى المريضات: الآثار الجانبية والتكلفة وتكرار التحاليل.' },
    { id: 8, lvl: '●', short: 'Audet et al., JAMA 2001 (ملخص AAFP)', full: 'Audet MC, et al. JAMA 2001;285:2347–54.', url: 'https://www.aafp.org/afp/2002/0115/p294a', use: 'الرقعة الجلدية: التزام 88.1% مقابل 77.7% للأقراص (1,417 امرأة).' },
    { id: 9, lvl: '●', short: 'Rouphael et al., Lancet 2017', full: 'Rouphael NG, et al. Lancet 2017. doi:10.1016/S0140-6736(17)30575-5', url: 'https://mdedge.com/content/small-study-patients-prefer-microneedle-flu-vaccine', use: '70% (33/47) فضّلوا رقعة الإبر الدقيقة على الحقن.' },
    { id: 10, lvl: '●', short: 'Martens et al., JAMA 2021', full: 'Martens T, et al. JAMA 2021 (CGM).', url: 'https://www.sciencedaily.com/releases/2021/07/210726170357.htm', use: 'القياس المستمر: انخفاض HbA1c بمقدار 1.1 مقابل 0.16.' },
    { id: 11, lvl: '●', short: 'Sharma et al., Anal Methods 2018', full: 'Sharma S, et al. Anal Methods 2018;10(18):2088–2095.', url: 'https://doi.org/10.1039/c8ay00264a', use: 'إبر دقيقة لقياس جلوكوز السائل الخلالي: MARD ≈ 9%.' },
    { id: 12, lvl: '●', short: 'Norman et al., Pediatr Diabetes 2013', full: 'Norman JJ, et al. Pediatr Diabetes 2013;14(6):459–465.', url: 'https://doi.org/10.1111/pedi.12031', use: 'توصيل الإنسولين بإبر دقيقة مجوّفة: بدء مفعول أسرع بنحو 22 دقيقة (16 طفلاً).' },
    { id: 13, lvl: '●', short: 'Jing et al., Chem Eng J 2024', full: 'Jing et al. Chem Eng J 2024;502:157488.', url: 'https://doi.org/10.1016/j.cej.2024.157488', use: 'استشعار هرمون (كورتيزول) عبر إبر دقيقة — متطوعون أصحاء.' },
    { id: 14, lvl: '●', short: 'Fang et al., J Endocrinol Invest 2022', full: 'Fang M, et al. J Endocrinol Invest 2022. 12 تجربة.', url: 'https://doi.org/10.1007/s40618-021-01674-6', use: 'زيادة الوقت ضمن النطاق ≈ 7.91% مع القياس المستمر.' },
    { id: 15, lvl: '◐', short: 'Huang et al., Theranostics 2024', full: 'Huang et al. Theranostics 2024;14(4):1662–1682.', url: 'https://doi.org/10.7150/thno.92910', use: 'رقعة إبر دقيقة تجمع الاستشعار والتوصيل (جرذان).' },
    { id: 16, lvl: '◐', short: 'Bußmann et al., Appl Sci 2021', full: 'Bußmann A, et al. Appl Sci 2021;11(17):8008.', url: 'https://doi.org/10.3390/app11178008', use: 'مضخة MEMS مصغّرة (اختبار منضدي).' },
    { id: 17, lvl: '◐', short: 'Yu et al., DDDT 2025', full: 'Yu et al. Drug Des Devel Ther 2025;19:2473–2490.', url: 'https://doi.org/10.2147/DDDT.S502701', use: 'رقعة إبر دقيقة للبروجسترون (فئران/جرذان؛ لا دراسة بشرية).' },
    { id: 18, lvl: '○', short: 'Symex Labs — جامعة ملبورن (خبر)', full: 'University of Melbourne newsroom, March 2026.', url: 'https://www.unimelb.edu.au/newsroom/news/2026/march/new-hormone-sensor-developed-to-streamline-ivf-process', use: 'مستشعر هرمونات عبر السائل الخلالي في طور مبكر (خبر مؤسسي).' },
    { id: 19, lvl: '●', short: 'Shamanna et al., AACE Clin Case Rep 2025', full: 'Shamanna P, et al. AACE Clin Case Rep 2025;11(1):70–74.', url: 'https://doaj.org/article/4b110d9e97164f56b2a990be31f3e0f9', use: 'حالة واحدة لتوأم رقمي في المتلازمة (توضيحي فقط).' },
    { id: 20, lvl: '●', short: 'Cochrane — lifestyle in PCOS', full: 'Cochrane review: lifestyle changes in PCOS (15 trials, 498 women).', url: 'https://cgf.cochrane.org/news/blogshot-lifestyle-changes-women-polycystic-ovary-syndrome', use: 'جودة الدليل منخفضة إلى منخفضة جداً — لذا نعرض نطاقات لا وعوداً.' },
    { id: 21, lvl: '●', short: 'Higham et al., 1990 — PBAC', full: 'Higham JM, et al. Br J Obstet Gynaecol 1990;97:734–9. مخطط تقدير فقد الدم.', url: 'https://read.qxmd.com/read/2400752/assessment-of-menstrual-blood-loss-using-a-pictorial-chart', use: 'منهجية تقدير النزف (PBAC).' },
    { id: 22, lvl: 'مرجع', short: 'Insulet — Omnipod 5 Training Series: System Components (فيديو؛ ليس من إنتاج الفريق)', full: 'Insulet Corporation. Omnipod 5 Training Series — System Components (صفحة فيديو رسمية).', url: 'https://www.omnipod.com/current-podders/resources/omnipod-5/videos/overview', use: 'فيديو مرجعي لآلية «مستشعر ← خوارزمية ← توصيل مراقَب» المطبّقة سريريًا.' },
    { id: 23, lvl: '●', short: 'Wilcox et al., 2004 — نافذة الخصوبة', full: 'Wilcox AJ, Dunson DB, Weinberg CR, et al. Likelihood of conception with a single act of intercourse: providing benchmark rates for assessment of post-coital contraceptives / The timing of the fertile window. Hum Reprod 2004;19(7):1539–43.', url: 'https://scholars.duke.edu/publication/769684', use: 'نافذة الخصوبة ستة أيام تنتهي بيوم الإباضة — أساس تقدير النافذة في تبويب الخصوبة.' },
    { id: 24, lvl: '●', short: 'International PCOS Guideline 2023 — ملخص', full: 'Teede HJ, et al. International evidence-based guideline for the assessment and management of PCOS 2023 (Summary).', url: 'https://assets.monashivf.com/assets/Summary-International-evidence-based-guideline-for-the-assessment-and-management-of-polycystic-ovary-syndrome-2023.pdf', use: 'تعريف عدم انتظام الدورة: أقل من 21 أو أكثر من 35 يوماً، أو أقل من 8 دورات سنوياً، أو أي دورة تتجاوز 90 يوماً.' }
  ];

  g.OvaKB = KB;
  if (typeof module !== 'undefined' && module.exports) module.exports = KB;
})(globalThis);
